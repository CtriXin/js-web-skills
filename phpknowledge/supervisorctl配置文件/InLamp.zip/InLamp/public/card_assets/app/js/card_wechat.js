// jQuery(document).ready(function($) {

var RongKey = 'm7ua80gbufiym';//融云key
var timeIntervalId;//刷新音频时间的Interval Id
var currentAudio = null; //当前播放音频对象
var currentAudioId = ''; //当前播放音频id
var isRecording = false;//是否在录音
var Max_MSG_LENGTH = 10;//最多10条消息记录
var commit = 1;//对话条数

var EXTRA_REC_AUDIO_V1 = '0101001';
var EXTRA_REC_READ_AUDIO_V1 = '0101002';
var EXTRA_REC_FEEDBACK_V1 = '0101003';
var EXTRA_REC_SOS_V1 = '0101004';
var EXTRA_REC_LBS_V1 = '0101005';

var lastClickTime = 0;//用于过滤冒泡事件
var LS_LastReceiveTime = card_loginName + 'card_LastReceiveTime';//标记最后一次收到消息的时间戳，用于过滤历史消息

var MAX_DETETE_RECEIVE_REDIS_TIME = 120;//删除redis键的失效时间,用来判断是否需要请求后台,减轻服务器压力,单位秒。

/**
 * 获得当前时间 格式06-26 20:23:50 r="now" 为当前时间
 */
function curDateTime(r) {
    var p, o, n, m, l, k, f, q = new Date;
    return 'now' != r && (p = parseInt(r), 10 == r.length ? q.setTime(1000 * p) : q.setTime(p)), o = q.getMonth() + 1, n = q.getDate(), q.getDay(), m = q.getHours(), l = q.getMinutes(), k = q.getSeconds(), f = '', f = o > 9 ? f + o + '-' : f + '0' + o + '-', f = n > 9 ? f + n + ' ' : f + '0' + n + ' ', f = m > 9 ? f + m + ':' : f + '0' + m + ':', f = l > 9 ? f + l + ':' : f + '0' + l + ':', k > 9 ? f += k : f = f + '0' + k, f
}

function saveChatToDb(audio_url,message_type,from_nick,phone,deviceId,tm){
  try{
    if (db!=null) {
      db.transaction(function(context){
        context.executeSql('INSERT INTO card_chat(audio_url, message_type, from_nick, phone, deviceId, tm) VALUES (?,?,?,?,?,?)',[audio_url,message_type,from_nick,phone,deviceId,tm]);
      });
    }
  }catch(e){
    console.log(e);
  }
}

//播放/暂停
function changeControlStyle(audioId, controlId) {

    var audio = document.getElementById(audioId);

    var controlObj = $('#' + controlId);
    if (controlObj.hasClass('play')) {
        controlObj.addClass('pause').removeClass('play');
        audio.play();//开始播放
        controlObj.html('<span class="iconfont iconline-media-pause"></span>');
    } else {
        controlObj.addClass('play').removeClass('pause');
        controlObj.html('<span class="iconfont iconline-media-play"></span>');
        audio.pause();
    }
}

//播放时间
function timeChange(time, timePlaceId) {//默认获取的时间是时间戳改成我们常见的时间格式
    //分钟
    var minute = time / 60;
    var minutes = parseInt(minute);
    if (minutes < 10) minutes = '0' + minutes;
    //秒
    var second = time % 60;
    seconds = parseInt(second);
    if (seconds < 10) seconds = '0' + seconds;
    
    var allTime = minutes + ':' + seconds;
    var timePlace = document.getElementById(timePlaceId);
    timePlace.innerHTML = allTime;
}


//播放事件监听
function prepareSong(audioId, controlId, TimePlaceId, currentTimeId) {
    if (((new Date()).valueOf() - lastClickTime) > 400) {//过滤掉冒泡
        lastClickTime = (new Date()).valueOf();
    } else {
        return;
    }
    clearInterval(timeIntervalId);

    if (currentAudio != null) {
        if (currentAudioId != audioId) {
            currentAudio.currentTime = 0;
        }
        currentAudio.pause();
        clearInterval(timeIntervalId);
    }
    var audio = document.getElementById(audioId);
    currentAudio = audio;
    currentAudioId = audioId;
    var controlObj = $('#' + controlId);

    if (controlObj.hasClass('play')) {

        setTimeout(function () {
            timeIntervalId = setInterval(function () {
                timeChange(audio.currentTime, currentTimeId);//刷新播放进度时间
                timeChange(audio.duration, TimePlaceId);//解决进度不出来的问题
            }, 50);
        }, 100);
    }

    changeControlStyle(audioId, controlId);

    audio.addEventListener('pause',
        function () { //监听暂停
            controlObj.addClass('play').removeClass('pause');
            controlObj.html('<span class="iconfont iconline-media-play"></span>');
            clearInterval(timeIntervalId);
            if (audio.currentTime == audio.duration) {
                audio.currentTime = 0;
                // audio.stop();
            }
        }, false);
    audio.addEventListener('play',
        function () { //播放
            controlObj.addClass('pause').removeClass('play');
            controlObj.html('<span class="iconfont iconline-media-pause"></span>');
        }, false);

    audio.addEventListener('ended', function () {
        clearInterval(timeIntervalId);
        currentAudio = null;
    }, false);
}
//audio end
hideBtnGroup();
function hideBtnGroup() {
    $('#btn_group').hide();
}

function hideScaleStop(cb) {
    $('#stopRecord').animate({width:'0px'},800,'ease');
    $('#uploadVoice').animate({width:'0px'},800,'ease',cb);
}

function showScaleStop() {
    $('#stopRecord').animate({width:'107px'},800,'ease');
    $('#uploadVoice').animate({width:'107px'},800,'ease');
}

function showBtnGroup() {
    $('#btn_group').css('display','inline-block');
}



function showScaleRecord() {
  $('#startRecord').animate({width:'214px'},800,'ease');
}


function hideBtnRecord() {
    $('#div_record').hide();
}

function showBtnRecord() {
    $('#div_record').show();
}

//重置录音按钮
function resetRecordBtn() {
    isRecording = false;
    hideScaleStop(function () {
        hideBtnGroup();
        showBtnRecord();
        showScaleRecord();
    });
    
    $('#startRecord').removeAttr('disabled').removeClass('disable');
    $('#uploadVoice').attr('disabled', true);
    $('#stopRecord').attr('disabled', true).removeClass('cancel');
}

//将录音状态设置禁止
function setRecordBtn() {
    isRecording = true;

    var startRecordObj=$('#startRecord');
    setTimeout(function (){
        startRecordObj.animate({width:'0px'},800,'ease',function(){
        hideBtnRecord();
        showBtnGroup();
        showScaleStop();
    });
    },200);
    startRecordObj.attr("disabled", true);
    $('#uploadVoice').attr("disabled", false).removeClass('disable');
    $('#stopRecord').attr("disabled", false).addClass('cancel').removeClass('disable');
}

//wechat
wx.ready(function () {
    wx.hideOptionMenu();
    var startRecoredObj=$('#startRecord');
    startRecoredObj.removeAttr('disabled').removeClass('disable');

    // 4.2 开始录音
    startRecoredObj.on(A.options.clickEvent, function () {

        if (getCurrentDeviceX('device_type') == "kqk") {
            A.showToast(TIPS_NOT_SUPPORT_ACTION);
            return;
        }
        setRecordBtn();
        wx.startRecord({
            cancel: function () {
                A.showToast('用户拒绝授权录音');
                wx_stopRecord();
            }
        });
    });


    $('#stopRecord').on(A.options.clickEvent, function () {
        wx_stopRecord();
    });


    function wx_stopRecord() {

        wx.stopRecord({
            success: function (res) {
                voice.localId = res.localId;
                if (!isRecording) {
                    
                    $('#uploadVoice').attr('disabled', true);
    $('#stopRecord').attr('disabled', true).removeClass('cancel');
                    wx_uploadRecord();
                } else {

                    voice.localId = "";
                    resetRecordBtn();
                }
            },
            fail: function (res) {
                resetRecordBtn();
                A.showToast('录音失败，请重试');
            }
        });
    }

    // 4.4 监听录音自动停止
    wx.onVoiceRecordEnd({
        complete: function (res) {
            voice.localId = res.localId;
            resetRecordBtn();
            A.showToast('录音时间已超过一分钟,自动停止');
        }
    });

    //
    $('#uploadVoice').on(A.options.clickEvent, function () {
        if (getCurrentDeviceX('device_type') == 'kqk') {
            A.showToast(TIPS_NOT_SUPPORT_ACTION);
            return;
        }
        if (!isRecording) {
            //先暂停录音再上传
            A.showToast('请先录音');
            return;
        }
        isRecording = false;
        wx_stopRecord();
    });


    function wx_uploadRecord() {
        if (voice.localId == '') {
            A.showToast('请先录制一段声音');
            return;
        }

        wx.uploadVoice({
            localId: voice.localId,
            success: function (res) {
                resetRecordBtn();
                voice.localId = '';
                voice.serverId = res.serverId;
                ajax_get('/card_downloadVoice?media_id=' + voice.serverId + '&device_id=' + getCurrentDeviceX('device_id'), handleDownloadVoice);
                isRecording = false;
            },
            fail:resetRecordBtn
        });
    }

    function handleDownloadVoice(data) {
        if (data.errcode == 0) {
            A.showToast('语音发送成功');
            var deviceId=getCurrentDeviceX('device_id')+'';
            writeToChatLog(data.data.url, TEXT_ME, '我', 'now', default_owner_pic_url, data.data.msgId,deviceId,false,false);
            saveChatToDb(data.data.url,TEXT_ME,'我',card_loginName,deviceId,getCurTs());
        } else if (data.errmsg != '') {
            A.showToast(data.errmsg);
        } else {
            A.showToast('未知错误，请联系管理员');
        }
    }

    // 3 智能接口
    var voice = {
        localId: '',
        serverId: ''
    };

});

/*
 * 将音频写到对话框里
 * @param audio_url 音频链接
 * @param message_type 对话类型 TEXT_ME/TEXT_USER
 * @param from 来自用户的昵称 我/对方昵称
 * @param tm 时间戳13位
 * @param header_url 用户头像
 * @param msg_id 消息id
 * @param toDeviceId 对话方设备id
 * @param append true/false 聊天记录往后插入
 * @param hide true/false 是否插入的时候隐藏
 */
function writeToChatLog(audio_url, message_type, from,tm, header_url, msg_id, toDeviceId,append,hide) {
    if (header_url == undefined) header_url = default_device_pic_url;
    if (msg_id == undefined) msg_id = commit;

    var s = document.getElementById('list_audio');
    if (commit >= Max_MSG_LENGTH) {
        var t = s.childNodes.length;
        s.removeChild(s.childNodes[s.childNodes.length - 1]);
    }
    commit++;
    var li = document.createElement('div');
    var cls=toDeviceId;
    if (hide) {
        cls+=' view-hide';
    }
    li.setAttribute('class', cls);//重要，用于消息分组
    if (message_type == TEXT_ME) {
        li.innerHTML = '<li class="am-comment-success am-animation-slide-right am-comment-flip" style="margin: 0px auto;text-align: center"><a href="#"><img src=' + header_url + ' alt="头像" class="am-comment-avatar" width="48" height="48"/></a><div class="am-comment-main"><div class="am-comment-hd"><div class="am-comment-meta"><a class="am-comment-author">' + from + '</a><time>&nbsp;' + curDateTime(tm) + '</time></div></div><div class="am-comment-bd"><p><div class="div_audio"><button id="control' + msg_id + '" class="control play" audioId="audio' + msg_id + '" controlId="control' + msg_id + '" TimePlaceId="allTime' + msg_id + '" currentTimeId="currentTime' + msg_id + '"><span class="iconfont iconline-media-play"></span></button><audio id="audio' + msg_id + '" preload="true"><source src="' + audio_url + '">浏览器不支持音频</audio><spam class="time_block"><span id="time"><span class="tiemDetail"><span class="currentTime" id="currentTime' + msg_id + '">00:00</span>/<span class="allTime" id="allTime' + msg_id + '">00:00</span></span></span></spam><i id="tick' + msg_id + '" class="iconline-mark-yes color-blue view-hide">已读</i></div></p></div></div></li><br/>';
    } else if (message_type == TEXT_USER) {
        //判断是否当前设备，不是的话需要隐藏
        if (getCurrentActiveSectionId() == 'section_device_main') {
            if (toDeviceId != getCurrentDeviceX('device_id')) {
                li.style.display = 'none';
            }
        }

        li.innerHTML = '<li class="am-comment-primary am-animation-slide-left" style="margin: 0px auto;text-align: center"><a href="#"><img src="' + header_url + '" alt="头像" class="am-comment-avatar" width="48" height="48"/></a><div class="am-comment-main"><div class="am-comment-hd"><div class="am-comment-meta"><a class="am-comment-author">' + from + '</a><time>&nbsp;' + curDateTime(tm) + '</time></div></div><div class="am-comment-bd"><p><div class="div_audio"><button id="control' + msg_id + '" class="control play" audioId="audio' + msg_id + '" controlId="control' + msg_id + '" TimePlaceId="allTime' + msg_id + '" currentTimeId="currentTime' + msg_id + '"><span  class="iconfont iconline-media-play"></span></button><audio id="audio' + msg_id + '" preload="true"><source src="' + audio_url + '">浏览器不支持音频</audio><spam class="time_block"><span id="time"><span class="tiemDetail"><span class="currentTime" id="currentTime' + msg_id + '">00:00</span>/<span class="allTime" id="allTime' + msg_id + '">00:00</span></span></span></spam></div></p></div></div></li><br/>';
    }

    if (append) s.appendChild(li);
    else s.insertBefore(li,s.childNodes[0]);
}

bindControlEvent();
function bindControlEvent() {
    $(document).on(A.options.clickEvent, '.control', function () {
        var audioId = this.getAttribute('audioId');
        var controlId = this.getAttribute('controlId');
        var TimePlaceId = this.getAttribute('TimePlaceId');
        var currentTimeId = this.getAttribute('currentTimeId');
        prepareSong(audioId, controlId, TimePlaceId, currentTimeId);
    });
}


rongyunIni();

rongIMClientConnet();
bindClick();
function bindClick() {
    $('#div_online_state').on(A.options.clickEvent, function () {
        rongIMClientConnet();
        return false;
    });
}
function rongIMClientConnet() {
    //融云链接
    RongIMClient.connect(RongToken, {
        onSuccess: function (x) {
            // A.showToast('TCP连接成功');
        },
        onError: function (x) {
            A.showToast('TCP连接失败');
        }
    });
}

function rongyunIni() {
    RongIMClient.init(RongKey);

    if (localStorage.getItem(LS_LastReceiveTime) == null)
        localStorage.setItem(LS_LastReceiveTime, 0);
}
RongIMClient.setConnectionStatusListener({
    onChanged: function (status) {
        if (status == RongIMClient.ConnectionStatus.CLOSURE) {
            A.showToast('您已离线，请检查您的网络');
        }
        if (status == RongIMClient.ConnectionStatus.OTHER_DEVICE_LOGIN) {
            A.showToast('您的账号已在其他设备登录');
            window.location.href = 'card_login_page?otherDevice=1';
        }

        if (status == RongIMClient.ConnectionStatus.CONNECTED) {
            $('#div_online_state').hide();
        } else {
            $('#div_online_state').show();
        }
    }
});


RongIMClient.getInstance().setOnReceiveMessageListener({
    //接收消息
    onReceived: function (data) {
        //getSentTime()//十三位
        var con = eval('(' + data.getContent() + ')');
        if (localStorage.getItem(LS_LastReceiveTime) > data.getSentTime()) {
            return;
        }
        localStorage.setItem(LS_LastReceiveTime, data.getSentTime());

        switch (data.getExtra()) {
            case EXTRA_REC_AUDIO_V1:

                recAudio(data);
                delRec(data);
                break;
            case EXTRA_REC_READ_AUDIO_V1:
                showTick(data);
                break;
            case EXTRA_REC_FEEDBACK_V1:
                recFeedback(data);
                delRec(data);
                break;
            case EXTRA_REC_SOS_V1:
                recLbs(data, 'sos');
                break;
            case EXTRA_REC_LBS_V1:
                recLbs(data);
                delRec(data);
                break;
            default:
                break;
        }

    }
});

/*
 * 设置bean的任意值
 * @param deviceId 设备id
 * @param unreadType 对象的属性：unreadVoice/unreadLocation/bindPhoneList..
 * @param isUnread 布尔值，是否未读
 */
function setDeviceUnread(deviceId, unreadType, isUnread) {
    if (deviceUnreadArr[deviceId] != undefined) {
        deviceUnreadArr[deviceId][unreadType] = isUnread;
    }
}

function recFeedback(data){
    playAudioTip();
    A.showToast('您有新的消息通知');
    if (getCurrentActiveSectionId() != 'section_msgcenter') {
        $('#unread_msgcenter').show();
    } else {
        card_getMsgCenter();
    }
}

function showSosMsgUnread() {
    if (getCurrentActiveSectionId() != 'section_msgcenter') {
        $('#unread_msgcenter').show();
    } else {
        card_getMsgCenter();
    }
}

function showSosSpUnread(deviceId) {
    if (getCurrentActiveSectionId() == 'section_cardcenter') {
        $('#spsos_' + deviceId).show();
    }
}


function recLbs(data, type) {
    playAudioTip();

    var obj = eval('(' + data.getContent() + ')');
    var index = getIndexByDeviceId(obj.user_id);
    var toast = '您有来自' + obj.nick + '的定位通知';
    if (type == 'sos') {
        toast = '您有来自' + obj.nick + '的求救信息';
        showSosMsgUnread();
        showSosSpUnread(obj.user_id);
    }
    A.showToast(toast);

    if (index != null) {
        user_bind_deivce_obj.data.devices[index].location_zh = obj.address;
        user_bind_deivce_obj.data.devices[index].location = '{"LAT_B":"' + obj.lat + '","LNG_B":"' + obj.lng + '","update_time":"' + curDateTime(data.getSentTime()) + '","type":"' + obj.type + '"}';
    }

    if (getCurrentActiveSectionId() != 'section_trace') {
        setDeviceUnread(obj.user_id, 'unreadLocation', true);
        $('#unread_li' + obj.user_id).show();//主页需要
        if (current_device_position != -1 && getCurrentDeviceX('device_id') == obj.user_id) {
            $('#unread_location').show();//在设备详情页需要
        }

    } else {//直接刷新地图
        iniLocation();
    }
}

function recAudio(data) {
    playAudioTip();
    var obj = eval('(' + data.getContent() + ')');
    A.showToast('您有来自' + obj.nick + '的语音消息');
    var sendTime=data.getSentTime();
    var hide=true;
    if (getCurrentActiveSectionId() == 'section_device_main' && getCurrentDeviceX('device_id') == obj.user_id) {
        //当前设备的语音页面，
        $('.' + obj.user_id).show();
        hide=false;
    } else {
        $('#unread_li' + obj.user_id).show();//主页需要
        setDeviceUnread(obj.user_id, 'unreadVoice', true);
    }
writeToChatLog(obj.url, TEXT_USER, obj.nick,sendTime, getHeadPicByDeviceId(obj.user_id), obj.msg_id, obj.user_id,false,hide);

    saveChatToDb(obj.url,TEXT_USER,obj.nick,card_loginName,obj.user_id,Math.round(sendTime/1000));
}

/**
 * 通知服务器删除已收到消息队列
 * @param data
 */
function delRec(data) {
    if (((new Date()).valueOf() - data.getSentTime()) > MAX_DETETE_RECEIVE_REDIS_TIME * 1000) {
        return;
    }
    var obj = eval('(' + data.getContent() + ')');
    var prefix = '';
    if (data.getExtra() == EXTRA_REC_FEEDBACK_V1) {
        prefix = card_userId;
    }
    ajax_get('/delRecAudio?msgId=' + prefix + obj.msg_id + '&type=xsk');//各类型已读通用
}

function showTick(data) {
    playAudioTip();
    A.showToast('您的语音已被收听');
    var obj = eval('(' + data.getContent() + ')');
    $('#tick' + obj.read_id).show();
}

//播放来信息提示音
function playAudioTip() {
    var audiotip = document.getElementById('audio_tip');
    audiotip.play();
}
