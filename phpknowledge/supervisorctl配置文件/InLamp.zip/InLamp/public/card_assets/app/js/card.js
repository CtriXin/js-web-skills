//#TODO 重构代码，减少全局污染 测试版入口
var TYPE_DEVICE_EDIT = 2;
var TYPE_DEVICE_ADD = 1;


var TEXT_ME = '0';
var TEXT_USER = '1';

var TIPS_NOT_SUPPORT_ACTION = '该设备不支持此功能';

var current_device_position = -1;//listview 切换设备数组的位置
var current_edit_type = 1;//当前设备是1编辑还是2添加

var previewSelected = null;//上一个选择的头像对象
var user_info_obj = null;//用户微信info的对象
var user_bind_deivce_obj = null;//用户绑定的设备的对象
var deviceUnreadArr = [];//用来存储含有未读控件的对象,key=device_id,value=beanObj

var default_device_pic_url = 'http://7xkaou.com2.z0.glb.qiniucdn.com/default_avatar.png';//用户默认头像
var default_owner_pic_url = default_device_pic_url;//微信用户默认头像

var db=null;
var isShowAudioRecord = false;//是否拉取过聊天记录

// $(document).ready(function(){
(function(){

//各按钮点击事件：
btnOnClick();

//各articleshow事件：
articleshow();

setTimeout(function(){
    $('#img_userhead').animate({width:'90px',height:'90px'},1000,'ease',function(){
      setLocationBtnViewSize();
  });
}, 2000);



function setLocationBtnViewSize() {
    $('#div_addDevice').show();
    $('#btn_addDevice').animate({width:'90%'},600,'ease',function(){
    });
}

//设置按钮点击事件
function btnOnClick(){

    $('#ic_device_delete').on(A.options.clickEvent, function () {
        var imei = $('#edit_imei').val();
        if ($('#edit_imei').val() != '') {
            A.confirm('提示', '确定要解绑此设备吗？',
                function () {
                    // 确定
                    ajax_get('/deleteDevice?imei=' + imei, handleDeteleDevice);
                });
        }
        function handleDeteleDevice(data) {
            if (data.errcode == 0) {
                A.showToast('解绑成功');
                redirectToCardCenter();

            } else {
                A.showToast(data.errmsg);
            }
        }
        return false;
    });

    //编辑/添加设备提交按钮
    $('#btn_edit_submit').on(A.options.clickEvent, function () {
        submitEditDevice();
        return false;
    });

    //跳转编辑设备按钮
    $('#a_device_edit').on(A.options.clickEvent, function () {
        jumpToEditSection();

        function jumpToEditSection() {
            A.Controller.section('#section_card_edit');
            current_edit_type = TYPE_DEVICE_EDIT;
            toEditType();
            //et 自动填入
            if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {

                var obj = user_bind_deivce_obj.data.devices[current_device_position];
                var nick = obj.nick ||'未设置昵称';
                var IMEI = obj.device_id;
                var sex = obj.sex||'男';
                $('#edit_imei').val(IMEI);
                $('#edit_nick').val(nick);
                if (sex == '男') {
                    $('#male').prop('checked', true);
                } else {
                    $('#female').prop('checked', true);
                }
                //TODO pic
            }
        }

        function toEditType() {
            $('#title_card_edit').html('编辑设备');
            $('#edit_pwd_right').hide();
            $('#edit_pwd_left').hide();
            $('#edit_pwd_hr').hide();
            $('#ic_device_delete').show();
            $("#edit_imei").attr('disabled','disabled'); 
        }

        return false;
    });

    //设置语音按键
    $('#btn_setKeySelect').on(A.options.clickEvent, function () {
        A.Controller.section('#section_card_manage');
        return false;
    });

    //校园管理
    $('#btn_submit_school_manage').on(A.options.clickEvent, function () {
        submitSchoolManage();

//校园管理时间提交
function submitSchoolManage() {
    var daily = getLimitTimeByTag('daily');
    var saturday = getLimitTimeByTag('saturday');
    var sunday = getLimitTimeByTag('sunday');
    var total = daily + ',' + saturday + ',' + sunday;
    var toggle = getIsToggleActive('toggle_school_manage');//TODO 提交更新到json device中
    ajax_get('/submitSchoolManage?device_id=' + getCurrentDeviceX('device_id') + '&toggle=' + toggle + '&limit_time=' + total, handleSubmitSchoolManage);

    function handleSubmitSchoolManage(data) {
        if (data.errcode == 0) {
            A.showToast('提交成功');
        } else {
            A.showToast(data.errmsg);
        }
    }
}
return false;
});

    //设备管理提交按钮
    $('#btn_manage_setting_submit').on(A.options.clickEvent, function () {
        if (getCurrentDeviceX('device_type') != 'kqk') {
            submitManageSettings();
        }

        submitToggleAttendance();
        return false;
    });

    //定位按钮
    $('#btn_location').on(A.options.clickEvent, function () {
        // 跳转定位页面
        A.Controller.section('#section_trace');
        return false;
    });

    //获取实时定位按钮
    $('#btn_getLocation').on(A.options.clickEvent, function () {
        getNewLocation();

        function getNewLocation() {
            ajax_get('/getNewLocation?device_id=' + getCurrentDeviceX('device_id'), handleGetNewLocation);

            function handleGetNewLocation(data) {
                if (data.errcode == 0) A.showToast('提交成功,等待定位返回');
                else A.showToast(data.errmsg);
            }
        }

        return false;
    });

    //远程关机按钮
    $('#btn_remote_shutdown').on(A.options.clickEvent, function () {
        shutdown();

        function shutdown() {
            A.confirm('提示', '确定要远程关机吗？',
                function () {
                    ajax_get('/shutdown?device_id=' + getCurrentDeviceX('device_id'), handleShutdown);
                });

            function handleShutdown(data) {
                if (data.errcode == 0) A.showToast('关机指令提交成功');
                else A.showToast(data.errmsg);
            }
        }
        return false;
    });

    //校园管理按钮
    $('#btn_school_manage').on(A.options.clickEvent, function () {
        // 跳转校园管理页面
        A.Controller.section('#section_school_manage');
        return false;
    });

    //消息中心
    $('#sp_msg_center').on(A.options.clickEvent, function () {
        // 跳转消息中心
        A.Controller.section('#section_msgcenter');
        return false;
    });

    //设备管理
    $('#sp_card_change').on(A.options.clickEvent, function () {
        // 跳转设备管理（号码设置）
        A.Controller.section('#section_card_manage');
        return false;
    });

    //添加设备
    $('#btn_addDevice').on(A.options.clickEvent, function () {
        // 跳转学生卡管理
        A.Controller.section('#section_card_edit');
        current_edit_type = TYPE_DEVICE_ADD;
        toAddType();

        function toAddType() {
            $('#edit_imei').val('').removeAttr("disabled");
            $('#edit_nick').val('');
            $('#edit_pwd').val('');
            $('#title_card_edit').html('添加设备');
            $('#edit_pwd_right').show();
            $('#edit_pwd_left').show();
            $('#edit_pwd_hr').show();
            $('#ic_device_delete').hide();
        }

        return false;
    });

    //选择头像
    $('.head-img').on(A.options.clickEvent, function () {
        var t = $(this);
        if (previewSelected) {
            previewSelected.css('border', '0px');
        }
        t.css('border', 'solid 1px #3779D0');
        previewSelected = t;
        document.getElementById('iconInfos').value = t.attr('src');
        return false;
    });

    //设备列表点击进入设备详情
    $(document).on(A.options.clickEvent, '.li_device', function () {
        current_device_position = this.getAttribute('position');
        A.Controller.section('#section_device_main');
        refrehDeviceDetial();
    });

    //消息中心点击进入定位页面
    $(document).on(A.options.clickEvent, '.action_sos,.action_17', function () {
        var device_id = this.getAttribute('device_id');
        var index=getIndexByDeviceId(device_id);
        if (index==null) return;
        current_device_position=index;
        A.Controller.section('#section_trace');
    });

}


//监听articleshowshow事件（核心）
function articleshow() {

    //article和section 状态切换：
    $('#article_cardcenter').on('refreshInit', function () {//首页首次展示调用
        getWechatinfo();
        getBindDevice();
        setRefresh();
        if (db==null) iniDb();

function iniDb(){
  console.log('iniDb');
  db = openDatabase('bxj_zhihui', '1.0', 'bxj DB', 2 * 1024 * 1024,function(){
  });
  db.transaction(function (context) {
    console.log('CREATE begin');
    var sql='CREATE TABLE if not exists card_chat(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,audio_url TEXT  NOT NULL,message_type TEXT NOT NULL,from_nick TEXT NOT NULL,phone TEXT NOT NULL,deviceId TEXT NOT NULL,tm INTEGER)';
    context.executeSql(sql,[],
      function(tx,result){}, 
      function(tx, error){});
  });
}

        function setRefresh() {
            var refresh = A.Refresh('#article_cardcenter');
            refresh.on('pullup', function () {
                setTimeout(function () {
                    ajax_get('/queryDevice', handleQueryDevice);
                }, 1000);//有点延迟才友善
            });
        }

        //获取微信用户信息
        function getWechatinfo() {
            if (user_info_obj == null) {
                var lsinfo=getWechatInfoFromLS(openid);
                if (lsinfo!=null) {
                    user_info_obj=1;
                    handleWechatinfo(A.JSON.parse(lsinfo),1);
                    return;
                }
                ajax_get('/wechatinfo', handleWechatinfo);
            }

            function handleWechatinfo(data,notSetLs) {
                if (data.nickname != null) {
                    user_info_obj = 1;
                    $('#img_userhead').attr('src', data.headimgurl);
                    $('#sp_user_name').html(data.nickname);
                    default_owner_pic_url = data.headimgurl;

                    if (notSetLs==undefined) {
                        setWechatInfoToLS(openid,data);
                    }
                }
            }
        }

        function setWechatInfoToLS(openid,obj){
            try {
               localStorage.setItem(openid+'info',A.JSON.stringify(obj));
               localStorage.setItem(openid+'infots',getCurTs());
           } catch (e) {}
       }
        function getWechatInfoFromLS(openid){
                    var info,ts=null;
                    try {
                        info=localStorage.getItem(openid+'info');
                        ts=localStorage.getItem(openid+'infots');
                    } catch (e) {}
                    if (ts) {
                        if ((getCurTs()-ts)>86400*2) {
                            return null;
                        }
                    }
                    return info;
                }

        //获取用户绑定设备
        function getBindDevice() {
            if (user_bind_deivce_obj == null) {
                ajax_get('/queryDevice', handleQueryDevice);
            }
        }
    });

    //当scroll初始化会进入此监听
    $('#article_device_main').on('scrollInit', function () {
        var scroll = A.Scroll(this);//已经初始化后不会重新初始化，但是可以得到滚动对象

        //监听滚动到顶部事件
        scroll.on('scrollTop', function () {
            scroll.refresh();
        });

        //监听滚动到底部事件
        scroll.on('scrollBottom', function () {
            scroll.refresh();
        });
    });

    $('#article_card_manage').on('scrollInit', function () {
        var scroll = A.Scroll(this);

        scroll.on('scrollTop', function () {
            scroll.refresh();
        });

        scroll.on('scrollBottom', function () {
            scroll.refresh();
        });
    });

    $('#article_cardcenter').on('articleshow', function () {//首页每次展示调用，考虑到频繁recreate，以后可以使用articleload
        showDeviceUnread();
        function showDeviceUnread() {
            for (deviceId in deviceUnreadArr) {
                if (deviceUnreadArr[deviceId].unreadVoice || deviceUnreadArr[deviceId].unreadLocation) {
                    $('#unread_li' + deviceId).show();
                } else {
                    $('#unread_li' + deviceId).hide();
                }
            }

        }
    });

    $('#article_msgcontent').on('articleshow', function () {//消息中心每次展示调用
        card_getMsgCenter();

//获取消息中心的信息
function card_getMsgCenter() {
    ajax_get('/card_getMsgCenter', handleGetMsgCenter);
    $('#unread_msgcenter').hide();


    function handleGetMsgCenter(data) {

        if (data.data.total == 0) {
            $('#list_noMsg').show();
            return;
        } else {
            $('#list_noMsg').hide();
        }
        var refresh = A.Refresh('#article_msgcontent');
        var ul = $('#lv_msg');
        ul.html('');//先清空ul
        var arr = data.data.records;
        var len = arr.length;
        for (var i = 0; i < len; i++) {
            var content = arr[i].content;
            var time = arr[i].time;
            var device_id = arr[i].device_id;
            var action = arr[i].action;
            var nick = arr[i].all_device.nick;
            var li = '<li device_id="'+device_id+'" class="action_'+action+'"><div class="text">' + content + '<small>' + nick + ' 【' + device_id + '】 ' + time + '</small></div></li>';
            ul.append(li);
        }
        refresh.refresh();
    }
}
});

    $('#article_school_manage').on('articleshow', function () {//校园管理设置每次展示调用
        iniSchoolManageSettings();

        function iniSchoolManageSettings() {
            setSchoolManageToggle();
            setSchoolManageLimitTime();

            function setSchoolManageToggle() {
                var flag = getCurrentDeviceX('flag_limit_time');
                setToggleState('toggle_school_manage', flag);
            }

            function setSchoolManageLimitTime() {
                var total = getCurrentDeviceX('limit_time');

                if (total == null || total == undefined || total == '') {
                    return;
                }
                var sectionArr = total.split(',', 3);
                setLimitTimeByTag(sectionArr[0], 'daily');
                setLimitTimeByTag(sectionArr[1], 'saturday');
                setLimitTimeByTag(sectionArr[2], 'sunday');

                //tag=daily\sunday\saturday
                function setLimitTimeByTag(sectionTime, tag) {
                    var paireArr = sectionTime.split(';', 4);
                    for (var i = 0; i < paireArr.length; i++) {
                        var singleArr = paireArr[i].split('-', 2);
                        $('#' + tag + (i + 1) + '1').val(singleArr[0]);
                        $('#' + tag + (i + 1) + '2').val(singleArr[1]);
                    }
                }
            }

        }
    });

    $('#article_device_main').on('articleshow', function () {//设备详情每次展示调用
        getBindPhoneByImei();
        setVolumeAndSwtich();
        setWorkMode();
        $('#spsos_' + getCurrentDeviceX('device_id')).hide();

        function setVolumeAndSwtich() {
            if (user_bind_deivce_obj.data.devices.length > current_device_position) {
                var obj = user_bind_deivce_obj.data.devices[current_device_position];
                var volume = obj.volume||0;
                var attendance_notice = obj.flag_attendance_notice == 1 ? 1 : 0;//到离校通知1开启
                setVolumeSelect(volume);
                setToggleState('toggle_attendance', attendance_notice);
            }
        }

        function setWorkMode() {
            if (user_bind_deivce_obj.data.devices.length > current_device_position) {
                var obj = user_bind_deivce_obj.data.devices[current_device_position];
                var work_model = obj.work_model;
                var id = 'mode_1';
                switch (work_model) {
                    case 0:
                    id = 'mode_0';
                    break;
                    case 2:
                    id = 'mode_2';
                    break;
                    default:
                    break;
                }
                $('#' + id).prop('checked', true);
            }
        }

        //设置音量展示给用户
        function setVolumeSelect(volume) {
            var id = 'vol_0';
            if (volume == 0) {
            }
            else if (volume < 2) {
                id = 'vol_1';
            } else if (volume >= 2 && volume < 4) {
                id = 'vol_2';
            } else {
                id = 'vol_3';
            }
            $('#' + id).prop('checked', true);
        }
    });

    $('#article_trace').on('articleshow', function () {//轨迹页面每次展示调用

        var map = new BMap.Map('container');// 创建地图实例
        map.addControl(new BMap.NavigationControl());
        map.addControl(new BMap.ScaleControl());
        map.addControl(new BMap.OverviewMapControl());
        map.addControl(new BMap.MapTypeControl());
        iniLocation();
        hideLbsUnread();

        function hideLbsUnread() {
            setDeviceUnread(getCurrentDeviceX('device_id'), 'unreadLocation', false);
            $('#unread_location').hide();
        }
    });
}


})();

//各种全局函数：
function redirectToCardCenter() {
    setTimeout(function () {
        document.location = 'card_center_page';
    }, 800);//有点延迟才友善
}

function getCurTs(){var a=(new Date).valueOf()+"",b=a.substr(0,a.length-3);return b}

function defaultFailCallback(){
  A.showToast('网络错误');
}

function defaultMiddleware(data){
    if (data.errcode==110) {
      A.showToast(data.errmsg);
      setTimeout(function () {
        document.location = 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_card&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect';
    }, 800);
  }
}

function getHeadPicByDeviceId(deviceId) {
    var url = default_device_pic_url;
    for (var i = 0; i < user_bind_deivce_obj.data.devices.length; i++) {
        if (deviceId == user_bind_deivce_obj.data.devices[i].device_id) {
            url = user_bind_deivce_obj.data.devices[i].picture;
            break;
        }
    }
    return url;
}


function getIndexByDeviceId(deviceId) {
    var index = null;
    for (var i = 0; i < user_bind_deivce_obj.data.devices.length; i++) {
        if (deviceId == user_bind_deivce_obj.data.devices[i].device_id) {
            index = i;
            break;
        }
    }
    return index;
}

function getCurrentActiveSectionId() {
    return $('section.active').attr('id');
}

function getCurrentDeviceLocation() {
    var str = user_bind_deivce_obj.data.devices[current_device_position].location;
    var obj = eval('(' + str + ')');
    if (obj.LAT_B != undefined && obj.LAT_B != '' && obj.LAT_B != null) {
        return obj;
    }
    return false;
}

function getCurrentDeviceX(x) {
    return user_bind_deivce_obj.data.devices[current_device_position][x];//不存在x属性就返回undefined
}

//handle succ result callback area:
function defaultSuccCallback(data) {
    if (data.errcode != 0) A.showToast(data.errmsg);
}

function handleQueryDevice(data) {
    if (data.errcode != null) {
        user_bind_deivce_obj = data;
        if (user_bind_deivce_obj.data.devices.length != 0) {
            //添加设备到列表
            ulAddLi();
            iniDeviceUnreadArr();
            if (current_device_position != -1) {
                refrehDeviceDetial();
            }
        }
    }

    //获取设备后添加到ul listview中
    function ulAddLi() {
        var refresh = A.Refresh('#article_cardcenter');
        var ul = $('#lv_device');
        ul.html('');//先清空ul
        var arr = user_bind_deivce_obj.data.devices;
        var len = arr.length;
        var li='';
        for (var i = 0; i < len; i++) {
            var nick = arr[i].nick||'未设置昵称';
            var device_id = arr[i].device_id;
            var picture = arr[i].picture||default_device_pic_url;
            var child='';
            if (arr[i].device_type=='kqk') {
            var child = '<li style="position:relative;" class="li_device" position="' + i + '" ><div class="img appimg"><img class="am-circle head-sm" src="' + picture + '" /><i id="unread_li' + device_id + '" class="unread view-hide"></i></div><i class="icon-color-blue ricon iconline-arrow-right"></i><div class="text">' + nick + '<small>考勤卡<br>' +device_id+ '</small></div> <span id="spsos_' + device_id + '" class="spsos view-hide">SOS</span></li>';
            }else{
            var status = arr[i].status ==1?'已开机':'已关机';
            var volume = arr[i].volume||'0';
            var electricity = arr[i].electricity||'0';
            var child = '<li style="position:relative;" class="li_device" position="' + i + '" ><div class="img appimg"><img class="am-circle head-sm" src="' + picture + '" /><i id="unread_li' + device_id + '" class="unread view-hide"></i></div><i class="icon-color-blue ricon iconline-arrow-right"></i><div class="text">' + nick + '<small>' + status + '<br>电量：' + electricity + ' | 音量：' + volume + '<br>'+device_id+'</small></div> <span id="spsos_' + device_id + '" class="spsos view-hide">SOS</span></li>';
            }
            li+=child;
        }
        ul.append(li);
        refresh.refresh();
    }

    function iniDeviceUnreadArr() {
        deviceUnreadArr = [];
        var arr = user_bind_deivce_obj.data.devices;
        var len = arr.length;
        for (var i = 0; i < len; i++) {
            if (arr[i].device_type != 'kqk') {
                deviceUnreadArr[arr[i].device_id] = new DeviceBean();
            }
        }
    }

    function DeviceBean() {
        this.unreadVoice = false;//未读语音消息
        this.unreadLocation = false;//未读定位
        this.bindPhoneList = null;//绑定的设备列表
    }
}

//tag=daily\sunday\saturday
function getLimitTimeByTag(tag) {
    var daily11 = $('#' + tag + '11').val();
    var daily12 = $('#' + tag + '12').val();
    var daily21 = $('#' + tag + '21').val();
    var daily22 = $('#' + tag + '22').val();
    var daily31 = $('#' + tag + '31').val();
    var daily32 = $('#' + tag + '32').val();
    var daily41 = $('#' + tag + '41').val();
    var daily42 = $('#' + tag + '42').val();
    return daily11 + '-' + daily12 + ';' + daily21 + '-' + daily22 + ';' + daily31 + '-' + daily32 + ';' + daily41 + '-' + daily42;
}


//获取绑定此设备的手机号
function getBindPhoneByImei() {
    if (getCurrentDeviceX('device_type') == 'kqk') {
        return;
    }//考勤卡不需要查询
    if (deviceUnreadArr[getCurrentDeviceX('device_id')].bindPhoneList != null) {
        //防止每次都查询，但是需要刷新select
        handleGetBindPhoneByImei(deviceUnreadArr[getCurrentDeviceX('device_id')].bindPhoneList);
        return;
    }

    if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {
        ajax_get('/getBindPhoneByImei?imei=' + getCurrentDeviceX('device_id'), handleGetBindPhoneByImei);
    }

    function handleGetBindPhoneByImei(data) {
    var select1 = document.getElementById('select_1');//按键1选择框
    var select2 = document.getElementById('select_2');//按键2选择框
    var select3 = document.getElementById('select_3');//按键3选择框
    select1.options.length = 1;//清空select
    select2.options.length = 1;
    select3.options.length = 1;
    if (data.errcode == 0) {
        var arr = data.data;

        for (var i = 0; i < arr.length; i++) {
            if (!jsSelectIsExitItem(select1, arr[i].userphone)) {
                addSelect(select1, arr[i].userphone, arr[i].userphone);
                addSelect(select2, arr[i].userphone, arr[i].userphone);
                addSelect(select3, arr[i].userphone, arr[i].userphone);
            }
        }
        setKeypressState();//设置学生卡按键选中项

        setDeviceUnread(getCurrentDeviceX('device_id'), 'bindPhoneList', data);
    } else {
        A.showToast(data.errmsg);
    }
}
}


/*
 * @param toggleId 元素id
 * @param state 是否需要选中 0/1
 * 设置toggle state
 */
 function setToggleState(toggleId, state) {
    var isToggleActive = getIsToggleActive(toggleId);
    if (state == 0) {
        if (isToggleActive == 1) {
            $('#' + toggleId).removeClass('active');
        }
    } else {
        if (!isToggleActive) {
            $('#' + toggleId).addClass('active');
        }
    }
}

function submitManageSettings(){
    if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {
        var quick_dial = select_1.value + ',' + select_2.value + ',' + select_3.value;
        var volume = $('#select_volume').find('input[name="volume"]:checked').val();
        volume = volume == undefined ? 0 : volume;//电脑端可取消点击问题& 服务器端0-6

        var work_mode = $('#select_workmode').find('input[name="wm"]:checked').val();
        work_mode = work_mode || 1;

        var url='';
        if (getCurrentDeviceX('work_model')==work_mode)
           url='/submitManageSettings?quick_dial=' + quick_dial + '&volume=' + volume + '&imei=' + getCurrentDeviceX('device_id');
        else
        url='/submitManageSettings?quick_dial=' + quick_dial + '&volume=' + volume + '&work_mode=' + work_mode + '&imei=' + getCurrentDeviceX('device_id');
        
        ajax_get(url,handlerSubmitManageSettings);
    }
    function handlerSubmitManageSettings(data) {
        if (data.errcode == 0) {
            setTimeout(function () {
                ajax_get('/queryDevice', handleQueryDevice);
            }, 500);//有点延迟才友善

        } else {
            A.showToast(data.errmsg);
        }
    }
}

function submitToggleAttendance() {
    var isToggleActive = getIsToggleActive('toggle_attendance');
    if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {
        var obj = user_bind_deivce_obj.data.devices[current_device_position];
        var attendance_notice = obj.flag_attendance_notice == 1 ? 1 : 0;//到离校通知1开启
        if (isToggleActive != attendance_notice) {//如果没变化就不提交，变化了提交
            ajax_get('/submitToggleAttendance?flag=' + isToggleActive + '&imei=' + getCurrentDeviceX('device_id'));//暂时不需要成功提示
            obj.flag_attendance_notice = isToggleActive;
        }
    }
    A.showToast('提交完成');
}

//@return 1=true,0=false
function getIsToggleActive(toggleId) {
    if ($('#' + toggleId).hasClass('active')) {
        return 1;
    }
    return 0;
}

//设置学生卡按键选中项
function setKeypressState() {
    var select1 = document.getElementById('select_1');//按键1选择框
    var select2 = document.getElementById('select_2');//按键2选择框
    var select3 = document.getElementById('select_3');//按键3选择框

    if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {
        var quick_dial = getCurrentDeviceX('quick_dial');
        if (quick_dial) {
            var arr = quick_dial.split(',', 3);
            setSelectedItem(select1, arr[0]);
            if (arr.length > 1) {
                setSelectedItem(select2, arr[1]);
            }
            if (arr.length > 2) {
                setSelectedItem(select3, arr[2]);
            }
        } 

    }
}

/*
 * 自定义一个select添加器 js版
 * @param select 选择器对象
 * @param value 值
 * @param text 展示的名字
 */
 function addSelect(select, value, text) {
    var varItem = new Option(text, value);
    select.options.add(varItem);
}

/*
 * 判断select选项中 是否存在Value="paraValue"的Item js版
 * @return boolean true 存在，false 不存在
 */
 function jsSelectIsExitItem(objSelect, objItemValue) {
    var isExit = false;
    for (var i = 0; i < objSelect.options.length; i++) {
        if (objSelect.options[i].value == objItemValue) {
            isExit = true;
            break;
        }
    }
    return isExit;
}

/*
 * 如果select选项中存在制定text，将其设置为选中
 * @return boolean true 设置成功，false 不存在
 */
 function setSelectedItem(objSelect, objItemText) {
    for (var i = 0; i < objSelect.options.length; i++) {
        if (objSelect.options[i].text == objItemText) {
            objSelect.options[i].selected = true;
            return true;
        }
    }
    return false;
}


//当主界面点击设备进入详情和提交按键绑定的时候需要刷新
function refrehDeviceDetial() {
    changeDeviceDetail();
    initViewByDeviceType();

    //修改设备详情页面
    function changeDeviceDetail() {
        if (user_bind_deivce_obj != null && user_bind_deivce_obj.data.devices.length > current_device_position) {
            var obj = user_bind_deivce_obj.data.devices[current_device_position];
            var nick = obj.nick||'未设置昵称';
            
            var picture = obj.picture|| default_device_pic_url;
            $('#img_device_main_head').attr('src', picture);
            $('#title_device_main').html(nick);
            if (obj.device_type=='kqk') {
                $('#device_main_status').html('考勤卡');
                $('#device_main_electricity').html(obj.device_id);
            }else{
            var electricity = obj.electricity||'0';
            var status = obj.status ==1?'已开机':'已关机';
            $('#device_main_status').html(status);
            $('#device_main_electricity').html('电量：' + electricity);
            }
            

            if (!isShowAudioRecord) {
                var num=user_bind_deivce_obj.data.devices.length * 15;
                getChatFromDb(card_loginName,num);
                isShowAudioRecord=true;
            }
            hideOtherDeviceChat();
        }
    }


function getChatFromDb(phone,num){
    console.log('getChatFromDb');
  if (db!=null){
    if (num==undefined) {
      num=15;
    }
    try{
      db.transaction(function (context) {
       context.executeSql('SELECT * FROM card_chat where phone=? ORDER BY 1 DESC LIMIT 0, '+num, [phone], function (context, results) {
        var len = results.rows.length, i;
        var nameArr=[];
        if (len>0) {
            var deviceArr=user_bind_deivce_obj.data.devices;
            var length=deviceArr.length;
            for (var i = 0; i < length; i++) {
                nameArr[deviceArr[i].device_id]=deviceArr[i].nick;
            }
        }
        for (i = 0; i < len; i++){//这里消息id简单的用主键吧..
            var queryObj=results.rows.item(i);
            var toDeviceId=queryObj.deviceId;
            var msgType=queryObj.message_type;
            var headimgurl=default_owner_pic_url;
            var tm=queryObj.tm+'';
            var nickname='';
            if (msgType==TEXT_ME) nickname='我';
            else{
                nickname=nameArr[toDeviceId]||queryObj.from_nick;
                headimgurl=getHeadPicByDeviceId(toDeviceId);
            }
            writeToChatLog(queryObj.audio_url,msgType,nickname,tm,headimgurl,queryObj.id,toDeviceId,true,true);
       }
       hideOtherDeviceChat();
     });
     });
    }catch(e){
      console.log(e);
    }
  }
}

    function hideOtherDeviceChat() {
        var scroll = A.Scroll('#article_device_main');
        var deviceId = getCurrentDeviceX('device_id');
        $('.' + deviceId).show();
        for (var i = 0; i < user_bind_deivce_obj.data.devices.length; i++) {
            if (deviceId != user_bind_deivce_obj.data.devices[i].device_id) {
                $('.' + user_bind_deivce_obj.data.devices[i].device_id).hide();
            }
        }
        scroll.refresh();
    }

    //判断当前用户是否绑定语音按键
    function isKeySelectBind() {
        var quick_dial = getCurrentDeviceX('quick_dial');
        if (quick_dial) {
            if (quick_dial.indexOf(card_loginName) >= 0) {
                return true;
            }
        }
        return false;
    }

    function initViewByDeviceType() {
        if (getCurrentDeviceX('device_type') != 'kqk') {
            $('#btn_location').show();
            //audio_area
            if (isKeySelectBind()) {
                $('#audio_area').show();
                $('#btn_setKeySelect').hide();
            } else {
                $('#audio_area').hide();
                $('#btn_setKeySelect').show();
            }
            //unread
            if (deviceUnreadArr[getCurrentDeviceX('device_id')].unreadLocation) {
                $('#unread_location').show();
            } else {
                $('#unread_location').hide();
            }

            setDeviceUnread(getCurrentDeviceX('device_id'), 'unreadVoice', false);

            $('#btn_school_manage').show();
            $('#btn_remote_shutdown').show();
            $('#form_volume').show();
            $('#form_key_phone').show();
            $('#form_workmode').show();

        } else {//考勤卡
            $('#btn_setKeySelect').hide();
            $('#audio_area').hide();
            $('#btn_school_manage').hide();
            $('#btn_location').hide();
            $('#btn_remote_shutdown').hide();
            $('#form_volume').hide();
            $('#form_key_phone').hide();
            $('#form_workmode').hide();
        }
    }
}

//提交设备编辑页面
function submitEditDevice() {

    var imei = $('#edit_imei').val();
    var pwd = $('#edit_pwd').val();
    var nick = $('#edit_nick').val();
    var sex = $('#radio_group_sex').find('input[name="sex"]:checked').val();//男、女
    var pic = $('#iconInfos').val();//男、女

    if (imei =='' || nick =='') {
        A.showToast('设备信息未填写完整');
        return;
    }
    if (current_edit_type == TYPE_DEVICE_EDIT) {//编辑设备
        ajax_submitEditDevice(imei, pwd, nick, sex, pic, 2);

    } else {//undefined 添加设备
        if (pwd =='') {
            A.showToast('未输入设备密码');
            return;
        }
        ajax_submitEditDevice(imei, pwd, nick, sex, pic, 1);
    }
}

//type=1添加2编辑
function ajax_submitEditDevice(imei, pwd, nick, sex, pic, type) {
    if (imei != '' && nick != '' && sex != '' && pic != '') {
        //type=1添加2编辑
        var url = '/submitEditDevice?imei=' + imei + '&nick=' + nick + '&pwd=' + pwd + '&sex=' + sex + '&pic=' + pic + '&type=' + type;
        ajax_get(url, handleSubmitEditDevice);
    }

    function handleSubmitEditDevice(data) {
        if (data.errcode == 0) {
            A.showToast('提交成功');
            redirectToCardCenter();
        } else {
            A.showToast(data.errmsg);
        }
    }
}


//初始化地理位置
function iniLocation() {
    var map = new BMap.Map('container');// 创建地图实例
    var obj = getCurrentDeviceLocation();

    if (obj) {
        if (obj.update_time != undefined && obj.update_time != null) {
            if (obj.type == undefined || obj.type == '') {
                obj.type = 'LBS'
            }
            $('#location_update_time').html('<strong>时间：</strong>' + obj.update_time + '，<strong>定位：</strong>' + obj.type);
        }
        LocalMap(obj.LNG_B, obj.LAT_B, getCurrentDeviceX('location_zh'));
        // LocalMap('116.404','39.915',getCurrentDeviceLocationZH());

    } else {
        ShenZhen();
    }

    //默认定位到深圳
    function ShenZhen() {
        map.centerAndZoom('深圳', 12);
    }

    function addCircle(mPoint) {
        var circle = new BMap.Circle(mPoint, 1000, {
            strokeColor: '#03ABF9',
            fillColor: '#03ABF9',
            strokeWeight: 1,
            fillOpacity: 0.15,
            strokeOpacity: 0.8
        });
        map.addOverlay(circle);
    }

    /*
     * @param content 中文地理位置
     */
     function LocalMap(lng, lat, content) {
        map.clearOverlays();
        // lng = parseFloat(lng) + 0.01185;//经度校正
        // lat = parseFloat(lat) + 0.00328;//纬度校正
        var point = new BMap.Point(parseFloat(lng), parseFloat(lat));
        map.centerAndZoom(point, 15);//centerAndZoom必不可少！！！
        map.enableScrollWheelZoom(true);

        var marker = new BMap.Marker(point);
        map.addOverlay(marker);//标注添加

        addCircle(point);//圆形区域

        // marker.setAnimation(BMAP_ANIMATION_BOUNCE); //标记点跳动效果
        if (content =='' || content == undefined) {
            var geoc = new BMap.Geocoder();
            geoc.getLocation(point, function (rs) {
                var addComp = rs.addressComponents;
                content = addComp.province +
                addComp.city +
                addComp.district +
                addComp.street +
                addComp.streetNumber;
                addClickHandler(content, marker);
                setLocationLabel(content);
            })

        } else {
            addClickHandler(content, marker); //如果数据库存在位置信息则调用数据库的位置信息
            setLocationLabel(content);
        }

        function setLocationLabel(content) {
            $('#location_msg').html('<strong>所在位置：</strong>' + content + '附近');
        }

        function addClickHandler(content, marker) {
            marker.addEventListener('click', function (e) {
                openInfo(content, e)
            }
            );
        }

        function openInfo(content, e) {
            var opts = {
                width: 250,     // 信息窗口宽度
                height: 80,     // 信息窗口高度
                title: '所在位置', // 信息窗口标题
                enableMessage: true//设置允许信息窗发送短息
            };
            var p = e.target;
            var point = new BMap.Point(p.getPosition().lng, p.getPosition().lat);
            var infoWindow = new BMap.InfoWindow(content + '附近', opts);  // 创建信息窗口对象
            map.openInfoWindow(infoWindow, point); //开启信息窗口
        }
    }
}

// });
