/**
* @author hgx 160224
* last modify 160227
*/
        function defaultMiddleware(data){
            if (data.code==-1) {
                A.showToast(data.msg);
            }else if (data.code==110) {
                setTimeout(function(){
                    document.location = 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_jxt&response_type=code&scope=snsapi_base&state=SUISHI';
                },800);
                A.showToast(data.msg);
            }
        }
        (function() {
            var isSubjectGot=false;
            var select = document.getElementById('select_device');

            getDeviceList();
            clickEvent();
            articleEvent();

    //全局函数
    function addSelect(select, value, text) {
        var varItem = new Option(text, value);
        select.options.add(varItem);
    }
    function jsSelectIsExitItem(objSelect, objItemValue) {
        var isExit = false;
        for (var i = 0; i < objSelect.options.length; i++) {
            if (objSelect.options[i].value == objItemValue) {
                isExit = true;
                break;
            }
        }
        return isExit;
    }

    function cardText(text){
        return '<div class="jumbotron raise padded"><div class="left-block"nowrap></div><div class="ml">'+text+'</div></div>';
    }

    function getDeviceList() {
        ajax_get('/jxt/queryDevice', function(data) {
            var len = data.data.length;
            var arr = data.data;
            if (len > 0) {
                select.options.length = 0;
                //清空select
                for (var i = 0; i < len; i++) {
                    if (!jsSelectIsExitItem(select, arr[i].device_id)) {
                        addSelect(select, arr[i].device_id, arr[i].device_name);
                    }
                }

                $('#select_device_sp').html(arr[0].device_name);

            }
        });

    }
    
            function getHomework(deviceid,subject) {
                if (!deviceid) {A.showToast('请先选择设备');return;}
                if (!subject) {return;};
                $('#container_homework').html('');
                ajax_get('/jxt/queryHomework?deviceid=' + deviceid+'&subject='+subject, function(data) {
                    if(data.msg) $('#container_homework').html(cardText(data.msg));
                    if (data.code!=0) return;
                    if (data.data) {
                        var html=addHomework(data.data.subject,data.data.content,data.data.ctime);
                    $('#container_homework').html(html);
                    }else{
                       $('#container_homework').html(cardText('暂无作业')); A.showToast('暂无作业');
                    }
                });
            }

            function addHomework(subject,content,ctime){
                content=content.replace(/\r\n/g, '<br/>');
                return '<div class="jumbotron raise padded"><div class="left-block"nowrap></div><div class="ml"><i class="iconfont iconline-pin fr color-blue"></i><br/><div><label>'+subject+'</label>&nbsp;<small>'+ctime+'</small></div><hr/><div class="mt"><strong class="line-height">'+content+'</strong></div></div></div>';
            }

    function articleEvent() {

        $('#article_homework').on('articleload', function() {

            document.getElementById('select_subject').onchange = function(){
                if (this.value!='') $('#select_subject_sp').html(this.options[this.selectedIndex].text);
                else $('#select_subject_sp').html('选择科目');
                $('#container_homework').html('');
                getHomework(select.value,this.value);
            };

        });

        $('#article_homework').on('articleshow', function() {
            if (!isSubjectGot) getSubjectList(select.value);

            function getSubjectList(deviceid) {
                if (!deviceid) {A.showToast('请先选择设备');return;}
                ajax_get('/jxt/querySubject?deviceid=' + deviceid, function(data) {
                    if(data.msg) $('#container_homework').html(cardText(data.msg));
                    if (data.code!=0) return;
                    isSubjectGot=true;
                    var len = data.data.length;
                    var arr = data.data;
                    if (len > 0) {
                        var select_subject = document.getElementById('select_subject');
                        select_subject.options.length = 0;
                        for (var i = 0; i < len; i++) {
                            if (!jsSelectIsExitItem(select_subject, arr[i].device_id)) {
                                addSelect(select_subject, arr[i], arr[i]);
                            }
                        }
                        $('#select_subject_sp').html(arr[0]);
                        getHomework(select.value,arr[0]);
                    }else {
                        $('#select_subject_sp').html('无科目可选');
                        A.showToast('无科目可选');
                    }
                });
            }

        });
    }

    function clickEvent() {

        select.onchange=function(){
            if (this.value!='') $('#select_device_sp').html(this.options[this.selectedIndex].text);
            else $('#select_device_sp').html('选择学生卡');
            reIniViews();

            function reIniViews(){
                isSubjectGot=false;
                $('#container_homework').html('');
                $('#select_subject_sp').html('选择科目');
                $('#container_notice').html('');
                document.getElementById('select_subject').options.length = 0;
            }
        };

        $('#refresh').on(A.options.clickEvent, function() {
            location.reload();
            return false;
        });
        $('#btn_contact').on(A.options.clickEvent, function() {
            A.Controller.section('#section_contact');
            getContact(select.value);
            function getContact(deviceid) {
                if (!deviceid) {A.showToast('请先选择设备');return;}
                $('#container_contact').html('');
                ajax_get('/jxt/queryContact?deviceid=' + deviceid, function(data) {
                    if(data.msg) $('#container_contact').html(cardText(data.msg));
                    if (data.code!=0) return;
                    var arr=data.data;
                    var len=arr.length;
                    if (len>0) {
                        var html='';
                        for (var i = 0; i <len; i++) {
                            html+=addContact(arr[i].subject,arr[i].name,arr[i].phone,arr[i].note);
                        }
                        $('#container_contact').html(html);
                    }else{$('#container_contact').html(cardText('暂无联系方式'));A.showToast('暂无联系方式');}
                });

                function addContact(subject,name,phone,note) {
                    var master='';
                    if (note) master='（'+note+'）';
                    return '<div class="jumbotron raise padded"><div class="left-block"nowrap></div><div class="ml"><i class="iconfont iconline-tag fr color-blue"></i><br/><div>'+subject+'老师'+master+'：<label>'+name+'</label></div><br/><div>手机号：<label><a data-toggle="html" href="tel:'+phone+'">'+phone+'</a></label></div></div></div>';
                }
            }
            return false;
        });
        $('#btn_grade').on(A.options.clickEvent, function() {
            A.Controller.section('#section_grade');
            getGrade(select.value);

            function getGrade(deviceid){
                if (!deviceid) {A.showToast('请先选择设备');return;}
                $('#container_grade').html('');
                ajax_get('/jxt/queryAllScore?deviceid=' + deviceid, function(data) {
                    if(data.msg) $('#container_grade').html(cardText(data.msg));
                    if (data.code!=0) return;
                    var arr=data.data;
                    var len=arr.length;
                    if (len>0) {
                        var html='';
                        for (var i = 0; i <len; i++) {
                            html+=addGrade(arr[i].subject,arr[i].ctime,arr[i].note,arr[i].score);
                        }
                        $('#container_grade').html(html);
                    }else{$('#container_grade').html(cardText('暂无成绩'));A.showToast('暂无成绩记录');}
                });

                function addGrade(subject,ctime,note,score) {
                    return '<div class="jumbotron raise padded"><div class="left-block"nowrap></div><div class="ml"><i class="iconfont iconline-badge fr color-blue"></i><br/><div class="color-gray">'+ctime+'&nbsp;'+note+'</div><br/><div>'+subject+'：<label>'+score+'分</label></div></div></div>';
                }
            }
            return false;
        });
        $('#btn_homework').on(A.options.clickEvent, function() {
            A.Controller.section('#section_homework');
            return false;
        });

        $('#btn_notice').on(A.options.clickEvent, function() {
            A.Controller.section('#section_notice');
            getNotice(select.value);

            function getNotice(deviceid){
                if (!deviceid) {A.showToast('请先选择设备');return;}
                $('#container_notice').html('');
                ajax_get('/jxt/queryNotice?deviceid=' + deviceid,function(data){
                    var html=cardText('暂无通知');
                    if (data.data) {
                        html=addNotice(data.data.content,data.data.ctime,data.data.from);
                    }else if(data.msg){
                        html=cardText(data.msg);
                    }else{
                        A.showToast('暂无通知');
                    }
                    $('#container_notice').html(html);
                    
                });

                function addNotice(content,ctime,fromUser){
                    content=content.replace(/\r\n/g, '<br/>');
                    return '<div class="jumbotron raise padded"><div class="left-block"nowrap></div><div class="ml"><i class="iconfont iconline-attach fr color-blue"></i><br/><div><label>'+fromUser+'</label>&nbsp;<small>'+ctime+'</small></div><hr/><div class="mt"><strong class="line-height">'+content+'</strong></div></div></div>';
                }
            }
            return false;
        });
    }
})();