<?php
/**
 * Mongo Exception
 *
 * @author Liu <q@yun4s.cn>
 */
class RMongoException extends MongoException {
	
}

?>