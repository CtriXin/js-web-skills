<?php
if(!isset($_SESSION)){
	session_start();  
}  

?>
<!-- 首页 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<!-- 自动探测电话号码 -->
	<meta name="format-detection" content="telephone=no">
	<meta http-equiv="x-rim-auto-match" content="none">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<title>学生卡</title>
	<link rel="stylesheet" href="assets/agile/css/agile.layout.css">
	<link rel="stylesheet" href="assets/agile/css/ratchet/css/ratchet.min.css">
	<link rel="stylesheet" href="assets/agile/css/flat/flat.component.css">
	<link rel="stylesheet" href="assets/agile/css/flat/flat.color.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconline.css">
	<link rel="stylesheet" href="assets/app/css/app.css">

	<link rel="stylesheet" href="assets/agile/css/flat/iconline.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconform.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconlogo.css">

	<style>
		.am-circle{ display:inline-block;-webkit-border-radius: 90px;border: 1px solid #424242;overflow: hidden; line-height:0;margin-right:20px;}
		.outer { border:1px solid #ccc; }

	</style>

</head>
<body>
	<div id="section_container">
		<section id="section_cardcenter" data-role="section" class="active">
			<header class="bar bar-nav">

					<h1 class="title">个人中心</h1>
				</header>
				<article data-role="article" id="article_cardcenter" data-scroll="verticle" class="active" style="top:44px;bottom:50px;">

					<div class="scroller">

						<form class="form-group">

							<div  class="card" style="background-color: #10A0EA;">
								<div style="padding: 8px ;">
									<img class="am-circle" src="http://img.alicdn.com/bao/uploaded/i1/TB17ppKHVXXXXb9XXXXXXXXXXXX_!!0-item_pic.jpg_240x240.jpg" width="100" height="100" style="float: left;margin-top: 10px" />
									&nbsp;&nbsp;&nbsp;&nbsp;<div id="user_name" style="margin-left: 110px;color: #FEFFFF"><?php echo $_SESSION['card_loginName'];?>
									<span id="sp_card_change" style="float: right" class="iconfont iconline-rdo-right">切换</span>
								</div>

								&nbsp;&nbsp;&nbsp;&nbsp;<div id="card_status" style="margin-left: 110px;color: #FEFFFF">努力加载中...</div>
							</div>
							<div id="time_type" style="margin-left: 10px;color: #FEFFFF">努力加载中...</div>
							<div id="last_location" style="margin-left: 10px;color: #FEFFFF">努力加载中...</div>
						</div>
					</form>


					<form class="form-group">

						<div class="card">
							<ul class="listitem">

								<li id="li_msg">
									<i class="icon-color-blue icon iconfont iconline-bell"></i>
									<i class="icon-color-blue ricon iconfont iconline-arrow-right"></i>
									<div class="text">消息中心</div>
								</li>
								<li id="li_voice">
									<i class="icon iconfont iconline-chat-bubble"></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">语音聊天</div>
								</li>
								<li id="li_card_manage">
									<i class="icon iconfont iconline-user-group"></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">学生卡管理</div>
								</li>

								<li id="li_trace">
									<i class="icon iconfont iconline-map-location" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">及时追踪</div>
								</li>
								<li id="li_phone_edit">
									<i class="icon iconfont iconline-notebook" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">号码管理</div>
								</li>
								<li id="li_kaoqin">
									<i class="icon iconfont iconline-week" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">查询考勤</div>
								</li>
								<li id="li_school_manage">
									<i class="icon iconfont iconline-cap-graduation" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">校园管理</div>
								</li>
								<li id="li_device_state">
									<i class="icon iconfont iconline-bulb" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">设备状态</div>
								</li>
								<li id="li_help_info">
									<i class="icon iconfont iconline-plugin" style=""></i>
									<i class="ricon iconfont iconline-arrow-right"></i>
									<div class="text">帮助信息</div>
								</li>
							</ul>
						</div>
					</form>

					</div>						
				</article>


				<article data-role="article" id="article_settings" data-scroll="verticle" style="top:44px;bottom:50px;">

					<div class="scroller">

						<form class="form-group">

							<div>settings</div>
					</form>

				</div>						
			</article>


			<!-- 底部tab -->
			<nav class="bar bar-tab">
				<a id="weituo_tab" class="tab-item active" data-role="tab" data-toggle="article" href="#article_cardcenter">
					<span class="icon icon-person"></span>
					<span class="tab-label">中心</span>
				</a>

				<a id="settings_tab" class="tab-item" data-role="tab" data-toggle="article" href="#article_settings">
					<span class="icon icon-gear"></span>
					<span class="tab-label">设置</span>
				</a>
			</nav> 


		</section>


		<section id="section_msgcontent" data-role="section" >
			<!-- 消息中心 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">消息中心</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">暂无消息</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>
		
		<section id="section_voice" data-role="section" >
			<!-- 语音聊天 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">语音聊天</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">语音聊天</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>

		<section id="section_card_manage" data-role="section" >
			<!-- 学生卡管理 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">学生卡管理</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">学生卡管理</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>

		<section id="section_school_manage" data-role="section" >
			<!-- 校园管理 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">校园管理</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">校园管理</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>

		<section id="section_device_state" data-role="section" >
			<!-- 设备状态 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">设备状态</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">设备状态</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>

		<section id="section_help_info" data-role="section" >
			<!-- 帮助信息 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">帮助信息</h1>
			</header>

			<article data-role="article" id="article_msgcontent" class="active" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="font-weight:bold;"  id="list_noMsg">帮助信息</div>
					<ul class="listitem" id="list_msg"></ul>
				</div>
			</article>
		</section>

		<section id="section_trace" data-role="section" >
			<!-- 及时追踪 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">及时追踪</h1>
			</header>

			<article data-role="article" class="active" id="article_trace" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<h5 class="content-sub-heading" id="dingweiMain">
						<!-- <button class="btn btn-red waves-button waves-light waves-effect" id="dingwei" type="button" data-theme="b">刷新定位</button> -->
					</h5>
					<div id="container" style="height:500px"></div>

				</div>
			</article>
		</section>

		<section id="section_phoneedit" data-role="section" >
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">号码管理</h1>
			</header>

			<!-- 号码管理 -->
			<article data-role="article" class="active" id="article_phoneedit" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title">紧急求助号码</div>
					<form autocomplete="off" oninput="range_output.value=parseInt(range.value)" class="form-common">
						<label class="label-left" for="user">号码1：</label>
						<label class="label-right">
							<input id="user" type="text" placeholder="输入求助号码"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr style="margin-left: 8px;margin-right: 8px;margin-top: 0px;margin-bottom: 0px" />
						<label class="label-left" for="user">号码2：</label>
						<label class="label-right">
							<input id="user" type="text" placeholder="输入求助号码"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr style="margin-left: 8px;margin-right: 8px;margin-top: 0px;margin-bottom: 0px" />

						<label class="label-left" for="user">号码3：</label>
						<label class="label-right">
							<input id="user" type="text" placeholder="输入求助号码"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr style="margin-left: 8px;margin-right: 8px" />
						<label class="label-left" for="user">号码4：</label>
						<label class="label-right">
							<input id="user" type="text" placeholder="输入求助号码"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr/>

					</form>
					<div class="section-title">亲情电话号码</div>
					<form autocomplete="off" oninput="range_output.value=parseInt(range.value)" class="form-common">

						<label ><input id="user" type="text" placeholder="输入称呼"  title="输入称呼" required/></label>
						<label >
							<input id="user" type="text" placeholder="输入情亲号码1"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr/><br/>	
						<label ><input id="user" type="text" placeholder="输入称呼"  title="输入称呼" required/></label>
						<label >
							<input id="user" type="text" placeholder="输入情亲号码2"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr/><br/>	
						<label ><input id="user" type="text" placeholder="输入称呼"  title="输入称呼" required/></label>
						<label >
							<input id="user" type="text" placeholder="输入情亲号码3"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr/><br/>	
						<label ><input id="user" type="text" placeholder="输入称呼"  title="输入称呼" required/></label>
						<label >
							<input id="user" type="text" placeholder="输入情亲号码4"  onkeyup="value=value.replace(/[^\d]/g,'')" title="11位数字" required/>
						</label>
						<hr/><br/>	
					</form>
					<button class="block">保存并发送到儿童机</button>
				</div>
			</article>

		</section>

		<section id="section_kaoqin" data-role="section" >
			<!-- 查看考勤 -->
			<header class="bar bar-nav">
				<a class="icon icon-left-nav pull-left" data-toggle="back" href="#"></a>
				<h1 class="title">查看考勤</h1>
			</header>

			<article data-role="article" class="active" id="article_kaoqin" data-scroll="verticle" style="top:44px;bottom:50px;">

				<div class="scroller padded">

					<div class="section-title" style="border-bottom: 2px solid #888; font-weight:bold;">查看考勤</div>

				</div>
			</article>
		</section>



	</div>

		<!--- third --->
		<script src="assets/third/zepto/zepto.min.js"></script>
		<script src="assets/third/arttemplate/template-native.js"></script>	
		<script src="assets/third/jquery/jquery-2.1.3.min.js"></script>
		<script src="assets/third/jquery/jquery.mobile.custom.min.js"></script>
		<script src="assets/third/iscroll/iscroll-probe.js"></script>
		<script src="assets/third/arttemplate/template-native.js"></script>
		<!-- agile -->
		<script type="text/javascript" src="assets/agile/js/agile.js"></script>		
		<!--- bridge --->
		<script type="text/javascript" src="assets/bridge/exmobi.js"></script>
		<script type="text/javascript" src="assets/bridge/agile.exmobi.js"></script>
		<!-- app -->
		<script type="text/javascript" src="assets/app/js/app.js"></script>

		<script type="text/javascript">
	//存放全局变量
	var card_userId="<?php echo $_SESSION['card_userId'];?>";//用户id
	var card_loginName='<?php echo $_SESSION['card_loginName'];?>';//登录用户名
	var card_terminalId='<?php echo $_SESSION['card_terminalId'];?>';//用户对应的设备id

	var card_last_location='';//最新状态记录，打开地图的时候直接使用，不需要重新获取
	var card_last_lat='';
	var card_last_lng='';
	var card_last_update_time='';

	// var map;//地图对象
</script>

<!-- baidu map -->
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=3c7ffcd0889bb67e543a2328f07964cd"></script>

<!-- card core-->
<script type="text/javascript" src="assets/app/js/card.js"></script>

</body>
</html>