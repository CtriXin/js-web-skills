<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>请假申请</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
 	 <script src="//cdn.bootcss.com/jquery/2.1.3/jquery.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.js"></script>
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.css">
	<!-- <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.1.0/css/amazeui.min.css"/> -->
	
</head>
<script type="text/javascript">
	function submit(){
		alert("提交成功");
	}
</script>
<body>
<div data-role="page" id="pageLogin" >
  <div  style="height:44px; background-color:#56B074 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#ffffff; font-size:16px; font-weight:bold;" >
    <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >请假申请</span>
  </div>
  <!-- // <script src="//cdn.amazeui.org/amazeui/2.1.0/js/amazeui.min.js"></script> -->
		<div data-role="content">
			<input type="text" name="ID" id="name" placeholder="请输入学生姓名">
			<input type="text" name="TITLE" id="pwd" placeholder="请输入监护人联系电话">
			<textarea class="" rows="5" cols ="5" id="doc-ta-1"  placeholder="请输入请假时间和原因等"></textarea>
						<div  id="submit" style=" display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; height:44px;font-size:20px; background-color:#489763; -webkit-border-radius:10px;">
			<div style="color: #ffffff;align:center;font-size: 22px;font-family:宋体,Georgia,Serif" onclick="submit();"> 提&nbsp;&nbsp;交</div></div>
		</div>
	</div> 


</body>


</html>