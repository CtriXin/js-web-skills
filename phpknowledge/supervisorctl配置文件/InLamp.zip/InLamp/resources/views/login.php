<!DOCTYPE html>
<html>
<head>
	<title>登录</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="static/css/login.css">
</head>
<body>
	<div class="container">
		<div class="logo">&nbsp;</div>
		<div class="content">
			<form action="" class="login">
				<h3 class="form-title">账户登录</h3>
				<div class="input">
					<div class="icon-user icon">&nbsp;</div>
					<!-- <div class="username">请输入用户名</div> -->
					<input type="text" value="请输入用户名" name="username" />
				</div>
				<br>
				<div class="input">
					<div class="icon-password icon"></div>
					<!-- <div class="password"> -->
					<input type="text" value="请输入密码" name="password" />
				</div>
				<br>
				<button class="submit" type="button" id="submit">提交</button>				
			</form>
		</div>
		<div class="copyright">
			Copyright&nbsp;&nbsp;2014 © 思路飞扬后台管理.
		</div>
	</div>
</body>
<script type="text/javascript" src="static/js/lib/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="static/js/login.js"></script>
</html>