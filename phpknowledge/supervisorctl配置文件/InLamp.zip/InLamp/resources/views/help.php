<!DOCTYPE html>
<html manifest="/hzsb.manifest">
<head>
  <meta charset="utf-8">
  <title>功能说明</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

<style type="text/css">
  #myImg{
    width:100%;
  }

</style>

  <!-- <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.1.0/css/amazeui.min.css"/> -->
  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.4.2/css/amazeui.min.css"/>

</head>
<body>
  <div id="pageLogin" >
    <div  style="height:44px; background-color:#E6E6E6 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#5EB95E; font-size:16px; font-weight:bold;" >
      <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >功能说明</span>
    </div>
  </div> 
  <br/>
<div class="am-u-sm-12 am-u-md-4 am-u-lg-3">
<div class="am-panel am-panel-primary">
<div class="am-panel-hd">1.切换学伴机</div>
<div class="am-panel-bd">
<div><img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/changeXBJ.png"
  alt="切换学伴机"
  />
  <p class="am-monospace">点击最上方的功能栏，再点击想要切换的学伴机即可。</p></div>
</div></div>
</div>
</div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3 am-u-md-offset-4 am-u-lg-offset-3">
<div class="am-panel am-panel-secondary" >
<div class="am-panel-hd">2.拍照</div>
<div class="am-panel-bd">
<div><img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/capture.png"
  alt="拍照"
  />
  <p class="am-monospace">小图拍的是标清图，大图拍的是高清图
</p><p class="am-monospace">
点击即可拍照
</p>
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/msgInfo.png"
  alt="拍照"
  /><p class="am-monospace">
拍照的请求发送过去后会进行提示
</p>
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/xbjbg.png"
  alt="拍照"
  /><p class="am-monospace">
拍到的图片会在这个区域内显示，照片只会拍到孩子正在写的作业，不会拍到人脸。
</p>
  </div>
  </div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3 am-u-md-offset-8 am-u-lg-offset-6">
<div class="am-panel am-panel-success" >
<div class="am-panel-hd">3.录音</div>
<div class="am-panel-bd">
<img id="myImgx"  style="width: 100px;height: 48px" src="http://7xkaou.com2.z0.glb.qiniucdn.com/record.png"
  alt="录音"
  /><p class="am-monospace">
点击录音按钮开始录音
</p>
<img id="myImgx" style="width: 100px;height: 48px"  src="http://7xkaou.com2.z0.glb.qiniucdn.com/send.png"
  alt="录音"
  /><p class="am-monospace">
点击发送按钮，完成并发送刚刚的录音
</p>
<img id="myImgx" style="width: 100px;height: 48px"  src="http://7xkaou.com2.z0.glb.qiniucdn.com/cancel.png"
  alt="录音"
  /><p class="am-monospace">
也可以点击放弃按钮，取消刚刚的录音
</p>
<img id="myImgx" style="width: 100px;height: 48px"  src="http://7xkaou.com2.z0.glb.qiniucdn.com/record_status.png"
  alt="录音"
  /><p class="am-monospace">
导航栏也会显示录音状态
</p>
</div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3 am-u-md-offset-8 am-u-lg-offset-9">
<div class="am-panel am-panel-warning" >
<div class="am-panel-hd">4.录音聊天记录</div>
<div class="am-panel-bd">
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/audio_chat.png"
  alt="录音"
  /><p class="am-monospace">
当前的聊天记录，会在【录音聊天记录】栏里显示
</p><p class="am-monospace">
信息包括发送人、时间以及录音。
</p>
</div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3 am-u-md-offset-8 am-u-lg-offset-6">
<div class="am-panel am-panel-danger" >
<div class="am-panel-hd">5.今天学习数据</div>
<div class="am-panel-bd">
<p class="am-monospace">
学习数据包括写字数、阅读量和学习时间
</p>
<img id="myImgx" style="width: 100px;height: 48px" src="http://7xkaou.com2.z0.glb.qiniucdn.com/refresh.png"
  alt="今天学习数据"
  />
  <p class="am-monospace">
数据不是实时更新的，所以要手动点击更新按钮
</p></div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3 am-u-md-offset-4 am-u-lg-offset-3">
<div class="am-panel am-panel-primary" >
<div class="am-panel-hd">6.学习统计图</div>
<div class="am-panel-bd">
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/chart_btn.png"
  alt="学习统计图"
  />
  <p class="am-monospace">
点击想要查看的数据，会显示相对应的当月统计数据
</p><img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/chart.png"
  alt="学习统计图"
  />
  <p class="am-monospace">
数据会以统计图的形式显示
</p>
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/calendar.png"
  alt="学习统计图"
  />
  <p class="am-monospace">
您还可以在此选择想查询的月份</p>
</div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3">
<div class="am-panel am-panel-secondary" >
<div class="am-panel-hd">7.设置</div>
<div class="am-panel-bd">
<img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/setting.png"
  alt="设置"
  />
  <p class="am-monospace">
您可以在此切换帐号和选择是否开启提示音</p>
</div></div>
</div></div>
<div class="am-g"><div class="am-u-sm-12 am-u-md-4 am-u-lg-3">
<div class="am-panel am-panel-success" >
<div class="am-panel-hd">8.其他</div>
<div class="am-panel-bd">
  <p class="am-monospace">
如有疑问，欢迎致电客服，或者在APP提交意见反馈</p>  <p class="am-monospace">
客服电话：</p>  <p class="am-monospace">
0755-32984123</p>  <p class="am-monospace">
0755-32985123</p>
</div></div>
</div>
<div style="text-align: center">
  <button data-am-smooth-scroll class="am-btn am-btn-primary"><span class="am-icon-level-up am-text-warning"></span>&nbsp;回到顶部</button>&nbsp;
<button onclick="history.go(-1);" class="am-btn am-btn-success"><span class="am-icon-mail-reply am-text-danger"></span>&nbsp;返回上页</button>

</div>
<br/>
</body>
  <script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
  <script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui2.x.min.js"></script>


</html>
