<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <title>孩在身边-密码找回</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.5.0/css/amazeui.min.css"/>

</head>
<body>
  <div data-role="page" id="pageLogin" >
    <div  style="height:44px; background-color:#E6E6E6 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#5EB95E; font-size:16px; font-weight:bold;" >
      <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >忘记密码</span>
    </div>
  </div> 
  <br>
  <div style="margin-top: 150px;margin: 10px;">

    <div class="am-input-group">
      <span class="am-input-group-label"><i class="am-icon-user am-icon-fw"></i></span>
      <input id="phone" type="tel" onkeyup="value=value.replace(/[^0-9]/g,'')" maxlength=11 class="am-form-field" placeholder="手机号" >
    </div>

    <div class="am-input-group">
      <span class="am-input-group-label"><i class="am-icon-lock am-icon-fw"></i></span>
      <input id="password" type="password" class="am-form-field" placeholder="新密码">
    </div>

    <div class="am-input-group">
      <span class="am-input-group-label"><i class="am-icon-lock am-icon-fw"></i></span>
      <input id="password2" type="password" class="am-form-field" placeholder="再次输入密码">
    </div>

    <div class="am-input-group"> 
      <span class="am-input-group-label"><i class="am-icon-envelope am-icon-fw"></i></span>
      <input id="checkCode" type="tel" class="am-form-field" placeholder="六位数字验证码" onkeyup="value=value.replace(/[^0-9]/g,'')" maxlength=6>
      <span class="am-input-group-btn">
        <button style="padding: 3px" id="btn_sendSMS" class="am-btn am-btn-warning am-btn-block doc-animations am-animation-shake" data-doc-animation="shake" type="button">发送验证码</button>
      </span>
    </div>
    <div><a id="login_url" href="/hzsb_login_page" style="float: right;margin: 8px">立即登录</a></div>
 <button id="btn_reset" type="button" style=" -webkit-border-radius:7px;" class="am-btn am-btn-success am-btn-block doc-animations am-animation-shake" data-doc-animation="shake">重置密码</button>

  </div>

  <button
  id="btn_myAlert"
  style="display: none;"
  type="button"
  class="am-btn am-btn-primary"
  data-am-modal="{target: '#my-alert',closeViaDimmer: 0}">
  Alert
</button>

<div class="am-modal am-modal-alert" tabindex="-1" id="my-alert">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">温馨提示</div>
    <div class="am-modal-bd" id="myAlert_value">

    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">确定</span>
    </div>
  </div>
</div>

</body>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui-2.5.0.min.js"></script>
<script type="text/javascript">

  var btn_sendSMS_obj=$('#btn_sendSMS');//发送验证码的对象
  var wait=0;//等待时间 
  var to_login_url='/hzsb_login_page_zhihui?r='+Math.random();
  checkLoginUrl();
  
  //验证码计数君
  function count() {
    if (wait == 0) { 
      btn_sendSMS_obj.removeAttr("disabled"); 
    btn_sendSMS_obj.text("发送验证码");//改变按钮中value的值 
  } else { 
      btn_sendSMS_obj.attr("disabled", true);//倒计时过程中禁止点击按钮 
      btn_sendSMS_obj.text(wait + "秒");//改变按钮中value的值 
      wait--;
      setTimeout('count()',1000);
    }
  } 

  function gotoLogin(){
    window.location.href=to_login_url;
  }

  //改变立即登录链接
  function checkLoginUrl(){
    if (GetRequest()['qr']=='1') {
      to_login_url='/hzsb_login_page_qr';
    }else if(GetRequest()['xsk']=='1') {
      to_login_url='/card_login_page';
    }else if(GetRequest()['jxt']=='1') {
      to_login_url='/jxt_login_page';
    }else{
      to_login_url='/hzsb_login_page_zhihui';
    }

    $('#login_url').attr('href',to_login_url);
  }

function GetRequest() {
var url = location.search;//获取url中"?"符后的字串
var theRequest = new Object();
if (url.indexOf("?") != -1) {
  var str = url.substr(1);
  strs = str.split("&");
  for(var i = 0; i < strs.length; i ++) {
    theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
  }
}
return theRequest;
}

  $(document).ready(function(){
    var progress = $.AMUI.progress;
    function startProgress(){
      progress.start();
    }
    function stopProgress(){
      progress.done();
    }


/*
* 自定义一个alert
* @param value
* @param closeViaDimmer是否可用通过点击外部关闭，默认不可以
*/
function myAlert(value){

  $("#myAlert_value").html(value);
  $('#btn_myAlert').click();
}



$('#btn_reset').click(function(){
  resetpwd();
});

btn_sendSMS_obj.click(function(){
    sendSMS();
  });

function sendSMS(){
  var phone=$('#phone').val().trim();
  if (phone.length!=11) {
    myAlert('手机号格式错误');
    return ;
  }

  ajax_sendSMS(phone);

}



function resetpwd(){

  var phone=$('#phone').val().trim();
  var password=$('#password').val().trim();
  var password2=$('#password2').val().trim();
  var checkCode=$('#checkCode').val().trim();

  if (phone.length!=11) {
    myAlert('手机号格式错误');
    return ;
  }

  if (password!=password2) {
    myAlert('两次输入密码不相同');
    return ;
  }

  if (checkCode.length!=6) {
    myAlert('验证码不是六位');
    return ;
  }

  if (password!='' &&password2!='') {
    startProgress();
    $("#btn_reset").attr("disabled", true);
    ajax_reset(phone,password,checkCode);
  }else{
    myAlert('密码为空');
  }
}

function ajax_reset(phone,password,checkCode){
  $.ajax({
    url:'hzsb_resetpwd?phone='+phone+'&password='+password+'&checkCode='+checkCode,
    type:"get",
    dataType: "json",
    success: function (data) {
      $("#btn_reset").attr("disabled", false);
      progress.done();
      if (data.code!='S000000') {
        if (data.msg!="") {
          myAlert(data.msg);
        }else{
            //未知错误
            myAlert("未知错误,请联系管理员");
          }
        }else{
          myAlert('密码重置成功，马上去登录..');
          setTimeout("gotoLogin()",1000);
        }
      },
      error: function (msg) {
        progress.done();
        $("#btn_reset").attr("disabled", false);
        myAlert("网络错误，请稍后重试");
      }
    });
}


function ajax_sendSMS(phone){
  $.ajax({
    url:'hzsb_sendSMS?phone='+phone+"&sendType=1",
    type:"get",
    dataType: "json",
    success: function (data) {
      if (data.code=='S000000') {
          //发送成功
          wait=60;//60s
          count();
        }else if (data.msg!="") {
          myAlert(data.msg);
        }else{
          //未知错误
          myAlert("未知错误,请联系管理员");
        }
      },
      error: function (msg) {
        btn_sendSMS_obj.attr("disabled", false);
        myAlert("网络错误，请稍后重试");
      }
    });
}

$(':button').click(function(){
  var a=$(this),i="am-animation-"+a.data("docAnimation");a.data("animation-idle")&&clearTimeout(a.data("animation-idle")),a.removeClass(i),setTimeout(function(){a.addClass(i),a.data("animation-idle",setTimeout(function(){a.removeClass(i),a.data("animation-idle",!1)},500))},50);
});

});
</script>

</html>
