<?php
if(!isset($_SESSION))
	session_start();
?>
<!-- 首页 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<title>学生卡</title>
	<link rel="stylesheet" href="card_assets/agile/css/agile.layout.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.component.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.color.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconline.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconform.css?1">
	<link rel="stylesheet" href="card_assets/component/timepicker/timepicker.css?1">
	<link rel="stylesheet" href="card_assets/app/css/app.css?1">

	<link rel="stylesheet" href="static/css/am-comment-min.css?2">
	<link rel="stylesheet" href="static/css/am-slide-min.css?2">
	<link rel="stylesheet" href="static/css/am-spin-min.css?2">
	<link rel="stylesheet" href="card_assets/app/css/main.min.css">

</head>
<body>
	<div id="section_container">
		<!-- 主页section -->
		<section id="section_cardcenter" data-role="section" class="active">
			<header class="titlebar">
				<h1 class="title">学生卡管理</h1>
				<a data-toggle="section" href="#section_account" data-transition="slidedown"><i class="iconfont iconline-uid"></i></a>
			</header>
			<article data-role="article" data-scroll="pullup" id="article_cardcenter" data-scroll="verticle"  class="active myarticle">

				<div class="scroller">
					<div class="reOnline view-hide" id="div_online_state"><i style="margin-left: 5px;" class="iconfont iconline-refresh am-animation-spin float-left reOnline"></i><span>&nbsp;离线状态，等待自动重连..</span><button id="reonline" style="border-radius: 50%;margin-right: 5px;margin-top: 1px" type="button" class="float-right cancel" >重连</button></div>
					<!-- 个人信息 -->
					<form class="form-group">

						<div class="card blue-bg">
							<div style="padding: 8px;">
								<img id="img_userhead" class="am-circle-noborder float-left" width="0px" height="0px" style="margin-bottom: 5px;" />
								&nbsp;&nbsp;&nbsp;&nbsp;<div style="margin-top:20px;color:white" id="user_name">
								<!-- 微信昵称 -->
								<b id="sp_user_name" class="float-left"></b>
								<div class="svg-wrapper" style="float: right">
									<b id="sp_msg_center" style="position: relative;text-align: center" height="26" width="92"  class="text-large">消息中心<i id="unread_msgcenter" class="unread view-hide"></i></b>
								</div>
							</div>

							<!-- &nbsp;&nbsp;&nbsp;&nbsp;<div id="card_status" class="card-body-left">积分...</div> -->
						</div>
					</div>
				</form>
				<form class="form-group">

					<div class="card">
						<ul id="lv_device" class="listitem">
							<li >暂无绑定设备</li>
						</ul>
					</div>
				</form>
			</div>	
		</article>

		<div id="div_addDevice" class="view-hide bottom full-width"><button class="block" id="btn_addDevice" style="width: 0px;margin:auto;min-width:0px">添加学生卡设备</button></div>
	</section>

	<section id="section_msgcenter" data-role="section" >
		<!-- 消息中心 -->
		<header class="titlebar">
			<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
			<h1 class="title">消息中心</h1>
		</header>

		<article data-role="article" id="article_msgcontent" data-scroll="pullup" style="top:44px" class="active" data-scroll="verticle">

			<div class="scroller padded">
				<div class="section-title" style="font-weight:bold;"  id="list_noMsg">暂无消息</div>
				<ul class="listitem" id="lv_msg"></ul>
			</div>
		</article>
	</section>

	<section id="section_device_main" data-role="section">
		<header class="titlebar">
			<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
			<h1 id="title_device_main" class="title">设备A</h1>
			<a id="a_device_edit"><i class="iconfont iconline-handsign"></i></a>
		</header>
		<article data-role="article" id="article_device_main" data-scroll="verticle" class="active" style="top:44px;bottom:0px;">
			<div class="scroller "> 
				<!-- 个人信息 -->
				<form class="form-group">
					<div  class="card blue-bg">
						<div class="padded">
							<img id="img_device_main_head" class="am-circle float-left" src="" width="100" height="100" style="margin: 3px" />
							&nbsp;&nbsp;&nbsp;&nbsp;
							<div style="margin-top:10px;color: white;">
								<span id="device_main_status">开机状态</span>
								<b id="sp_card_change" style="margin-top: 8px" class="card-body-right text-large" >设备管理</b>
							</div>
							&nbsp;&nbsp;&nbsp;&nbsp;<div id="device_main_electricity" class="card-body-left">电量-</div>
							<!-- &nbsp;&nbsp;&nbsp;&nbsp;<div id="card_status" style="margin-left: 110px;color: #FEFFFF">音量...</div> -->
						</div>
					</div>
				</form>
				<div id="btn_setKeySelect" class="form-group padded view-hide">
					<button class="block cancel outline ">请先设置语音按键</button>
				</div>
				<div id="audio_area">
				<div  style="text-align: center">
					<div id="div_record"><button style="width:214px;min-width:0px;padding: 0px;" id="startRecord" class="disable" disabled>
						<i class="iconfont iconline-record"></i>
						<span>单击录音</span>
					</button></div>
					<div id="btn_group" style="display: inline-block;">
						<button disabled id="stopRecord" class="disable" style="margin-right: 0px;box-sizing: border-box;white-space: 
						nowrap;float: left;border-bottom-right-radius: 0;border-top-right-radius: 0;width: 0px;min-width:0px;padding: 0px">
						<i class="iconfont iconline-rdo-cancel"></i>&nbsp;取消</button>

						<button class="disable" disabled id="uploadVoice" style="margin-left: 0px;box-sizing: border-box;white-space: nowrap;float: right;border-bottom-left-radius: 0;border-top-left-radius: 0;width: 0px;min-width:0px;padding: 0px">
							<i class="iconfont iconline-send"></i>&nbsp;发送</button></div>

						</div>
						<br/>
						<ul id="list_audio" class="am-comments-list padded">
						</ul>
					</div>
				</div>  

			</article>

			<button id="btn_location" class="btn-3dshadow left view-hide">
				<i class="iconfont iconline-map-location"></i>
				<span>定位</span>
				<i id="unread_location" class="unread view-hide"></i>
			</button> 

		</section>

		<section id="section_card_manage" data-role="section" >
			<header class="titlebar">
				<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
				<h1 class="title">设备管理</h1>
			</header> 
			<article data-role="article" id="article_card_manage" data-scroll="verticle" class="active" style="top:44px;">
				<div class="scroller padded">  
					<!-- 设备管理 -->
					<form class="form-group" style="margin-top:1px" id="form_key_phone">
						<div data-role="select" class="card nopadding">
							<select id="select_1" placeholder="选择按键1号码">
								<option class="full-width" value="" selected="true">选择按键1号码</option>
							</select>
						</div>
						<div data-role="select" class="card  nopadding">
							<select id="select_2" placeholder="选择按键2号码">
								<option class="full-width" value="" selected="true">选择按键2号码</option>
							</select>
						</div>
						<div data-role="select" class="card  nopadding">
							<select id="select_3" placeholder="选择按键3号码">
								<option class="full-width" value="" selected="true">选择按键3号码</option>
							</select>
						</div>
					</form>

					<form class="form-group" id="form_volume">
						<div class="card">
							<ul class="listitem" id="select_volume">
								<li >音量</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="vol_0" class="black full-width" >静音</label>
										<input checked="true" type="radio" name="volume" id="vol_0" value="0">
									</a>
								</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="vol_1" class="black full-width" >1档</label>
										<input type="radio" name="volume" id="vol_1" value="2">
									</a>
								</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="vol_2" class="black full-width" >2档</label>
										<input type="radio" name="volume" id="vol_2" value="4">
									</a>
								</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="vol_3" class="black full-width" >3档</label>
										<input type="radio" name="volume" id="vol_3" value="6">
									</a>
								</li>
							</ul>
						</div> 
					</form>
					<form class="form-group" id="form_workmode">
						<div class="card">
							<ul class="listitem" id="select_workmode">
								<li >工作模式</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="mode_0" class="black full-width" >紧急模式</label>
										<input type="radio" name="wm" id="mode_0" value="0">
									</a>
								</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="mode_1" class="black full-width" >正常模式</label>
										<input checked="true" type="radio" name="wm" id="mode_1" value="1">
									</a>
								</li>
								<li class="nopadding">
									<a data-role="radio">
										<label for="mode_2" class="black full-width" >省电模式</label>
										<input type="radio" name="wm" id="mode_2" value="2">
									</a>
								</li>
							</ul>
						</div>
					</form>

					<div><strong style="float: left;margin-left: 5px">到离校通知</strong><div id="toggle_attendance" style="float: right;margin-top: 0px" class="toggle classic" data-role="toggle" data-on="开" data-on-value="1" data-off="关" data-off-value="0"></div><br/>
				</div><br/>
				<button id="btn_manage_setting_submit" class="block">提&nbsp;&nbsp;交</button>
				<button id="btn_school_manage" class="block outline">校园管理</button>
				<div id="btn_remote_shutdown" class="padded"><button class="block cancel">远程关机</button></div>
			</div>

		</article>
	</section>

	<section id="section_card_edit" data-role="section">
		<header class="titlebar">
			<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
			<h1 id="title_card_edit" class="title">添加设备</h1>
			<a id="ic_device_delete"><i class="iconfont iconline-trash"></i></a>
		</header>
		<article data-role="article" id="article_card_edit" data-scroll="verticle" class="active" style="top:44px;bottom:0px;">
			<div class="scroller padded">
				<!-- 编辑/添加设备 -->
				<form autocomplete="false"  class="form-common">
					<label class="label-left" for="user" style="width: 40px"><span class="iconfont iconline-uid"></span></label>
					<label class="label-right">
						<input id="edit_imei" type="tel" placeholder="设备id号" onkeyup="value=value.replace(/[^0-9]/g,'')" title="设备id号" value=""/>
					</label>
					<hr style="margin-top: 1px" /><br/>
					<label  id="edit_pwd_left" class="label-left" for="password"  style="width: 40px"><span class="iconfont iconline-lock"></span></label>
					<label  id="edit_pwd_right" class="label-right">
						<input id="edit_pwd"  type="password" value="" title="设备密码" placeholder="设备密码"/>
					</label>
					<hr  id="edit_pwd_hr"  style="margin-top: 1px" /><br/>

					<label class="label-left" for="user" style="width: 40px"><span class="iconfont iconline-heart-fill"></span></label>
					<label class="label-right">
						<input id="edit_nick" type="text" placeholder="昵称" title="昵称" value=""/>
					</label>
					<hr style="margin-top: 2px" /><br/>
					<label class="label-left">性&nbsp;别：</label>
					<label class="label-right" id="radio_group_sex">
						<a data-role="radio">
							<input type="radio" checked="true" name="sex" id="male" value="男" />
							<label for="male" class="black">男&nbsp;&nbsp;</label>
						</a>
						<a data-role="radio">
							<input type="radio" name="sex" id="female" value="女" />
							<label for="female" class="black">女&nbsp;&nbsp;</label>
						</a>
					</label>
					<hr/>

				</form>

				<!-- 选择头像： -->
				<div class="m-box trac-history" style="background-color: #FFF;overflow: hidden;">
					<label class="mylabel">选择头像：</label>
					<nav class="track-top-nav" style="height:80px;!important">
						<a class="head-select">
							<img class="head-img" src="http://7xkaou.com2.z0.glb.qiniucdn.com/boy01_c.png" alt="">
						</a>
						<a class="head-select">
							<img class="head-img" src="http://7xkaou.com2.z0.glb.qiniucdn.com/boy02_c.png" alt="">
						</a>
						<a class="head-select">
							<img class="head-img" src="http://7xkaou.com2.z0.glb.qiniucdn.com/girl01_c.png" alt="">
						</a>
						<a class="head-select">
							<img class="head-img" src="http://7xkaou.com2.z0.glb.qiniucdn.com/girl02_c.png" alt="">
						</a>
					</nav>
					<!--选中的头像值--> 
					<input type="hidden" name="iconInfos" id="iconInfos" value="http://7xkaou.com2.z0.glb.qiniucdn.com/boy01_c.png"/>
				</div>

				<button  id="btn_edit_submit" class="block">提&nbsp;&nbsp;交</button>

			</div>  

		</article>
	</section>

	<section id="section_school_manage" data-role="section">
		<!-- 校园管理 -->
		<header class="titlebar">
			<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
			<h1 class="title">校园管理</h1>
		</header>

		<article data-role="article" id="article_school_manage" class="active myarticle" data-scroll="verticle">

			<div class="scroller padded">
				<div class="mydiv"> <strong style="float: left;">上课禁用</strong><span id="toggle_school_manage" style="float: right;" class="toggle classic" data-role="toggle" data-on="开" data-on-value="1" data-off="关" data-off-value="0"></span><br/>
				</div><hr class="myhr" />
				<div class="center-text-bold">周一~周五</div>

				<div class="time-manage"><span class="time-manage">阶段一</span>
					<input id="daily11" type="time" name="time" value="08:00" readonly="readonly">至
					<input id="daily12" type="time" name="time" value="10:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段二
					<input id="daily21" type="time" name="time" value="10:00" readonly="readonly">至
					<input id="daily22" type="time" name="time" value="12:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段三
					<input id="daily31" type="time" name="time" value="14:00" readonly="readonly">至
					<input id="daily32" type="time" name="time" value="15:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段四
					<input id="daily41" type="time" name="time" value="15:00" readonly="readonly">至
					<input id="daily42" type="time" name="time" value="16:00" readonly="readonly">
				</div>


				<div class="center-text-bold">周六</div>

				<div class="time-manage">阶段一
					<input id="saturday11" type="time" name="time" value="08:00" readonly="readonly">至
					<input id="saturday12" type="time" name="time" value="10:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段二
					<input id="saturday21" type="time" name="time" value="10:00" readonly="readonly">至
					<input id="saturday22" type="time" name="time" value="12:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段三
					<input id="saturday31" type="time" name="time" value="14:00" readonly="readonly">至
					<input id="saturday32" type="time" name="time" value="15:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段四
					<input id="saturday41" type="time" name="time" value="15:00" readonly="readonly">至
					<input id="saturday42" type="time" name="time" value="16:00" readonly="readonly">
				</div>


				<div class="center-text-bold">周日</div>

				<div class="time-manage">阶段一
					<input id="sunday11" type="time" name="time" value="08:00" readonly="readonly">至
					<input id="sunday12" type="time" name="time" value="10:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段二
					<input id="sunday21" type="time" name="time" value="10:00" readonly="readonly">至
					<input id="sunday22" type="time" name="time" value="12:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段三
					<input id="sunday31" type="time" name="time" value="14:00" readonly="readonly">至
					<input id="sunday32" type="time" name="time" value="15:00" readonly="readonly">
				</div>
				<div class="time-manage">阶段四
					<input id="sunday41" type="time" name="time" value="15:00" readonly="readonly">至
					<input id="sunday42" type="time" name="time" value="16:00" readonly="readonly">
				</div>

			</div>
		</article>
		<div style="margin-top: 5px" class="bottom full-width">
			<button  class="block" id="btn_submit_school_manage" style="width: 90%;margin: auto">保&nbsp;&nbsp;存</button></div>
		</section>

		<section id="section_account" data-role="section" >
			<!-- 账户 -->
			<header class="titlebar">
				<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
				<h1 class="title">账户</h1>
			</header>

			<article data-role="article" id="article_account" class="active myarticle" data-scroll="verticle">

				<div class="scroller">

					<div class="card">
						<ul class="listitem">
							<li >
								<?php echo $_SESSION['card_loginName'];?>
							</li>
							<li>
								<i class="icon-color-blue ricon iconfont iconline-arrow-right"></i>
								<div class="text">
									帮助信息
								</div>
								
							</li>
						</ul>
					</div>

					<div class="padded"><a href="card_login_page#Login_section"><button class="block cancel">切换账户</button></a></div>

				</div>
			</article>
		</section>

		<section id="section_trace" data-role="section" >
			<!-- 定位地图 -->
			<header class="titlebar">
				<a data-toggle="back"  href="#"><i class="iconfont iconline-arrow-left"></i><span style="font-size: 18px">返回</span></a>
				<h1 class="title">定位地图</h1>
			</header>

			<article data-role="article" class="active myarticle" id="article_trace" data-scroll="verticle">

				<div class="scroller padded">
					<div id="location_msg"></div>
					<div id="location_update_time"></div>
					<div id="container" style="height:500px"></div>
				</div>
			</article>

			<div class="bottom full-width"><button  class="block" id="btn_getLocation" style="width: 90%;margin: auto">获取实时定位</button></div>
		</section>


		<audio id="audio_tip" preload="auto" >
			<source src="http://7xkaou.com2.z0.glb.qiniucdn.com/tip.mp3">
			</audio>
		</div>
		<!--- third -->
<script src="card_assets/third/zepto/zepto.min.js"></script>
		<script src="card_assets/third/iscroll/iscroll-probe.js?12"></script>
		<script src="card_assets/third/arttemplate/template-native.js?12"></script>
		<!-- agile -->
		<script type="text/javascript" src="card_assets/agile/js/agile.min.js?13"></script>
		<!-- component timepicker-->
		<script type="text/javascript" src="card_assets/component/timepicker/agile.timepicker.js?12"></script>
		<script type="text/javascript" src="card_assets/component/extend.js?12"></script>
		<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
		<script src="http://res.websdk.rongcloud.cn/RongIMClient-0.9.15.min.js"></script>
		<!-- app -->
		<script type="text/javascript" src="card_assets/app/js/app.js?12"></script>
		<script type="text/javascript" src="http://7xkaou.com2.z0.glb.qiniucdn.com/myajax1.1-min.js"></script>

		<script type="text/javascript">
			wx.config({
				debug: false,
				appId: '<?php echo $signPackage["appId"];?>',
				timestamp: <?php echo $signPackage["timestamp"];?>,
				nonceStr: '<?php echo $signPackage["nonceStr"];?>',
				signature: '<?php echo $signPackage["signature"];?>',
				jsApiList: [
				'checkJsApi',
				'hideMenuItems',
				'showMenuItems',
				'startRecord',
				'stopRecord',
				'onRecordEnd',
				'uploadVoice',
				]
			});
	var openid='<?php echo $_SESSION['id'];?>';
	var RongToken="<?php echo $_SESSION['card_rongtoken'];?>";//融云token
	var card_userId="<?php echo $_SESSION['card_userId'];?>";//用户id
	var card_loginName='<?php echo $_SESSION['card_loginName'];?>';//登录用户名手机号
</script>

<!-- card core-->
<script type="text/javascript" src="card_assets/app/js/card.min_3d60c.js"></script>

<script type="text/javascript">
(function(){
	function loadjs(a,b){var c=document.createElement("script");c.setAttribute("type","text/javascript"),c.setAttribute("src",a),c.setAttribute("id",b),script_id=document.getElementById(b),script_id&&document.getElementsByTagName("head")[0].removeChild(b),document.getElementsByTagName("head")[0].appendChild(c)}
	loadjs('card_assets/app/js/card_wechat.min_7cd8b.js?6','card_wechat');
})();

</script>

<!-- baidu map -->
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=3c7ffcd0889bb67e543a2328f07964cd"></script>

</body>
</html>