<?php
if(!isset($_SESSION))
	session_start();
?>
<!-- 首页 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta http-equiv="x-dns-prefetch-control" content="on" />
	<link rel="dns-prefetch" href="http://kq.snewfly.com"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<title>学生卡</title>
	<link rel="stylesheet" href="card_assets/agile/css/agile.layout.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.component.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.color.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconline.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconform.css?1">
	<link rel="stylesheet" href="card_assets/component/timepicker/timepicker.css?1">
	<link rel="stylesheet" href="card_assets/app/css/app.css?1">

	<link rel="stylesheet" href="card_assets/app/css/main.min.css?">

</head>
<body>
	<div id="section_container"></div>

<script type="text/javascript">
	var RongToken="<?php echo $_SESSION['card_rongtoken'];?>";//融云token
	var card_userId="<?php echo $_SESSION['card_userId'];?>";//用户id
	var card_loginName='<?php echo $_SESSION['card_loginName'];?>';//登录用户名手机号
	var openid='<?php echo $_SESSION['id'];?>';
</script>
<!--- third -->
<script src="card_assets/third/zepto/zepto.min.js"></script>
<!-- card view-->
<script type="text/javascript" src="card_assets/app/js/loadview.js?1"></script>
<!--- third -->
<script src="card_assets/third/iscroll/iscroll-probe.js?12"></script>
<script src="card_assets/third/arttemplate/template-native.js?12"></script>
<!-- agile -->
<script type="text/javascript" src="card_assets/agile/js/agile.min.js?1"></script>
<!-- component timepicker-->
<script type="text/javascript" src="card_assets/component/timepicker/agile.timepicker.js?12"></script>
<script type="text/javascript" src="card_assets/component/extend.js?12"></script>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script src="http://res.websdk.rongcloud.cn/RongIMClient-0.9.15.min.js"></script>
<!-- app -->
<script type="text/javascript" src="card_assets/app/js/app.js?12"></script>
<script type="text/javascript" src="http://7xkaou.com2.z0.glb.qiniucdn.com/myajax1.1-min.js"></script>

<!-- card core-->
<script type="text/javascript">
	wx.config({
		debug: false,
		appId: '<?php echo $signPackage["appId"];?>',
		timestamp: <?php echo $signPackage["timestamp"];?>,
		nonceStr: '<?php echo $signPackage["nonceStr"];?>',
		signature: '<?php echo $signPackage["signature"];?>',
		jsApiList: [
		'checkJsApi',
		'hideMenuItems',
		'showMenuItems',
		'startRecord',
		'stopRecord',
		'onRecordEnd',
		'uploadVoice',
		]
	});

</script>
<script type="text/javascript" src="card_assets/app/js/card.min_5843d.js"></script>
<script type="text/javascript">
	(function(){
  function loadjs(a,b,c){var d=document.createElement("script");d.setAttribute("type","text/javascript"),d.setAttribute("src",a),d.setAttribute("id",b),script_id=document.getElementById(b),script_id&&document.getElementsByTagName("head")[0].removeChild(b),d.onload=function(){void 0!=c&&c()},document.getElementsByTagName("head")[0].appendChild(d)}
  function loadCss(a,b){var c=document.getElementById(b),d=document.getElementsByTagName("head").item(0);c&&d.removeChild(c),css=document.createElement("link"),css.href=a,css.rel="stylesheet",css.type="text/css",css.id=b,d.appendChild(css)}
  loadjs('card_assets/app/js/card_wechat.js?00','card_wechat');
  loadCss('static/css/am.min.css','am.min.css');  
	})();

</script>

<!-- baidu map -->
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=3c7ffcd0889bb67e543a2328f07964cd"></script>

</body>
</html>