<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>交流</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script src="http://cdn.bootcss.com/jquery/2.1.3/jquery.min.js"></script>
	<script src="http://cdn.amazeui.org/amazeui/2.1.0/js/amazeui.min.js"></script>
	<link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.1.0/css/amazeui.min.css"/>
	<style type="text/css">
  hr{
    border:0;background-color:#56B074;height:1px;
  }
  .myhead{
    height:44px; background-color:#56B074 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#ffffff; font-size:16px; font-weight:bold;
  }
  </style>
</head>
<body>

<section class="am-panel am-panel-success">
  <div class="myhead" >
    <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >交&nbsp;&nbsp;流</span>
  </div>
  <div class="am-panel-bd">
  <div style="margin: 15px">
  	
  	<label>语文老师：</label><br/>
  	<label>微信号：liulaoshi</label><br/>
  	<label>手机号：13714871234</label><br/>
<hr data-am-widget="divider" class="am-divider am-divider-dashed"/>

  	<label>数学老师：</label><br/>
  	<label>微信号：chenlaoshi</label><br/>
  	<label>手机号：15814776660</label><br/>
<hr data-am-widget="divider" class="am-divider am-divider-dashed"/>

  	<label>英语老师（班主任）：</label><br/>
  	<label>微信号：misshuang</label><br/>
  	<label>手机号：13530684569</label><br/>
<hr data-am-widget="divider"  class="am-divider am-divider-dashed"/>
<div>
	
</div>
	<img style="width: 100px;height: 100px;float: right" src="https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGb7zoAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL0pVeGE2X2JsUkpBOUxfZGxtV0FtAAIEcvJbVQMEAAAAAA==">
	  	<label>家长群：</label><br/>
  	<label>微信群二维码：</label><br/>
  	<label>（长按识别）</label>
  </div>
  <br/>
  <br/>

  </div>
</section>



</body>


</html>