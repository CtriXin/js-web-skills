<!DOCTYPE html>
<html>
<head>
	<title>
		主页
	</title>
	<meta charset='utf8'>
	<link rel="stylesheet" href="static/css/index.css">
</head>
<body>

<div class="container">
<!-- Left  begin	-->
	<div class="left">
		<a class="menu home" href="/"></a>
		<a href="/" class="menu audio"></a>
		<div class="submenu">
			<ul>
				<li>
					<a href="/?state=382">
						<span class="icon">&rsaquo;</span>
						<span class="text">未处理</span>
						<span class="num to-deal-num"><?php echo $messagesToDealNum?></span>
					</a>
				
				<li>
					<a href="/?state=61">
						<span class="icon">&rsaquo;</span>
						<span class="text">已处理</span>
						<span class="num dealed-num"><?php echo $messagesDealedNum?></span>
					</a>
				</li>
				<li>
					<a href="/?state=383">
						<span class="icon">&rsaquo;</span>
						<span class="text">已下载</span>
						<span class="num downleaded-num"><?php echo $messagesDownloadedNum?></span>
					</a>
				</li>
				<li>
					<a href="/?state=62">
						<span class="icon">&rsaquo;</span>
						<span class="text">回复错误</span>
						<span class="num error-num"><?php echo $messagesErrordNum?></span>
					</a>
				</li>
			
			</ul>
		</div>
		<a href="/?state=67" class="menu trash"></a>
	</div>
<!-- Left  finish	-->

<!-- Right  begin	-->

	<div class="right">
		<div class="header">
			<div class="profile">
				<img src="static/img/user.jpg" id="avatar"alt="user">
				<span>Admin </span>			
				<div class="menu">
					<ul>
						<li>
							<a href="/logout">
								<div class="logout">&nbsp;</div>
								登出
							</a>
						</li>
						<li>

							<a href="/edit">
								<div class="edit">&nbsp;</div>
								修改密码
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- <div class="state">
			<span class="dealed">已处理</span>
			<span class="todeal active">未处理</span>
		</div> -->
		<div class="content">
			<?php
			foreach ($messages as $key => $value) {
				$date = date('Y-m-d H:i:s',$value->upload_time);
				echo "<div class='item'>
				<div class='icon'></div>
				<div class='img'>
					<div class='img-icon'></div>
					<div class='trash-icon' id='$value->id'></div>
					<img src='$value->pic' alt=''>
				</div>
				<div class='audio'>
					<audio controls>
 						<source src='$value->audio' type='audio/ogg'>
						Your browser does not support the audio element.
					</audio>
					<div class='choice'>
						 <input type='button' audio = '$value->audio' value='问题'' class='disable' name='question'>	
						 <input type='button' audio = '$value->reply' value='我的回复'' class='disable' name='reply'>
						 <input type='button' class='disable' value='录音' name='startRecord' id='$value->id'>
						 <input type='button' name='stopRecord' value='停止' class='disable'>
						 <input type='button' name='submit' value='提交' class='disable' id='$value->id'>
					</div>
					
					<canvas></canvas>
					<div class='date'><span><b>发表日期</b></span><span>$date</span></div>
				</div>
			</div>";
			}	
			?>
		</div>
		<div class="pagination">
			<div class="pages">
				<div class="prev">
					<a href="?currentPage=<?php echo $currentPage ?>&page=<?php echo $currentPage-1 ?>&state=<?php echo $state ?>">
					上一页
					</a>
				</div>
				<ul>
					<?php
						foreach ($totalPage as $key => $value) {
							if($currentPage == $value){
								echo "<li><a href=\"/?currentPage=$currentPage&page=$value&state=$state\" class='active'>$value</a></li>";
							}
							else{
								echo "<li><a href=\"/?currentPage=$currentPage&page=$value&state=$state\">$value</a></li>";
							}
						}
					?>
				</ul>
				<div class="next"><a href="?currentPage=<?php echo $currentPage ?>&page=<?php echo $currentPage + 1 ?>&state=<?php echo $state?>">下一页</a></div>
			</div>
			
			<div class="clear"></div>
		</div>

	</div>
<!-- Right  finish	-->
</div>
<div class="reminder">
	<audio src="static/audio/reminder.mp3" id='reminder'></audio>
</div>
<div class="img-container" id="img-container">&nbsp;
	<div class="close">关闭</div>
	<div class="rotate forward">正向旋转</div>
	<div class="rotate reverse">反向旋转</div>
	<img id="img-prev" class="img-prev" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNJZCJ7zgxELU0M5rNISa2vwjpguedvUvl2_u9R0t_wEZG-b71" alt="" class="prev">	
	<div class="img-zoom-cover">&nbsp;</div>
</div>
</body>
<script type="text/javascript" src="static/js/lib/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="static/js/lib/recordmp3.js"> </script>
<script type="text/javascript" src="static/js/index.js"></script>
</html>