<?php
if(!isset($_SESSION)){
 session_start();  
}  
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <meta content="yes" name="apple-mobile-web-app-capable" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

  <title>孩在身边</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.5.0/css/amazeui.min.css"/>
  <link rel="stylesheet" href="http://7xkaou.com2.z0.glb.qiniucdn.com/mobilebone-min.css"/>

  <style type="text/css">
    a.am-btn-primary:visited,a.am-btn-danger:visited,a.am-btn-warning:visited,a.am-btn-secondary:visited,a.am-btn-success:visited{
      color:#fff;
    }

    .set-bt, .set-bt span{ display:-webkit-box;-webkit-box-sizing:border-box; background-color:#ffffff;border:1px solid #d2d2d2; -webkit-border-radius:16px;}
    .set-bt{width:52px; height:32px; text-align:left;}
    .set-bt span{width:30px; height:30px;}
    .set-on-bt{ background-color:#01e366; border:1px solid #01e366; -webkit-box-pack:end;}
    .float-right{float: right;margin-right: 4px}
    .float-left{float:left;margin-left: 4px}
    .padding{margin:8px}
    .study-chart{width: 800px; height: 250px;display: none}
    .hide{display: none}
    .audio-li{margin: 0 auto;text-align: center}
    .mybtn-radius{-webkit-border-radius:7px;}
    .padded{margin: 10px 10px}

    .fade{opacity: 0}
    .border-warn{border: 1px solid #F37B1D}
  </style>

</head>
<body>
  <div  id="pageHome" class="page out" >
    <div class="padded">
      <select id="mySelect" data-am-selected="{btnWidth: '100%', btnSize: 'sm', btnStyle: 'default'}">
        <!--     <option value="rongyunid">学伴机一号</option> -->
      </select>
    </div>
    <div id="div_online_state" class="hide"><i class="am-icon-spinner am-animation-spin float-left"></i><span>&nbsp;离线状态，等待自动重连..</span><button id="reonline" type="button" class="float-right am-btn am-btn-primary am-round am-btn-xs doc-animations " data-doc-animation="shake">重连</button></div>
    <div id="myImgContainer">
      <figure id="myfigure" style="width: 0px;margin:0px auto" data-am-widget="figure" class="am am-figure am-figure-default hide"
      data-am-figure="{  pureview: 'true' }">
      <img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png"
      data-rel="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png" alt=""
      />
    </figure>
  </div>

  <div class="padded">

    <div style="text-align: center">
      <button id="send" type="button" class="am-btn am-btn-secondary doc-animations "  data-doc-animation="shake"><span class="am-icon-camera"></span>&nbsp;截小图</button>&nbsp;
      <button id="sendbig" type="button" class="am-btn am-btn-warning  doc-animations"  data-doc-animation="shake"><span class="am-icon-camera"></span>&nbsp;截大图</button>
    </div>
    <div style="margin: 3px" id="picMsgContainer"></div>
    <hr data-am-widget="divider" style="border:0;background-color:#DEDEDE;height:1px;" class="am-divider am-divider-dashed"/>
    <div id="audioMsgContainer"></div>
    <div style="text-align: center">
      <div id="refreshing"><span class="am-icon-spinner am-animation-spin"></span>&nbsp;数据初始化，请稍等..</div>
      <div style="text-align: center" class="hide" id="div_record"><button disabled class="am-btn am-btn-success mybtn-radius" id="startRecord" style="width:0px"><span class="am-icon-microphone"></span>&nbsp;单击录音</button></div>

      <div class="am-btn-group" id="btn_group">
        <button style="width:0px;border-top-left-radius: 7px; border-bottom-left-radius: 7px;" class="am-btn am-btn-danger am-round" id="stopRecord"><span class="am-icon-trash"></span>&nbsp;放 弃</button>
        <button style="width:0px;border-top-right-radius: 7px; border-bottom-right-radius: 7px;" class="am-btn am-btn-success am-round" id="uploadVoice"><span class="am-icon-paper-plane"></span>&nbsp;发 送</button>
      </div>
      
    </div>

  </div>

  <section data-am-widget="accordion" class="am-accordion am-accordion-gapped"
  data-am-accordion='{  }'>
  <!-- <dl class="am-accordion-item am-active"> -->
  <dl class="am-accordion-item" id="audio_live">
    <dt class="am-accordion-title">语音聊天记录<span id="badge_not_read" class="am-badge am-badge-danger am-round hide" >0</span><span style="float: right" class="am-icon-save"></span></dt>
    <dd style="" class="am-accordion-bd am-collapse">
      <!-- 规避 Collapase 处理有 padding 的折叠内容计算计算有误问题， 加一个容器 -->
      <div class="am-accordion-content">
        <!-- <h3 id="menu-voice">聊天表</h3> -->
        <ul class="am-comments-list" id="s">
        </ul>
        <div>

        </div>
      </div>
    </dd>
  </dl>

  <dl class="am-accordion-item"  id="data_live">
    <dt class="am-accordion-title">今天学习数据<span style="float: right" class="am-icon-file-text-o"></span></dt>
    <dd class="am-accordion-bd am-collapse">
      <!-- 规避 Collapase 处理有 padding 的折叠内容计算计算有误问题， 加一个容器 -->
      <div class="am-accordion-content">
        <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
          <li><a href="###" class="am-cf"><span class="am-icon-check"></span> 您的孩子已学习：<span class="am-icon-star am-fr am-margin-right am-text-warning am-animation-spin"></span></a></li>
          <li><a href="###"><span class="am-icon-clock-o"></span> 时&nbsp;&nbsp;&nbsp;间：<span id="timeNum" class="am-badge am-badge-secondary am-margin-right am-fr">0分</span></a></li>
          <li><a href="###"><span class="am-icon-at"></span> 写字数：<span id="wordNum"  class="am-badge am-badge-secondary am-margin-right am-fr">0字</span></a></li>
          <li><a href="###"><span class="am-icon-book"></span> 阅读量：<span id="pageNum"  class="am-badge am-badge-secondary am-margin-right am-fr">0页</span></a></li>
          <li><a href="###"><span class="am-icon-bookmark-o"></span> 更新时间：<span id="updateTime"  class="am-badge am-badge-secondary am-margin-right am-fr">0000-00-00 00:00:00</span></a></li>
        </ul>

        <button id="data" type="button" class="am-btn am-btn-success am-round doc-animations  am-btn-block  am-radius"  data-doc-animation="scale-up"><span class="am-icon-refresh " ></span>&nbsp;更新数据</button><!-- <span class="am-icon-cog am-animation-spin" style="float: right"></span> -->

      </div>
    </dd>
  </dl>


  <dl class="am-accordion-item"  id="score_live">
    <dt style="border: 1px solid #F37B1D" class="am-accordion-title">积分任务<span style="float: right" class="am-icon-gift am-text-warning"></span></dt>
    <dd class="am-accordion-bd am-collapse">
      <!-- 规避 Collapase 处理有 padding 的折叠内容计算计算有误问题， 加一个容器 -->
      <div class="am-accordion-content">
        <ul class="am-list am-collapse admin-sidebar-sub am-in" id="collapse-nav">
          <li><a href="###" class="am-cf"><span class="am-text-warning am-icon-database"></span> 今日任务进度：<span class="am-icon-star am-fr am-margin-right am-text-warning am-animation-spin"></span></a></li>
          <li><a href="###"><span class="am-icon-power-off am-text-success"></span> 开机&nbsp;<span class="am-text-xs am-text-danger">(+5/次 最高5)</span><span class="am-icon-check-square-o am-fr fade" id="i_turn_on"></span><span id="s_turn_on_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
          <li><a href="###"><span class="am-icon-clock-o am-text-success"></span> 学习时间&nbsp;<span class="am-text-xs am-text-danger">(+10/30分钟 最高30)</span><span class="am-icon-check-square-o am-fr fade" id="i_study"></span><span id="s_study_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
          <li><a href="###"><span class="am-icon-pencil am-text-success"></span> 写字字数&nbsp;<span class="am-text-xs am-text-danger">(+10/50字 最高50)</span><span class="am-icon-check-square-o am-fr fade" id="i_word"></span><span id="s_word_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
          <li><a href="###"><span class="am-icon-book am-text-success"></span> 阅读页数&nbsp;<span class="am-text-xs am-text-danger">(+5/5页 最高20)</span><span class="am-icon-check-square-o am-fr fade" id="i_page"></span><span id="s_page_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
          <li><a href="###"><span class="am-icon-photo am-text-success"></span> 图片互动&nbsp;<span class="am-text-xs am-text-danger">(+10/次 最高60)</span><span class="am-icon-check-square-o am-fr fade" id="i_pic"></span><span id="s_pic_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
          <li><a href="###"><span class="am-icon-volume-up am-text-success"></span> 语音互动&nbsp;<span class="am-text-xs am-text-danger">(+10/次 最高60)</span><span class="am-icon-check-square-o am-fr fade" id="i_voice"></span><span id="s_voice_num" class="am-badge am-badge-warning am-fr">+0</span></a></li>
        </ul>
        <a href="http://points.snewfly.com/" type="button" class="am-btn am-btn-success am-btn-block am-radius">积分商城</a>
      </div>
    </dd>
  </dl>


  <dl class="am-accordion-item" id="chart_live">
    <dt class="am-accordion-title">学习统计图<span style="float: right" class="am-icon-line-chart"></span></dt>
    <dd class="am-accordion-bd am-collapse ">
      <div class="am-accordion-content">
        <!-- 日期选择 -->
        <div class="am-input-group am-datepicker-date" style="margin: 0 auto;">
          <input style="text-align: center" id="datepicker" type="text" class="am-form-field" placeholder="选择查询月份"  data-am-datepicker="{format: 'yyyy-mm', viewMode: 'months', minViewMode: 'months'}"  readonly>
          
        </div>
        <br/>
        <div id="msgContainer"></div>
        <div class="study-chart" id="draw_words"></div>
        <div class="study-chart" id="draw_pages"></div>
        <div class="study-chart" id="draw_timecost"></div>
      </div>
    </dd>
  </dl>


  <dl class="am-accordion-item">
    <dt class="am-accordion-title">账户设置<span style="float: right" class="am-icon-cog"></span></dt>
    <dd class="am-accordion-bd am-collapse ">

      <div style="margin: 5px;margin-top: 15px">
        <a style="margin: 1px" data-ajax="false" href="/hzsb_login_page_zhihui">
          <span class="am-icon-user am-text-success">
          </span>&nbsp;<strong><?php echo $_SESSION['telephone'];?></strong><span id="username" style=""></span>
          <span class="am-btn-sm am-btn-danger float-right">切换账号</span>
        </a></div>
        <hr/>
        <div style="margin: 5px;margin-top: 15px"><a style="margin: 1px" href="http://7xkaou.com2.z0.glb.qiniucdn.com/help.html?">
          <span class="am-icon-tag am-text-success"></span>&nbsp;
          <span id="username">使用说明</span><span class="am-btn-sm am-btn-primary float-right">点我查看</span>
        </a></div>
        <hr/>
        <div style="margin: 5px;"><span class="am-icon-toggle-on am-text-success"></span><span style="vertical-align: middle"> 新消息提示音</span><input name="stateon" id="stateon" type="hidden" value="0" /><a style="margin:1px;" class="set-bt am-fr" id="toggleswitch" href="javascript:void(0)"><span></span></a></div>
        <hr/>
      </dd>
    </dl>
  </section>

  <ul class="am-list" style="margin: 10px;">

    <li><a href="#page_xbjmanage" data-rel="accordion">&nbsp;<i class="am-icon-edit am-icon-fw"></i><span class="widget-name">&nbsp;伴学机管理</span><i class="am-icon-angle-right float-right"></i></a></li>
    <!-- <li><a href="#" data-rel="accordion">&nbsp;<i class="am-icon-gift am-icon-fw"></i><span class="widget-name">&nbsp;积分功能</span><i class="am-icon-angle-right float-right"></i></a></li> -->
    <li><a href="#" data-rel="accordion">&nbsp;<i class="am-icon-clock-o am-icon-fw"></i><span class="widget-name">&nbsp;提醒功能</span><i class="am-icon-angle-right float-right"></i></a></li>
  </ul>

  <br/>

</div>
<!-- pageHome end -->

<div id="page_xbjmanage" class="page out">

  <div style="text-align: center;margin-top: 5px"> <a class="float-left" type="button" href="#pageHome" data-rel="back">&laquo;返回</a><span >伴学机管理</span></div>
  <hr style="margin-top: 5px"/>

  <ul class="am-list" id="lv_bxj_binded" style="margin: 10px;">
    <li><a><span class="widget-name">&nbsp;&nbsp;未绑定伴学机</span>
    </a></li>
<!-- 
    <li><a onclick="toEdit(0);"><span class="widget-name">&nbsp;&nbsp;伴学机A</span>
      <span class="am-badge am-badge-success float-right">编辑</span></a></li>
    -->

  </ul>
  <br/>
  <div class="padding"><a href="#page_xbj_edit" id="btn_xbj_to_add" type="button" class="mybtn-radius am-btn am-btn-success am-btn-block doc-animations" data-doc-animation="shake">设备号绑定设备</a></div>
  <div class="padding"><a href="qrcode/qrbind2.html?uId=<?php echo $_SESSION['rong_token_id'];?>" data-ajax="false"  type="button" class="am-btn am-btn-warning am-btn-block mybtn-radius">二维码绑定设备</a></div>
  <div class="padding"><a href="qrcode/wifisettings2.html?" data-ajax="false"  type="button" class="am-btn am-btn-secondary am-btn-block mybtn-radius">伴学机配置wifi</a></div>
</div>
<!-- page_xbjmanage end -->

<div id="page_xbj_edit" class="page out">

  <div style="text-align: center;margin-top: 5px"> 
    <a class="float-left" type="button" href="#page_xbjmanage" data-rel="back">&laquo;返回</a><span id="title_xbj_edit">添加伴学机</span><a  id="device_delete" class=" float-right"><i class="am-icon-trash am-text-danger"></i>解绑</a>
  </div>
  <hr style="margin-top: 5px"/>
  <div class="am-input-group">
    <span class="am-input-group-label"><i class="am-icon-user am-icon-fw"></i></span>
    <input id="imei" type="text" class="am-form-field" placeholder="设备号" >
    <span class="am-input-group-btn" id="group_scan">
      <button id="btn_scan" class="am-btn am-btn-warning am-btn-block doc-animations am-animation-shake" data-doc-animation="shake" type="button" style="padding: 3px">扫一扫</button>
    </span>
  </div>
  <div id="realNameGroup" class="am-input-group">
    <span class="am-input-group-label"><i class="am-icon-heart-o am-icon-fw"></i></span>
    <input id="realName" type="text" class="am-form-field" placeholder="孩子真实姓名" >
  </div>

  <div class="am-input-group"> 
    <span class="am-input-group-label"><i class="am-icon-heart am-icon-fw"></i></span>
    <input id="childNick" type="text" class="am-form-field" placeholder="孩子昵称">
  </div>

  <div class="am-input-group"> 
    <span class="am-input-group-label"><i class="am-icon-users am-icon-fw"></i></span>
    <input id="parentCall" type="text" class="am-form-field" placeholder="你的称呼">
  </div>
  &nbsp;语音按键：
  <select id="myKeySelect" data-am-selected="{btnWidth: '50%', btnSize: 'sm', btnStyle: 'default'}">
    <option value="">请选择绑定按键</option>
    <option value="F">F 爸爸键</option>
    <option value="M">M 妈妈键</option>
    <option value="O">O 更多键</option>
  </select>
  <br/>
  <div style="margin: 8px"><button id="btn_xbj_edit_submit" type="button" class="am-btn am-btn-success am-btn-block doc-animations mybtn-radius" data-doc-animation="shake">提&nbsp;&nbsp;交</button></div>
  <span style="font-style:italic;font-size: 10px">&nbsp;*非管理员修改按键需重新绑定，管理员可直接修改</span>
</div>

<!-- page_xbj_edit end -->
<!-- confirm -->
<div class="am-modal am-modal-confirm" tabindex="-1" id="my-confirm">
  <div class="am-modal-dialog">
    <div id="myConfirm_title" class="am-modal-hd">标题</div>
    <div id="myConfirm_content" class="am-modal-bd">
      内容
    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn" data-am-modal-cancel>取消</span>
      <span class="am-modal-btn" data-am-modal-confirm>确定</span>
    </div>
  </div>
</div>
<audio id="audio_tip" preload="auto" >
  <source src="http://7xkaou.com2.z0.glb.qiniucdn.com/tip.mp3">
  </audio>
</body>


<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui-2.5.0.min.js"></script>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script src="http://res.websdk.rongcloud.cn/RongIMClient-0.9.15.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/mobilebone-mini.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/myajax1.1-min.js"></script>

<script type="text/javascript">
  wx.config({
    debug: false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: <?php echo $signPackage["timestamp"];?>,
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: [
    'checkJsApi',
    'hideMenuItems',
    'showMenuItems',
    'startRecord',
    'stopRecord',
    'onRecordEnd',
    'uploadVoice',
    'downloadVoice',
    'scanQRCode',
    ]
  });
</script>

<script type="text/javascript">
  var RongToken='<?php echo $_SESSION['rong_token'];?>';
  var telephone='<?php echo $_SESSION['telephone'];?>';
  var username='<?php echo $_SESSION['telephone'];?>';
  var openid='<?php echo $_SESSION['id'];?>';
  var tokenid='<?php echo $_SESSION['rong_token_id'];?>';
  var user_id='<?php echo $_SESSION['user_id'];?>';//手机号对应id

</script>
<script src="static/js/wxdemozhihui.js?"></script>

<script type="text/javascript">
  var bajian=new B();
  function B() {
    this.toast = function(str){
      alert(str);
    };
  }
  (function(){
  function loadjs(a,b,c){var d=document.createElement("script");d.setAttribute("type","text/javascript"),d.setAttribute("src",a),d.setAttribute("id",b),script_id=document.getElementById(b),script_id&&document.getElementsByTagName("head")[0].removeChild(b),d.onload=function(){void 0!=c&&c()},document.getElementsByTagName("head")[0].appendChild(d)}
  function loadCss(a,b){var c=document.getElementById(b),d=document.getElementsByTagName("head").item(0);c&&d.removeChild(c),css=document.createElement("link"),css.href=a,css.rel="stylesheet",css.type="text/css",css.id=b,d.appendChild(css)}
  loadjs('static/js/bonezhihui.js?1','bonezhihui');
  loadCss('http://7xkaou.com2.z0.glb.qiniucdn.com/warntoast.min.css','warntoastcss');
  loadjs('http://7xkaou.com2.z0.glb.qiniucdn.com/warntoast.min.js','warntoastjs',function(){
    bajian.toast=function(str){
      var options = {
        title: str,
        duration: 5000,
      };
      $toast.show(options);
    }
  });
  loadjs('http://7xkaou.com2.z0.glb.qiniucdn.com/highcharts.js','highcharts');
  })();
</script>
</html>
