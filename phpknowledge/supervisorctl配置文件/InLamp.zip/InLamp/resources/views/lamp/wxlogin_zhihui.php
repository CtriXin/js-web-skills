<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <title>孩在身边-登录</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.5.0/css/amazeui.min.css"/>

</head>
<body>
  <div  style="height:44px; background-color:#E6E6E6 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#5EB95E; font-size:16px; font-weight:bold;" >
    <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >用户登录</span>
  </div>
  <br>
  <div style="margin-top: 150px;margin: 10px;">

    <div class="am-input-group am-animation-slide-left">
      <span class="am-input-group-label"><i class="am-icon-user am-icon-fw"></i></span>
      <input id="phone" type="tel" class="am-form-field" onkeyup="value=value.replace(/[^0-9]/g,'')" maxlength=11 placeholder="手机号"  data-am-popover="{content: '没有账号？请点立即注册', trigger: 'hover focus'}">
    </div>

    <div class="am-input-group am-animation-slide-right">
      <span class="am-input-group-label"><i class="am-icon-lock am-icon-fw"></i></span>
      <input id="password" type="password" class="am-form-field" placeholder="密码">
    </div>
    <div><a href="hzsb_register_page_zhihui" style="float: right;margin: 8px">立即注册</a></div>
    <button id="btn_login" type="button" style=" -webkit-border-radius:7px;" class="am-btn am-btn-success am-btn-block doc-animations am-animation-shake" data-doc-animation="shake">登&nbsp;&nbsp;录</button>
    <div><a href="hzsb_reset_pwd_page" style="float: left;margin: 8px">忘记密码</a><a href="hzsb_edit_pwd_page" style="float: right;margin: 8px">修改密码</a></div>

  </div>

  <button
  id="btn_myAlert"
  style="display: none;"
  type="button"
  class="am-btn am-btn-primary"
  data-am-modal="{target: '#my-alert',closeViaDimmer: 0}">
  Alert
</button>

<div class="am-modal am-modal-alert" tabindex="-1" id="my-alert">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">温馨提示</div>
    <div class="am-modal-bd" id="myAlert_value">

    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">确定</span>
    </div>
  </div>
</div>

</body>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui-2.5.0.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){function b(){a.start()}function d(a){$("#myAlert_value").html(a),$("#btn_myAlert").click()}function e(){var a=$("#phone").val(),c=$("#password").val();return 11!=a.length?(d("手机号格式错误"),void 0):(""!=a&&""!=c?(b(),$("#btn_login").attr("disabled",!0),f(a,c)):d("账号或密码为空"),void 0)}function f(b,c){$.ajax({url:"hzsb_login_zhihui?phone="+b+"&password="+c+"&r="+Math.random(),type:"get",dataType:"json",success:function(b){$("#btn_login").attr("disabled",!1),a.done(),""!=b.msg?(d(b.msg),"101"==b.code&&setTimeout(function(){window.location.href="http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_bxj&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect"},800)):window.location.href="wxdemo_zhihui?r="+Math.random()},error:function(){a.done(),$("#btn_login").attr("disabled",!1),d("网络错误，请稍后重试")}})}function g(){var a=new Object;a=h(),"1"==a["otherDevice"]&&d("您的账号已在其他设备登录,如果不是本人登录，请立即修改密码")}function h(){var c,d,a=location.search,b=new Object;if(-1!=a.indexOf("?"))for(c=a.substr(1),strs=c.split("&"),d=0;d<strs.length;d++)b[strs[d].split("=")[0]]=unescape(strs[d].split("=")[1]);return b}var a=$.AMUI.progress;$("#btn_login").click(function(){e()}),$(":button").click(function(){var a=$(this),b="am-animation-"+a.data("docAnimation");a.data("animation-idle")&&clearTimeout(a.data("animation-idle")),a.removeClass(b),setTimeout(function(){a.addClass(b),a.data("animation-idle",setTimeout(function(){a.removeClass(b),a.data("animation-idle",!1)},500))},50)}),g()});
</script>

</html>
