<?php
if(!isset($_SESSION)) session_start();?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-dns-prefetch-control" content="on" />
  <link rel="dns-prefetch" href="http://bxj.server.snewfly.com"/>
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

  <title>伴学机</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.5.0/css/amazeui.min.css"/>
  <link rel="stylesheet" href="http://7xkaou.com2.z0.glb.qiniucdn.com/mobilebone-min.css"/>
  <link rel="stylesheet" href="static/css/bxj-main.min-c1ea661e56624a43da676b34430688a0.css"/>

</head>
<body>
  <div  id="pageHome" class="page out" >
    <div class="padded">
      <select id="mySelect" placeholder="选择伴学机" data-am-selected="{btnWidth: '100%', btnSize: 'sm', btnStyle: 'default'}">
        <!--     <option value="rongyunid">学伴机一号</option> -->
      </select>
    </div>
    <div id="div_online_state" class="hide"><i class="am-icon-spinner am-animation-spin float-left"></i><span>&nbsp;离线状态，等待自动重连..</span><button id="reonline" type="button" class="float-right am-btn am-btn-primary am-round am-btn-xs doc-animations " data-doc-animation="shake">重连</button></div>

  <div data-am-flexslider="{playAfterPaused: 8000}" id="banner_container"  class="hide banner padded am-slider am-slider-default"  >
    <ul class="am-slides">
      <li data-thumb="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png">
        <img class="banner-img" src="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png" /></li>
      </ul>
    </div>
    <hr/>
    <div class="hide" id="myImgContainer">
      <figure id="myfigure" data-am-widget="figure" class="am am-figure am-figure-default hide"
      data-am-figure="{pureview:'true'}">
      <img id="myImg" src="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png"
      data-rel="http://7xkaou.com2.z0.glb.qiniucdn.com/bxjbgmin.png" alt=""
      />
    </figure>
  </div>

  <div class="padded">

    <div style="text-align: center">
      <button id="send" type="button" class="am-btn am-btn-secondary doc-animations "  data-doc-animation="shake"><span class="am-icon-camera"></span>&nbsp;截小图</button>&nbsp;
      <button id="sendbig" type="button" class="am-btn am-btn-warning  doc-animations"  data-doc-animation="shake"><span class="am-icon-camera"></span>&nbsp;截大图</button>
    </div>
    <div style="margin: 3px" id="picMsgContainer"></div>
    <hr data-am-widget="divider" style="border:0;background-color:#DEDEDE;height:1px;" class="am-divider am-divider-dashed"/>
    <div id="audioMsgContainer"></div>
    <div style="text-align: center">
      <div id="refreshing"><span class="am-icon-spinner am-animation-spin"></span>&nbsp;数据初始化，请稍等..</div>
      <div class="hide" id="div_record"><button disabled class="am-btn am-btn-success mybtn-radius" id="startRecord" style="width:0px;padding:0.5em 0em;border: 0px"><span class="am-icon-microphone"></span>&nbsp;单击录音</button></div>

      <div class="am-btn-group" id="btn_group">
        <button style="width:0px;border-top-left-radius: 7px; border-bottom-left-radius: 7px;padding:0.5em 0em;border: 0px" class="am-btn am-btn-danger am-round" id="stopRecord"><span class="am-icon-trash"></span>&nbsp;放 弃</button>
        <button style="width:0px;border-top-right-radius: 7px; border-bottom-right-radius: 7px;padding:0.5em 0em;border: 0px" class="am-btn am-btn-success am-round" id="uploadVoice"><span class="am-icon-paper-plane"></span>&nbsp;发 送</button>
      </div>
      
    </div>

  </div>

  <section data-am-widget="accordion" class="am-accordion am-accordion-gapped"
  data-am-accordion='{  }'>
  <dl class="am-accordion-item" id="audio_live">
    <dt class="am-accordion-title">语音聊天记录<span id="badge_not_read" class="am-badge am-badge-danger am-round hide" >0</span><span style="float: right" class="am-icon-save"></span></dt>
    <dd style="" class="am-accordion-bd am-collapse">
      <div class="am-accordion-content">
        <ul style="margin-bottom:0px" class="am-comments-list" id="lv_audio">
        </ul>
        <div style="margin-bottom:10px">
        <a id="delete_record" href="####" >清空记录</a>
        <a id="read_more" href="####" style="float: right;">查看更多</a></div>
      </div>
    </dd>
  </dl>

  <dl class="am-accordion-item"  id="data_live">
    <dt class="am-accordion-title">今天学习数据<span style="float: right" class="am-icon-file-text-o"></span></dt>
    <dd class="am-accordion-bd am-collapse">
      <div id="data_content"></div>
    </dd>
  </dl>


  <dl class="am-accordion-item"  id="score_live">
    <dt style="border: 1px solid #F37B1D" class="am-accordion-title">积分任务<span style="float: right" class="am-icon-gift am-text-warning"></span></dt>
    <dd class="am-accordion-bd am-collapse">
      <div id="score_content"></div>
    </dd>
  </dl>


  <dl class="am-accordion-item" id="chart_live">
    <dt class="am-accordion-title">学习统计图<span style="float: right" class="am-icon-line-chart"></span></dt>
    <dd class="am-accordion-bd am-collapse ">
      <div id="chart_content" class="am-accordion-content"></div>
    </dd>
  </dl>

  <dl class="am-accordion-item">
    <dt class="am-accordion-title">账户设置<span style="float: right" class="am-icon-cog"></span></dt>
    <dd class="am-accordion-bd am-collapse ">
    <div id="setting_content"></div>
    </dd>
    </dl>
  </section>

  <ul class="am-list" style="margin: 10px;">

    <li><a href="#page_xbjmanage" data-rel="accordion">&nbsp;<i class="am-icon-edit am-icon-fw"></i><span class="widget-name">&nbsp;伴学机管理</span><i class="am-icon-angle-right float-right"></i></a></li>
    <!-- <li><a href="#" data-rel="accordion">&nbsp;<i class="am-icon-clock-o am-icon-fw"></i><span class="widget-name">&nbsp;提醒功能</span><i class="am-icon-angle-right float-right"></i></a></li> -->
  </ul>
  <br/>

</div>
<!-- pageHome end -->

<div id="page_xbjmanage" class="page out"></div>
<!-- page_xbjmanage end -->

<div id="page_xbj_edit" class="page out"></div>
<!-- page_xbj_edit end -->

<!-- confirm -->
<div class="am-modal am-modal-confirm" tabindex="-1" id="my-confirm"></div>

<audio id="audio_tip" preload="auto" ><source src="http://7xkaou.com2.z0.glb.qiniucdn.com/tip.mp3"></audio>
</body>


<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui-2.5.0.min.js"></script>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script src="http://res.websdk.rongcloud.cn/RongIMClient-0.9.15.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/mobilebone-mini.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/myajax1.1-min.js"></script>

<script type="text/javascript">
  wx.config({
    debug: false,
    appId: '<?php echo $signPackage["appId"];?>',
    timestamp: <?php echo $signPackage["timestamp"];?>,
    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
    signature: '<?php echo $signPackage["signature"];?>',
    jsApiList: [
    'checkJsApi',
    'hideMenuItems',
    'showMenuItems',
    'startRecord',
    'stopRecord',
    'onRecordEnd',
    'uploadVoice',
    'scanQRCode',
    ]
  });
</script>

<script type="text/javascript">
  var RongToken='<?php echo $_SESSION['rong_token'];?>';
  var telephone='<?php echo $_SESSION['telephone'];?>';
  var username='<?php echo $_SESSION['telephone'];?>';
  var openid='<?php echo $_SESSION['id'];?>';
  var tokenid='<?php echo $_SESSION['rong_token_id'];?>';
  var user_id='<?php echo $_SESSION['user_id'];?>';//手机号对应id

</script>
<script src="static/js/bxj/bxj.min_84445.js"></script>
<script type="text/javascript">
  var bajian=new B();
  function B() {
    this.toast = function(str){
      alert(str);
    };
  }
  (function(){
  function loadjs(a,b,c){var d=document.createElement("script");d.setAttribute("type","text/javascript"),d.setAttribute("src",a),d.setAttribute("id",b),script_id=document.getElementById(b),script_id&&document.getElementsByTagName("head")[0].removeChild(b),d.onload=function(){void 0!=c&&c()},document.getElementsByTagName("head")[0].appendChild(d)}
  function loadCss(a,b){var c=document.getElementById(b),d=document.getElementsByTagName("head").item(0);c&&d.removeChild(c),css=document.createElement("link"),css.href=a,css.rel="stylesheet",css.type="text/css",css.id=b,d.appendChild(css)}
  loadjs('static/js/bxj/bonezhihui-a3b3d22928349ac7c45f2c774a75187b.js','bonezhihui');
  loadCss('http://7xkaou.com2.z0.glb.qiniucdn.com/warntoast.min.css','warntoastcss');
  loadjs('http://7xkaou.com2.z0.glb.qiniucdn.com/warntoast.min.js','warntoastjs',function(){
    bajian.toast=function(str){
      var options = {
        title: str,
        duration: 5000,
      };
      $toast.show(options);
    }
  });
  loadjs('http://7xkaou.com2.z0.glb.qiniucdn.com/highcharts.js','highcharts');
  })();


</script>
</html>
