
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="static/img/rec.ico">

  <title>孩在身边推荐界面</title>

  <!-- Bootstrap core CSS -->
  <link href="http://cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="static/css/dashboard.css" rel="stylesheet">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->

    </head>

    <body>

      <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <!-- <span class="sr-only">Toggle navigation</span> -->
<!--               <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span> -->
            </button>
            <a class="navbar-brand" href="#">推荐界面</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#">主页</a></li>
              <li><a href="http://lamp.snewfly.com/childAccompanyRec">内部</a></li>
              <li><a href="http://lamp.snewfly.com/childAccompanyRecCom">全体微信</a></li>
            </ul>
            <form class="navbar-form navbar-right">
              <!-- <input type="text" class="form-control" placeholder="Search..."> -->
            </form>
          </div>
        </div>
      </nav>
          <br>
          <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
            <h3 class="page-header">推广记录</h3>
            <div class="table-responsive">
            <div>*退货订单把订单号发给开发者删除记录
            <button onclick="deleteRow('tb_re')" type="button" class="btn btn-success btn-sm">屏蔽0购买的</button>
            </div>
            
              <table id="tb_re" class="table table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>姓名</th>
                    <th>推荐人数</th>
                    <th>购买次数</th>
                    
                  </tr>
                </thead>

                <tbody>

                  <?php
                  define('PAGE_SIZE', 100);
                  define('PAGE_LENGTH', 5);
                  $nameArr=['刘挺','徐文慧','刘滨洲','柴有林','张福祥','何志兰','张莹','叶海媚','左宽','张兆缘','孙康','吴秉桦','骆聪'
                  ,'黄荣登','洪培昇','陈丽榆','王劼','姜川','余卓晋','摆东雪','陈曼曼','叶晓鹏','赖景少','陈家汤','赖伟宏','吴哲佳','胡健聪','郑超锴',''
                  ,'刘挺2','陈翮','刘滨洲','蔡剑','张福祥','柴有林','刘庚华','谢广辉','严靖雅','谢兆榜','魏伟鹏','龚朝辉','李仁旺','陈林'
                  ,'刘东昌','谢鹏飞','李孟新','关政雄','徐丹清','周美芳','陈敏珺','周威宇','谷航','叶海媚','张莹','徐雯慧','黄小钰','周琴'];//56
                  
                  $Re = DB::select('SELECT COUNT(*)total,rec_id FROM rec where type=0 GROUP BY rec_id');//特定rec——id
                  //$reCountBuy=DB::select('SELECT COUNT(*),rec_id FROM rec ,`order` WHERE rec.`type`=0 AND `rec`.`name` = `order`.`buyer_openid` GROUP BY rec_id');
                  
                  $count=count($Re);
                  $page_count = ceil($count/PAGE_SIZE); 
                  $max_p=$page_count; 
                  $pages=$page_count; 
                  //判断当前页码 
                  if(empty($_GET['page'])||intval(Input::get('page'))<0){ 
                    $page=1; 
                  }else { 
                    $page=intval(Input::get('page')); 
                  }
                  $offset=PAGE_SIZE*($page-1); 
                  // $Re=DB::select('SELECT COUNT(*)total,rec_id FROM yg_rec GROUP BY rec_id');
                 //当前页数
                  $nowPage=intval(Input::get('page'));
                  $nowPage=$nowPage==0?1:$nowPage;
                  $count=count($Re);
                  for ($i=0; $i <$count; $i++) { 
                    
                    if (array_key_exists(($Re[$i]->rec_id), $nameArr)) {
                      $name=$nameArr[($Re[$i]->rec_id)];
                    }else{
                      $name='我叫无名';
                    }
                    $color='success';
                    if ($i%2==0) {
                      $color='active';
                    }
                    

                    echo '<tr  class="'.$color.'">
                    <td>'.($i+1).'</td>
                    <td>'.$name.'</td>
                    <td>'.$Re[$i]->total.'</td>
                    <td id="'.$Re[$i]->rec_id.'">0</td>
                    </tr>';
                  }
                  $page_len = (PAGE_LENGTH%2)?PAGE_LENGTH:PAGE_LENGTH+1;//页码个数 
                  $pageoffset = (PAGE_LENGTH-1)/2;//页码个数左右偏移量 
                  // $key='<div class="a_page" align="center">'; 
                  $key='<ul class="pagination"><li><a href="#">'.$page.'/'.$pages.'
                  </a></li><li><a href="/childAccompanyRec">&laquo;</a></li>';
                  // $key.="<span>$page/$pages</span> "; //第几页,共几页 
                  if($page!=1){ 
                  // $key.='<a href="/withdraw">首页</a> '; //第一页 
                  $key.='<li><a href="/childAccompanyRec?page='.($page-1).'">上页</li>'; //上一页 
                }
                $init=1; 
                if($pages>PAGE_LENGTH){ 
                  //如果当前页小于等于左偏移 
                  if($page<=$pageoffset){ 
                    $init=1; 
                    $max_p = PAGE_LENGTH; 
                  }else{//如果当前页大于左偏移 
                  //如果当前页码右偏移超出最大分页数 
                    if($page+$pageoffset>=$pages+1){ 
                      $init = $pages-PAGE_LENGTH+1; 
                    }else{ 
                  //左右偏移都存在时的计算 
                      $init = $page-$pageoffset; 
                      $max_p = $page+$pageoffset; 
                    } 
                  } 
                } 
              // $key='<ul class="pagination">
              // <li><a href="/withdraw">&laquo;</a></li>';
                for($i=$init;$i<=$max_p;$i++){
                  if($i==$page){ 
                    $key.='<li><a href="/childAccompanyRec?page='.$i.'" class="disabled">'.$i.'</li>'; //当前页
                  } else { 
                    $key.='<li><a href="/childAccompanyRec?page='.$i.'">'.$i.'</li>'; 
                  } 
                } 
                if($page!=$pages){ 
              // $key.= '<a href="#">下页</a> ';//下一页 
                  $key.='<li><a href="/childAccompanyRec?page='.($page+1).'">下页</li>'; 
              $key.='<li><a href="/childAccompanyRec?page='.$pages.'">&raquo;</a></li>'; //最后一页 
            }
            $key.='</ul>'; 
            echo $key;
            ?>


          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<!-- SELECT withdraw_log.`account`,withdraw_log.`create_time`,withdraw_log.`money`,withdraw_log.`state`,withdraw_log.`type`,app_certificate.`name` FROM withdraw_log INNER JOIN app_certificate ON withdraw_log.`users_id`=app_certificate.`users_id` -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="http://cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script type="text/javascript">
    showRec();//获取推荐的人的购买次数
  function showRec(){
    $.ajax({
      url:"/getSPRecNum",//用于校验是否同一个用户的
      type:"get",
      dataType: "json",
      success: function (data) {
        if (data.length!=0) {
          for (var i = 0; i <data.length; i++) {
            $('#'+data[i].rec_id).html(data[i].total);
          };
        };
      },
      error: function (msg) {
      }
    });
  }

  function deleteRow(tableid) {
    var tableInfo = "";
    var tableObj = document.getElementById(tableid);
    for (var i = 0; i < tableObj.rows.length; i++) {    //遍历Table的所有Row
        
            tableInfo= tableObj.rows[i].cells[3].innerText;   //获取Table中单元格的内容
            if(tableInfo=="0"){ tableObj.deleteRow(i);i--;}//记得把删掉的序列减掉
    }
    return tableInfo;
}

    </script>
  </body>
  </html>
