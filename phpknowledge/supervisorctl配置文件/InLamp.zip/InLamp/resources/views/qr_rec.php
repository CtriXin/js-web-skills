<!DOCTYPE html>
<html >
<head>
  <meta charset="utf-8">
  <title>会员信息</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="http://cdn.amazeui.org/amazeui/2.4.2/css/amazeui.min.css"/>

</head>
<body>
  <div data-role="page" id="pageLogin" >
    <div  style="height:44px; background-color:#E6E6E6 ; display:-webkit-box; -webkit-box-align:center; -webkit-box-pack:center; color:#5EB95E; font-size:16px; font-weight:bold;" >
      <span style="font-size: 22px;font-family:宋体,Georgia,Serif" >您的专属二维码</span>
    </div>
  </div> 
  <br>

<div style="text-align: center"><img id="img_qr"  />

</div>
<!-- 推荐人数 异步加载-->
<div id="rec_num"></div>

<div style="margin: 5px" class="am-panel am-panel-warning">
  <div class="am-panel-hd">活动说明</div>
  <div class="am-panel-bd">
    <p>1.分享您的专属二维码给朋友</p>
    <p>2.朋友通过您的专属二维码关注“孩在身边”公众号，并购买了儿童手表，则推荐购买人数+1</p>
    <p>3.推荐购买人数达到8人或以上，即可获得三年免通讯费手表一块（价值399）</p>
    <p>4.每位用户限参加一次</p>
    <p>5.购买人数以实际交易为准，不含退货的情况</p>
    <p>6.该活动解释权归深圳市思路飞扬教育科技有限公司所有</p>

  </div>
</div>
<br/>
<!-- <button type="button" id="data_wrong" class="am-btn am-btn-primary am-btn-block doc-animations am-animation-shake" data-doc-animation="shake">孩在身边儿童手表购买链接（微信打开）</button> -->
<a class="am-btn am-btn-primary am-btn-block" href="http://mp.weixin.qq.com/bizmall/malldetail?pid=p4ugXtz-mum5cQyRIGt6RPK8yKVE&biz=MzA3MTc5NzQ3NA==&action=show_detail&showwxpaytitle=1&scene=1&from=singlemessage&isappinstalled=0#wechat_redirect" target="_blank">孩在身边儿童手表购买链接（微信打开）</a>
<br/>
<!-- http://mp.weixin.qq.com/bizmall/malldetail?pid=p4ugXtz-mum5cQyRIGt6RPK8yKVE&biz=MzA3MTc5NzQ3NA==&action=show_detail&showwxpaytitle=1&scene=1&from=singlemessage&isappinstalled=0#wechat_redirect -->
<div style="text-align: center"><!-- <button style="padding-left: 5px;padding-right: 5px;width: 80%;text-align: center" type="button" id="login" class="am-btn am-btn-danger ">切换账号</button> -->
<a style="padding-left: 5px;padding-right: 5px;width: 80%;text-align: center" class="am-btn am-btn-danger" href="http://lamp.snewfly.com/hzsb_login_page_qr" target="_blank">切换账号</a>

</div>
<br/>
  <button
  id="btn_myAlert"
  style="display: none;"
  type="button"
  class="am-btn am-btn-primary"
  data-am-modal="{target: '#my-alert',closeViaDimmer: 0}">
  Alert
</button>

<div class="am-modal am-modal-alert" tabindex="-1" id="my-alert">
  <div class="am-modal-dialog">
    <div class="am-modal-hd">温馨提示</div>
    <div class="am-modal-bd" id="myAlert_value">

    </div>
    <div class="am-modal-footer">
      <span class="am-modal-btn">确定</span>
    </div>
  </div>
</div>

</body>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/jquery-2.1.4.min.js"></script>
<script src="http://7xkaou.com2.z0.glb.qiniucdn.com/amazeui2.x.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    var progress = $.AMUI.progress;
    function startProgress(){
      progress.start();
    }
    function stopProgress(){
      progress.done();
    }

function myAlert(value){

  $("#myAlert_value").html(value);
  $('#btn_myAlert').click();
}

$('#btn_login').click(function(){

});

showImg();
resetRect();
showRec(GetRequest()['phone']);
checkImg();

function showImg(){
  var ticket=GetRequest()['ticket'];

  var img_src=$('#img_qr').attr('src');
  if (img_src!="" && img_src!=null) {
    
  }else if(ticket!=""){//离线模式
    $('#img_qr').attr('src',"https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket="+ticket+"==");
  }
}

function checkImg(){
  var img_src=$('#img_qr').attr('src');
  if (img_src!="" && img_src!=null) {
  }else{//隐藏，一般不出现这情况
    $('#img_qr').hide();
  }
}

function resetRect(){
          var h = $(window).width();
        if (h>700) {h=700;}
        h=h*0.8;
        $("#img_qr").css("width", h);
        $("#img_qr").css("height", h);
}


  function showRec(phone){
    $.ajax({
      url:"/getRecNum?phone="+phone,//用于校验是否同一个用户的
      type:"get",
      dataType: "text",
      success: function (data) {
        if(data!="" || data=='0') {
          set_rec_num("当前推荐购买人数："+data);
        };
      },
      error: function (msg) {
      }
    });
  }


});

 $('#data_wrong').click(function(){
       window.location="http://mp.weixin.qq.com/bizmall/malldetail?pid=p4ugXtz-mum5cQyRIGt6RPK8yKVE&biz=MzA3MTc5NzQ3NA==&action=show_detail&showwxpaytitle=1&scene=1&from=singlemessage&isappinstalled=0#wechat_redirect";
    
      });

 $('#login').click(function(){
       window.location="http://lamp.snewfly.com/hzsb_login_page_qr";
    
      });

function set_rec_num(str){
  var showmsg=getShowMsg(str,'success');
  $('#rec_num').html(showmsg);
}

$(':button').click(function(){
  var a=$(this),i="am-animation-"+a.data("docAnimation");a.data("animation-idle")&&clearTimeout(a.data("animation-idle")),a.removeClass(i),setTimeout(function(){a.addClass(i),a.data("animation-idle",setTimeout(function(){a.removeClass(i),a.data("animation-idle",!1)},500))},50);
});


//封装的提示块：color=success,warning,danger,secondary,primary
function getShowMsg(value,color){
  var msg='<div id="showmsg" class="am-alert am-alert-'+color+' am-animation-slide-left" data-am-alert><button type="button" class="am-close">&times;</button><p style="text-align: center">'+value+'</p></div>';
  return msg;
}

function GetRequest() {
var url = location.search; //获取url中"?"符后的字串 
var theRequest = new Object(); 
if (url.indexOf("?") != -1) {
  var str = url.substr(1); 
  strs = str.split("&"); 
  for(var i = 0; i < strs.length; i ++) {
    theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
  } 
} 
return theRequest; 
}


</script>

</html>
