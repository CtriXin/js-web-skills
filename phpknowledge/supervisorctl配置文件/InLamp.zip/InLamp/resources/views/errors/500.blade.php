<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>访问出错</title>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style type="text/css">
  .text-center{text-align: center;}
</style>
</head>
<body>

<div class="text-center" style="margin-top: 100px">
        <div style="vertical-align: center;"><p class="am-text-center">出错啦...服务器更新中，请稍后访问</p>
        <pre >
          .----.
       _.'__    `.
   .--($)($$)---/#\
 .' @          /###\
 :         ,   #####
  `-..__.-' _.-\###/
        `;_:    `"'
      .'"""""`.
     /,  ya ,\\
    //  500!  \\
    `-._______.-'
    ___`. | .'___
   (______|______)
        </pre></div>
</div>

<div style="bottom: 10px;position: fixed;width: 90%;">
  <div class="text-center">Copyright  2016 © 思路飞扬科技</div>
</div>

</body>
</html>
