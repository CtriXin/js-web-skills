<!DOCTYPE html>
<html>
    <head>
        <title>服务器亚历山大</title>
  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <style>
            html,body{height:100%}body{margin:0;padding:0;width:100%;color:#b0bec5;display:table;font-weight:100;font-family:'Lato'}.container{text-align:center;display:table-cell;vertical-align:middle}.content{text-align:center;display:inline-block}.title{font-size:25px;margin-bottom:40px}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">场面火爆，稍后访问</div>
            </div>
        </div>
    </body>
</html>