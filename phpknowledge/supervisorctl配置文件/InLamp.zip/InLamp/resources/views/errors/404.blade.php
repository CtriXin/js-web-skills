<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>23333</title>
  <meta name="description" content="这是一个404页面">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<style type="text/css">
  .text-center{text-align: center;}
</style>
</head>
<body>

<div class="text-center" style="margin-top: 100px">
        <div style="vertical-align: center;"><img width="100%" style="max-width: 700px" src="http://static.hdslb.com/error/404.png" alt=""></div>
</div>

<div style="bottom: 10px;position: fixed;width: 90%;">
  <div class="text-center">Copyright  2016 © 思路飞扬科技</div>
</div>

</body>
</html>
