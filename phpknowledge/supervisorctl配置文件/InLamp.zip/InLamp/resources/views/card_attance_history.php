<!-- 首页 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<!-- 自动探测电话号码 -->
	<meta name="format-detection" content="telephone=no">
	<meta http-equiv="x-rim-auto-match" content="none">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<title>学生卡</title>
	<link rel="stylesheet" href="assets/agile/css/agile.layout.css">
	<link rel="stylesheet" href="assets/agile/css/ratchet/css/ratchet.min.css">
	<link rel="stylesheet" href="assets/agile/css/flat/flat.component.css">
	<link rel="stylesheet" href="assets/agile/css/flat/flat.color.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconline.css">
	<link rel="stylesheet" href="assets/component/timepicker/timepicker.css">
	<link rel="stylesheet" href="assets/app/css/app.css">

	<link rel="stylesheet" href="assets/agile/css/flat/iconline.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconform.css">
	<link rel="stylesheet" href="assets/agile/css/flat/iconlogo.css">  
<style type="text/css">
	.li_out{background-color: #F5F5F5}
</style>

</head>
<body>
	<div id="section_container">
		<!-- 主页section -->
		<section id="section_cardcenter" data-role="section" class="active">
			<header class="bar bar-nav">
				<h1 class="title">考勤历史</h1>
			</header>
			<article data-role="article" id="article_cardcenter" data-scroll="pullup" class="active" style="top:44px;">

				<div class="scroller">

					<form class="form-group">
						
						<div class="card">
							<ul id="lv_history" class="listitem" style="background-color: #ECF4F8;">
								<li >暂无历史数据</li>
								<!-- 默认打开就查前200条 -->

							</ul>
						</div>
					</form>

					<form autocomplete="off" oninput="range_output.value=parseInt(range.value)" class="form-square">
						<label class="label-left" for="date">起始</label>
						<div data-role="date" class="label-right">
							<label>请选择查询日期</label>
							<input id="begin_date" type="hidden"/>
						</div>
						<label class="label-left" for="date">结束</label>
						<div data-role="date" class="label-right">
							<label>请选择查询日期</label>
							<input id="end_date" type="hidden"/>
						</div>
						<button id="btn_search" class="block">查&nbsp;&nbsp;询</button>
					</form>

				</div>	


			</article>

		</section>




	</div>
	<!--- third -->
	<script src="assets/third/zepto/zepto.min.js"></script>
	<script src="assets/third/arttemplate/template-native.js"></script>	
	<script src="assets/third/jquery/jquery-2.1.3.min.js"></script>
	<script src="assets/third/jquery/jquery.mobile.custom.min.js"></script>
	<script src="assets/third/iscroll/iscroll-probe.js"></script>
	<script src="assets/third/arttemplate/template-native.js"></script>
	<!-- agile -->
	<script type="text/javascript" src="assets/agile/js/agile.js"></script>		
	<!--- bridge -->
	<script type="text/javascript" src="assets/bridge/exmobi.js"></script>
	<script type="text/javascript" src="assets/bridge/agile.exmobi.js"></script>
	<!-- component timepicker-->
	<script type="text/javascript" src="assets/component/timepicker/agile.timepicker.js"></script>
	<script type="text/javascript" src="assets/component/extend.js"></script>

	<!-- app -->
	<script type="text/javascript" src="assets/app/js/app.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {

		$('#article_cardcenter').on('refreshInit', function(){//首页每次展示调用，考虑到频繁recreate，以后可以使用articleload
			ajax_getHistory('','');

		});


		$('#btn_search').on(A.options.clickEvent, function(){

			var begin_date=$('#begin_date').val();
			var end_date=$('#end_date').val();
			ajax_getHistory(begin_date,end_date);
			return false;
		});

		function ajax_getHistory(begin_date,end_date){
			if (GetRequest()['userId']==undefined||GetRequest()['device_id']==undefined) {
				A.showToast('访问链接缺少参数');
				return ;
			}
			ajax_get('/getAttanceHistory?userid='+GetRequest()['userId']+'&device_id='+GetRequest()['device_id']+'&begin_date='+begin_date+"&end_date="+end_date,handlerHistory);
		}

		function ulAddLi(arr){
			var refresh = A.Refresh('#article_cardcenter');
			var ul=$('#lv_history');
		  ul.html('');//先清空ul
		  var len=arr.length;
		  for (var i = 0; i < len; i++) {
		  	if (arr[i].type=='出') {
		  		var li='<li class="li_out"> '+arr[i].time+' '+arr[i].student_name+' '+arr[i].type+'校</li>';
		  	}else{
		  		var li='<li> '+arr[i].time+' '+arr[i].student_name+' '+arr[i].type+'校</li>';
		  	}
		  	
		  	ul.append(li);
  		}
		  refresh.refresh();
	}

function handlerHistory(data){
			// alert(data);
			if (data.errcode=='0') {
				var arr=data.data.records;
				ulAddLi(arr);
			}else{
				if (data.errmsg!='') {
					A.showToast(data.errmsg);
				}
			}
		}

		function GetRequest() {
		var url = location.search; //获取url中"?"符后的字串 
		var theRequest = new Object(); 
		if (url.indexOf("?") != -1) {
			var str = url.substr(1); 
			strs = str.split("&"); 
			for(var i = 0; i < strs.length; i ++) {
				theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]); 
			} 
		} 
		return theRequest; 
	}

      /*
        * by hgx 15-11-28
        * 统一处理ajax get 请求（返回json格式），成功分发回调函数处理,失败统一提示
        * @param url 完成get 请求url,可不带上host
        * @param succCallback succ 回调 可空
        * @param dataType 返回值类型 可空 默认json
        * @param failCallback fail 回调 可空 defaultFailCallback
        */
        function ajax_get(url,succCallback,dataType,failCallback){

        	if (url=="") {return;}
        	dataType=(dataType==undefined||dataType=="")?"json":dataType;
        	failCallback=failCallback==undefined?defaultFailCallback:failCallback;

        	$.ajax({
        		url:url,
        		type:"get",
        		dataType: dataType,
        		success: function (data) {
        			if (succCallback!=undefined) {
                succCallback(data);//允许undefined
            }
        },
        error: function (msg) {
        	failCallback(msg);
        }
    });
        }
 //handle fialure result callback section:

 function defaultFailCallback(msg){
 	A.showToast('网络错误');
 }


});

</script>
</body>
</html>