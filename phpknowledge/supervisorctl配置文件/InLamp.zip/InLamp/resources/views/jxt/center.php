<?php if(!isset($_SESSION)) session_start(); ?>
<!-- 首页 -->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<title>家校互动</title>
<link rel="stylesheet" href="card_assets/agile/css/agile.layout.css?1">
<link rel="stylesheet" href="card_assets/agile/css/flat/flat.component.css?1">
<link rel="stylesheet" href="card_assets/agile/css/flat/flat.color.css?1">
<link rel="stylesheet" href="card_assets/agile/css/flat/iconline.css?1">
<link rel="stylesheet" href="card_assets/agile/css/flat/iconform.css?1">
<link rel="stylesheet" href="card_assets/app/css/app.css?1">
<link rel="stylesheet" href="card_assets/app/css/jxt.min.css">

</head>
<body>
<div id="section_container">
	<!-- 主页section -->
	<section id="section_center" data-role="section" class="active">
	<header class="titlebar">
	<h1 class="title">首页</h1>
	<a data-toggle="section" href="#section_account" data-transition="slidedown"><i class="iconfont iconline-uid"></i></a>
	</header>
	<article data-role="article" data-scroll="pulldown" id="article_center" data-scroll="verticle" class="active myarticle">
	<div class="scroller padded">
		<form class="form-group " style="margin-top:1px" id="form_key">
			<div data-role="select" class="card nopadding jumbotron raise ui-select">
				<span id="select_device_sp">未绑定学生卡</span>
				<select id="select_device" placeholder="选择学生卡">
					<option value="" selected="true">未绑定学生卡</option>
				</select>
			</div>
		</form>
		<div class="grid padded" data-col="2">
			<div id="btn_contact" class="grid-cell">
				<div class="raise mg">
					<img class="img_icon" src="http://7xkaou.com2.z0.glb.qiniucdn.com/jxt_i_contact_c.png"><br>
					<div>
						<b>联系方式</b>
					</div>
				</div>
			</div>
			<div id="btn_grade" class="grid-cell">
				<div class="raise mg">
					<img class="img_icon" src="http://7xkaou.com2.z0.glb.qiniucdn.com/jxt_i_score_c.png"><br>
					<b>成绩查询</b>
				</div>
			</div>
			<div id="btn_notice" class="grid-cell">
				<div class="raise mg">
					<img class="img_icon" src="http://7xkaou.com2.z0.glb.qiniucdn.com/jxt_i_notice_c.png"><br>
					<b>通知查询</b>
				</div>
			</div>
			<div id="btn_homework" class="grid-cell">
				<div class="raise mg">
					<img class="img_icon" src="http://7xkaou.com2.z0.glb.qiniucdn.com/jxt_i_homework_c.png"><br>
					<b>作业查询</b>
				</div>
			</div>
		</div>
	</div>
	</article>
	</section>
	<section id="section_contact" data-role="section">
	<!-- 联系方式 -->
	<header class="titlebar">
	<a data-toggle="back" href="#"><i class="iconfont iconline-arrow-left"></i><b style="font-size: 18px">返回</b></a>
	<h1 class="title">联系方式</h1>
	</header>
	<article data-role="article" id="article_contact" class="active myarticle" data-scroll="verticle">
	<div class="scroller padded">
		<div id="container_contact">
		</div>
	</div>
	</article>
	</section>
	<section id="section_grade" data-role="section">
	<!-- 成绩查询 -->
	<header class="titlebar">
	<a data-toggle="back" href="#"><i class="iconfont iconline-arrow-left"></i><b style="font-size: 18px">返回</b></a>
	<h1 class="title">成绩查询</h1>
	</header>
	<article data-role="article" id="article_grade" class="active myarticle" data-scroll="verticle">
	<div class="scroller padded">
		<div id="container_grade">
		</div>
	</div>
	</article>
	</section>
	<section id="section_notice" data-role="section">
	<!-- 通知查询 -->
	<header class="titlebar">
	<a data-toggle="back" href="#"><i class="iconfont iconline-arrow-left"></i><b style="font-size: 18px">返回</b></a>
	<h1 class="title">通知查询</h1>
	</header>
	<article data-role="article" id="article_notice" class="active myarticle" data-scroll="verticle">
	<div class="scroller padded">
	<div id="container_notice"></div>
		
	</div>
	</article>
	</section>
	<section id="section_homework" data-role="section">
	<!-- 作业查询 -->
	<header class="titlebar">
	<a data-toggle="back" href="#"><i class="iconfont iconline-arrow-left"></i><b style="font-size: 18px">返回</b></a>
	<h1 class="title">作业查询</h1>
	</header>
	<article data-role="article" id="article_homework" class="active myarticle" data-scroll="verticle">
	<div class="scroller padded">
		<form class="form-group" style="margin-top:1px" id="form_key">
			<div data-role="select" class="card nopadding jumbotron raise ui-select">
				<span id="select_subject_sp">选择科目</span>
				<select id="select_subject" placeholder="选择科目">
					<option class="full-width" value="" selected="true">没有科目</option>
				</select>
			</div>
		</form>
		<div id="container_homework">
		</div>
	</div>
	</article>
	</section>
	<section id="section_account" data-role="section">
	<!-- 账户 -->
	<header class="titlebar">
	<a data-toggle="back" href="#"><i class="iconfont iconline-arrow-left"></i><b style="font-size: 18px">返回</b></a>
	<h1 class="title">账户</h1>
	</header>
	<article data-role="article" id="article_account" class="active myarticle" data-scroll="verticle">
	<div class="scroller">
		<div class="card">
			<ul class="listitem">
				<li><?php echo $_SESSION['card_loginName'];?>
				</li>
				<li>
				<i class="icon-color-blue ricon iconfont iconline-arrow-right"></i>
				<a data-toggle="html" href="http://rcatc.snewfly.com/htmlify?url=doc/card_help.html"><div class="text">帮助信息</div></a>
				</li>
			</ul>
		</div>
		<div class="padded">
			<a href="jxt_login_page#Login_section"><button class="block cancel">切换账户</button></a>
		</div>
	</div>
	</article>
	</section>
</div>
	<!--- third -->
	<script src="card_assets/third/zepto/zepto.min.js"></script>
	<script src="card_assets/third/iscroll/iscroll-probe.js?12"></script>
	<script src="card_assets/third/arttemplate/template-native.js?12"></script>
	<!-- agile -->
	<script type="text/javascript" src="card_assets/agile/js/agile.min.js?1"></script>
	<!-- app -->
	<script type="text/javascript" src="card_assets/app/js/app.js?12"></script>
	<script type="text/javascript" src="http://7xkaou.com2.z0.glb.qiniucdn.com/myajax1.1-min.js"></script>

    <script type="text/javascript" src="card_assets/app/js/jxt.min-f5b219e65f8d90faccca89ea99b8a109.js"></script>

</body>
</html>