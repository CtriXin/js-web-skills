<!-- 登录 -->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
	<title>家校通</title>

	<link rel="stylesheet" href="card_assets/agile/css/agile.layout.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.component.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/flat.color.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconline.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconform.css?1">
	<link rel="stylesheet" href="card_assets/agile/css/flat/iconlogo.css?1">
	<link rel="stylesheet" href="card_assets/app/css/app.css?1">

</head>
<body>
	<div id="section_container">
		<section id="Login_section" data-role="section" class="active">
			<header class="titlebar">
				<h1 class="title">用户登录</h1>
			</header>
			<article data-role="article" id="flat_article" data-scroll="verticle" class="active" style="top:44px;">
				<div class="scroller padded">

					<form autocomplete="false"  class="form-common">
						<label class="label-left" for="user" style="width: 40px"><span class="iconfont iconline-uid"></span></label>
						<label class="label-right">
							<input id="user" type="tel" placeholder="手机号" maxlength=11 title="手机号" value="" />
						</label>
						<hr style="margin-top: 1px" /><br/>
						<label class="label-left" for="password"  style="width: 40px"><span class="iconfont iconline-lock"></span></label>
						<label class="label-right">
							<input id="pwd"  type="password" value="" title="密码" placeholder="密码" required/>
						</label>
						<hr style="margin-top: 2px" /><br/>
						
					</form>
					<div><a href="hzsb_register_page_zhihui?jxt=1" style="float: right;margin: 8px">立即注册</a></div>
					<button id="login" class="block">
						登&nbsp;&nbsp;录
					</button>
					<div><a href="hzsb_reset_pwd_page?jxt=1" style="float: left;margin: 8px">忘记密码</a><a href="hzsb_edit_pwd_page?jxt=1" style="float: right;margin: 8px">修改密码</a></div>
				</article>
			</section>
		</div>
		<script src="card_assets/third/zepto/zepto.min.js"></script>
		<!--- third -->
		<!-- agile -->
		<script type="text/javascript" src="card_assets/agile/js/agile.min.js?1"></script>
		<!-- app -->
		<script>

			$(document).ready(function(){

				$('#login').click(function(){
					var user=$('#user').val().trim();
					var pwd=$('#pwd').val().trim();

					if (user.length!=11) {
						A.showToast('手机号格式错误');
						return;
					}
					if (pwd!="" && user!="") {
						$("#login").attr("disabled", true);
						login(user,pwd);
					}else{
						A.showToast('账号或者密码为空');
					}
				});


				function login(user,pwd){
					$.ajax({
						url:"/card_login?name="+user+"&pwd="+pwd+"&r="+Math.random(),
						type:"get",
						dataType: "json",
						success: function (data) {
							$("#login").removeAttr('disabled');
							if (data.code=='S000000') {
								window.location.href='/jxt_center_page?r='+Math.random();
							}else if (data.msg!='') {
								A.showToast(data.msg);
								if (data.code=='101') {
									setTimeout(function(){
										window.location.href='http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_jxt&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect';
									},800);
								}
							}else{
								A.showToast('登录失败');
							}

						},
						error: function (msg) {
							$("#login").removeAttr('disabled');
							A.showToast('网络错误，请稍后重试');
						}
					});
				}
			});
</script>
<script type="text/javascript" src="card_assets/app/js/app.js?1"></script>
</body>
</html>