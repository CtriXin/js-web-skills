<!DOCTYPE html>
<html>
<head>
	<title>
		主页
	</title>
	<meta charset='utf8'>
	<link rel="stylesheet" href="static/css/index.css">
	<link rel="stylesheet" href="static/css/edit.css">
</head>
<body>

<div class="container">
<!-- Left  begin	-->
	<div class="left">
		<a class="menu home" href="/"></a>
	</div>
<!-- Left  finish	-->

<!-- Right  begin	-->
	<div class="right">
		<div class="header">
			<div class="profile">
				<img src="static/img/user.jpg" id="avatar"alt="user">
				<span>Admin </span>			
				<div class="menu">
					<ul>
						<li>
							<a href="/logout">
								<div class="logout">&nbsp;</div>
								登出
							</a>
						</li>
						<li>

							<a href="">
								<div class="edit">&nbsp;</div>
								修改密码
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="content">
			<div class="edit">
				&nbsp;
				<div class="header">
					<div class="logo"></div>
					<span>修改密码</span>
				</div>
				<form action="" class="edit_password">
					<span>新密码</span>
					<input type="password" id="password" name="PWD">
					<span>确认密码</span>
					<input type="password" id="retype">
					<input type="button" value="确认" name="confirm" class="confirm">
				</form>
			</div>
		</div>
	</div>
<!-- Right  finish	-->
</div>

</body>
<script type="text/javascript" src="static/js/lib/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="static/js/index.js"></script>
<script type="text/javascript" src="static/js/edit.js"></script>
</html>