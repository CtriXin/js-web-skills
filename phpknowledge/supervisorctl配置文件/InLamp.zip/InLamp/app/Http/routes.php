<?php

Route::get('/login', function()
{
	return View::make('login');
});
Route::get('/','AdminController@index');
Route::get('/index',function(){
	return View::make('index');
});
Route::post('/test','TestController@test');
Route::post('/login',"UserController@login");
Route::post('/img','FileController@image');
Route::post('/audio','FileController@audio');
Route::get('/getToken','FileController@getToken');
Route::get('audio/get','FileController@get');
Route::get('/send', 'FileController@send');
Route::get('/download',array('as' => 'download','uses' =>function(){
	$filePath = Input::get('filePath');
	$file = public_path().'/'.$filePath;
	return Response::download($file);
}));


Route::get('/wechat','WechatResponseController@check');
/*
Route::post('/wxyg','WechatResponseController@response');
Route::get('/wxyg','testwechat@check');*/
Route::post('/wechat','WechatResponseController@response');
Route::get('/wxdemo','WechatAuthController@wxdemo');
Route::get('/wxdemo3','WechatAuthController@wxdemo3');
Route::get('/downloadVoice', 'WechatAuthController@downloadVoice');//下载微信音频

// Route::get('/getTicket','WechatAuthController@getTicket1');//生成参数二维码ticket

// Route group
$router->group(['middleware' => 'cardauth'], function() {
    // lots of routes that require wechatauth middleware
    Route::get('/wechatinfo', 'CardRouteController@wechatinfo');//查看微信用户信息
    
    //学生卡：
    Route::get('/queryDevice', 'CardRouteController@queryDevice');//学生卡查询绑定设备
    Route::get('/submitEditDevice', 'CardRouteController@submitEditDevice');//学生卡绑定编辑设备
    Route::get('/card_getMsgCenter', 'CardRouteController@card_getMsgCenter');//
    Route::get('/getBindPhoneByImei', 'CardRouteController@getBindPhoneByImei');//
    Route::get('/deleteDevice', 'CardRouteController@deleteDevice');//
    Route::get('/submitManageSettings', 'CardRouteController@submitManageSettings');//shebeiguanli
    Route::get('/submitToggleAttendance', 'CardRouteController@submitToggleAttendance');//到离校通知设置
    Route::get('/submitSchoolManage', 'CardRouteController@submitSchoolManage');//到上課禁用设置
    Route::get('/getNewLocation', 'CardRouteController@getNewLocation');//获取实时定位
    Route::get('/shutdown', 'CardRouteController@shutdown');//获取实时定位

    Route::get('/card_center_page', 'CardRouteController@showCardCenterPage');
    
    Route::get('/card_downloadVoice', 'ZhihuiWechatAuthController@card_downloadVoice');//下载微信音频

	//xsk route end

	Route::get('/jxt_center_page', 'JxtRouteController@showCenterPage');
});


// Route group
$router->group(['middleware' => 'bxjauth'], function() {
    // lots of routes that require bxjauth middleware #TODO
	Route::get('/wxdemo_zhihui','LampRouteController@wxdemo');
});

// Route group wx auth check
$router->group(['middleware' => 'wechatauth'], function() {
    // lots of routes that require wechatauth middleware
	Route::get('/hzsb_login_zhihui', 'ZhihuiWechatAuthController@hzsb_login');//还在身边登录
	Route::get('/card_login', 'ZhihuiWechatAuthController@card_login');//

});


// Route group
$router->group(['prefix' => 'zhihui','middleware' => 'bxjauth'], function() {
    // lots of routes that require bxjauth middleware
    Route::get('/getdevice', 'LampRouteController@getdevice_zhihui');//获取用户伴学机
    Route::get('/getDailyData', 'LampRouteController@getDailyData_zhihui');//获取用户伴学机学习数据
    Route::get('/getdeviceData', 'LampRouteController@getdeviceData');//获取伴学机学习数据

    Route::get('/bindDevice', 'LampRouteController@bindDevice');//绑定伴学机
    Route::get('/editDevice', 'LampRouteController@editDevice');//绑定伴学机
    Route::get('/unbindDevice', 'LampRouteController@unbindDevice');//解绑伴学机

    Route::get('/downloadVoice', 'ZhihuiWechatAuthController@downloadVoice');//下载微信音频
    
});

// Route group
$router->group(['prefix' => 'token'], function() {
    
    Route::get('/zhjy_access_token','TokenController@getZHJYAccessToken');
    Route::get('/refresh_zhjy_access_token','TokenRefreshController@zhjyAccessToken');
    Route::get('/zhjy_jsapi_ticket','TokenController@getZHJYJsApiTicket');
    Route::get('/refresh_zhjy_js_ticket','TokenRefreshController@zhjyJsApiTicket');
    
});

$router->group(['prefix' => 'jxt','middleware' => 'jxtauth'], function() {
    Route::get('/queryDevice', 'JxtRouteController@queryDevice');
    Route::get('/queryContact', 'JxtRouteController@queryContact');
    Route::get('/querySubject', 'JxtRouteController@querySubject');
    Route::get('/queryAllScore', 'JxtRouteController@queryAllScore');
    Route::get('/queryHomework', 'JxtRouteController@queryHomework');
    Route::get('/queryNotice', 'JxtRouteController@queryNotice');

});

$router->group(['prefix' => 'jxt'], function() {
    Route::any('/push', 'JxtController@push');
});

$router->group(['prefix' => 'card'], function() {
    Route::any('/attendanceConfirm', 'CardSignRequestController@attendanceConfirm');//考勤反馈
});

Route::any('/card_msgcenter', 'CardController@card_msgcenter');//学生卡接收消息接口
Route::any('/lamp_msgcenter', 'LampPushController@lamp_msgcenter');//伴学机接收消息接口

Route::get('/delRecAudio', 'CardController@delRecAudio');//删除接收到的消息redis

Route::any('/card_sign', 'CardSignController@card_sign');//考勤
Route::any('/card_sign_request', 'CardSignRequestController@cardSignRequest');//考勤反馈给老师

Route::any('/getAttanceHistory', 'CardSignController@getAttanceHistory');

// Route::get('/sql','Sql@test');
// Route::get('/testSession','WechatAuthController@Tsession');
// Route::get('/mg', 'WechatAuthController@mg');//测试mongodb

Route::get('/auth', 'WechatAuthController@users_center_qr');//二维码通道
Route::get('/auth2', 'WechatAuthController@hzsb_getOpenid');//还在身边登录auth

Route::get('/auth_bxj', 'ZhihuiWechatAuthController@hzsb_getOpenid');//还在身边登录auth
Route::get('/auth_card', 'ZhihuiWechatAuthController@auth_card');//xsk 登录auth
Route::get('/auth_card_test', 'ZhihuiWechatAuthController@auth_card_test');//xsk 登录auth

Route::get('/auth_jxt', 'ZhihuiWechatAuthController@auth_jxt');//家校通 登录auth
Route::get('/auth3', 'ZhihuiWechatAuthController@hzsb_getOpenid3');//还在身边登录auth测试接口
Route::get('/hzsb_login', 'WechatAuthController@hzsb_login');//还在身边登录
Route::get('/hzsb_sendSMS', 'ZhihuiWechatAuthController@hzsb_sendSMS');//还在身边发送手机验证码
Route::get('/hzsb_register', 'ZhihuiWechatAuthController@hzsb_register');//还在身边发送手机验证码
Route::get('/hzsb_resetpwd', 'ZhihuiWechatAuthController@hzsb_resetpwd');
Route::get('/hzsb_editpwd', 'ZhihuiWechatAuthController@hzsb_editpwd');
Route::get('/getdevice', 'ZhihuiWechatAuthController@getdevice');//获取用户一体机
Route::get('/getUserName', 'ZhihuiWechatAuthController@getUserName');//获取用户昵称
Route::get('/getdeviceData', 'WechatAuthController@getdeviceData');//获取用户一体机学习数据
Route::get('/getDailyData', 'ZhihuiWechatAuthController@getDailyData');//获取用户一体机学习数据

// Route::get('/spt', 'SinglePushTest@pushTarget');//用来推送模板给个别用户的
Route::get('/getRecNum', 'WechatAuthController@getRecNum');//获取用户推荐数，需要向微信增量调用订单接口并保存到服务器
Route::get('/getSPRecNum', 'WechatAuthController@getSPRecNum');//通过id推荐的 批量获取用户推荐数，需要向微信增量调用订单接口并保存到服务器

Route::get('/card_login_page', function(){
		return View::make('card.card_login');
	});

Route::get('/jxt_login_page', function(){
		return View::make('jxt.login');
	});

Route::get('/hzsb_login_page', function(){
	return View::make('wxlogin');//登录办学机
});

Route::get('/hzsb_login_page_zhihui', function(){
	return View::make('lamp.wxlogin_zhihui');//登录办学机zhihuijiaoyu
});

Route::get('/hzsb_login_page_qr', function(){
	return View::make('wxlogin_qr');//登录用户中心qr二维码
});

Route::get('/qr_rec', function(){
	return View::make('qr_rec');//用户中心qr二维码
});

Route::get('/hzsb_register_page', function(){
	return View::make('register');//注册
});

Route::get('/hzsb_register_page_zhihui', function(){
	return View::make('user.register_zhihui');//注册
});

Route::get('/hzsb_edit_pwd_page', function(){
	return View::make('user.edit_pwd');//修改密码
});

Route::get('/hzsb_reset_pwd_page', function(){
	return View::make('user.resetpwd');//重置密码
});

//学伴机微信help
Route::get('/xbjhelp', function(){
	return View::make('help');
});
//获取用户一体机学习数据
Route::get('/hzsb_login_page3', function(){
	return View::make('wxlogin3');
});//测试接口

Route::get('/contact', function(){
	return View::make('contact');
});//交流
Route::get('/rest', function(){
	return View::make('rest');
});//请假


Route::get('/childAccompanyRec',function(){
	return View::make('queryRec');
});

Route::get('/childAccompanyRecCom',function(){//面向全体
	return View::make('queryRecCom');
});

//clock:
Route::get('/clockApp',function(){
	return '<!DOCTYPE html><html><head>	<title></title></head><body></body><script type="text/javascript">	document.location="http://babyfeet.aliguli.com/api/get_download_url.php?lang=cn&ca=default";</script></html>';
	// return '可变页面';
});