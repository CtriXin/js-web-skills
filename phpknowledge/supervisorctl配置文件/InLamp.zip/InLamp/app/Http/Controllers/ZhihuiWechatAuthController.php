<?php
namespace App\Http\Controllers;

use App\Http\Controllers\WechatBaseController;
use Log;
use Input;
use DB;
use View;

require_once('lib/Tool.php');
require_once('lib/Http.php');
require_once('lib/MyWechat.php');
require_once('lib/Card.php');
require_once('lib/Lamp.php');
require_once('lib/Lampv2.php');
use MyWechat;
use Card;
use Lamp;
use Lampv2;
use Tool;
use Http;


define('REMOTE_HOST', 'http://120.24.76.242:8686/hzsbServer/');//登录成功标志
define('Audio_HOST', 'http://bxjtest.snewfly.com/');//
// define('Audio_HOST', 'http://lamp.snewfly.com/');//
define('LOGIN_URL', REMOTE_HOST.'wechat/login.action');//登录url
define('GETDEVICE_URL', REMOTE_HOST.'wechat/getdevice.action');//获取设备
define('GETDAILYDATA_URL', REMOTE_HOST.'xbj/chatbynow.action');//获取设备每日数据
define('GETMONTHLYDATA_URL', REMOTE_HOST.'xbj/querybychat.action');//获取设备每月数据
define('GET_USER_NAME_URL', REMOTE_HOST.'wechat/getnamebyphone.action');//获取自己昵称

define('CODE_S', 'S000000');
define('CODE_TYPE_BXJ', 'S002');//伴学机type
define('CODE_TYPE_XSK', 'S003');//学生卡

define('URL_AUTH_LOGIN', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_bxj&response_type=code&scope=snsapi_base&state=SUISHI');
define('URL_AUTH_LOGIN_QR', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_zhihui&response_type=code&scope=snsapi_base&state=SUISHI');
define('URL_AUTH_LOGIN_XSK', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_card&response_type=code&scope=snsapi_base&state=SUISHI');
define('URL_AUTH_LOGIN_XSK_TEST', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_card_test&response_type=code&scope=snsapi_base&state=SUISHI');
define('URL_AUTH_LOGIN_JXT', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_jxt&response_type=code&scope=snsapi_base&state=SUISHI');

define('NET_ERR', '网络错误，请稍后重试');
define('PAGE_ERR', '页面过期，请重新从公众号进入');
define('RELOG_ERR', "请重新登录<script type='text/javascript'>alert('请重新登录');close();</script>");

set_time_limit(0);



/**
 * Class WechatAuthController
 * @package App\Http\Controllers
 * anthor hgx
 */
class ZhihuiWechatAuthController extends ZhihuiWechatBaseController{

    private $openid,$uid;
    //智慧教育
    private static $appId='wx2683432074892f86';
    private static $secret='9147009bbad321887c93b17cc1989c7e';
    public function __construct(){
    	if(!isset($_SESSION)){
    		session_start();   //开启session
      }
    }


  //生成ticket、获取链接
/*  public function getTicket1()
  {
    // for ($i=0; $i < 80; $i++) { 
    //   $this->getTicketExtra($i);
    // }
    // return 'finish';
    // https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=
    $prefix='https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=';
    $reArr=DB::select('select * from ticket_extra where rec_id>48 and rec_id<590');
    $str='';
    for ($i=0; $i <count($reArr) ; $i++) { 
      $str.=$reArr[$i]->rec_id.'|'.$prefix.$reArr[$i]->ticket.'<br/>';
    }

    return $str;
  }*/

  /**
  * 学生卡登录
  * @return json
  */
  public function card_login(){
    $loginName=Input::get('name');
    $loginPwd=Input::get('pwd');
    if ($loginName && $loginPwd) {
      $re=Card::userLogin(['userPhone'=>$loginName, 'password'=>$loginPwd, 'type'=>'S003']);
      Log::info($loginName.'-'.$loginPwd.'card_login:'.$re);
      $obj=json_decode($re);
      if ($obj->code==CODE_S) {
        $this->updateDBByLogin($obj,$loginName,$loginPwd);
        $_SESSION['card_userId'] = $obj->data->userId;//测试用的userid
      $_SESSION['card_loginName'] = $loginName;//手机号
    }
    
    return $re;
  }
  return Tool::getJson('0','账号或密码为空');
}

private function updateDBByLogin($obj,$loginName,$loginPwd)
{
  $card_rongtoken='';
  $card_tokenId='';
  $bxj_rongtoken='';
  $bxj_tokenId='';
  $_SESSION['telephone']=$loginName;
  $_SESSION['user_id'] = $obj->data->userId;
  foreach ($obj->data->tokenList as $key => $value) {
   switch ($value->type) {
     case CODE_TYPE_BXJ:
     $bxj_rongtoken=$value->token;
     $bxj_tokenId=$value->id;
     $_SESSION['rong_token'] = $bxj_rongtoken;//将融云token保存到session中
     $_SESSION['rong_token_id'] = $bxj_tokenId;//将融云token保存到session中

     break;
     case CODE_TYPE_XSK:
     $card_rongtoken=$value->token;
     $_SESSION['card_rongtoken'] = $card_rongtoken;//将融云token保存到session中
     $card_tokenId=$value->id;
     break;

     default:
     break;
   }
 }   

 $userId=$obj->data->userId;
 $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
 $this->clearDBUserInfo($loginName,$loginPwd,$_SESSION['users_id']);
 DB::update("update users set last_login='$ts', telephone='$loginName',password='$loginPwd',user_id='$userId',card_rongtoken='$card_rongtoken',rong_token='$bxj_rongtoken',card_token_id='$card_tokenId',token_id='$bxj_tokenId' where id=".$_SESSION['users_id']);

}

public function hzsb_sendSMS()
{
  $phone=Input::get('phone');
  $sendType=Input::get('sendType',0);
  $re= Lampv2::sendSMS(['userPhone'=>$phone,'sendtype'=>$sendType]);
  // $re= Lamp::sendSMS($phone,$sendType);
  Log::info('$re='.$re);
  return $re;
}

public function hzsb_register()
{
  $phone=Input::get('phone');
  $password=Input::get('password');
  $checkCode=Input::get('checkCode');
  // return Lamp::register($phone,$password,$checkCode);
  $re= Lampv2::register(['userPhone'=>$phone,'password'=>$password,'smscode'=>$checkCode]);
  Log::info('$re='.$re.$phone.$password.$checkCode);
  return $re;
}

public function hzsb_resetpwd()
{
  $phone=Input::get('phone');
  $password=Input::get('password');
  $checkCode=Input::get('checkCode');
  $re=Lampv2::resetPwd(['userPhone'=>$phone,'newPassword'=>$password,'reset'=>'0','smscode'=>$checkCode]);
  $obj=json_decode($re);
  if ($obj->code==CODE_S) {
    $this->clearDBUserByPhone($phone);
  }
  Log::info('hzsb_resetpwd'.$phone.$password.$re);
  return $re;
}

public function hzsb_editpwd()
{
  $phone=Input::get('phone');
  $password=Input::get('password');
  $password_new=Input::get('password_new');

  $re=Lampv2::resetPwd(['userPhone'=>$phone,'newPassword'=>$password_new,'reset'=>'1','password'=>$password]);
  $obj=json_decode($re);
  if ($obj->code==CODE_S) {
    $this->clearDBUserByPhone($phone);
  }
  Log::info('hzsb_editpwd'.$phone.$password.$password_new.$re);
  return $re;
}

private function clearDBUserByPhone($phone)
{
  DB::update("UPDATE users SET telephone='',rong_token='',token_id='',user_id='',card_token_id='',card_rongtoken='' WHERE telephone='$phone'");
}

private function clearDBUserInfo($phone,$password,$id)
{
  DB::update("update users set  token_id='',telephone='',password='',rong_token='',card_rongtoken='',user_id='',card_token_id='' where telephone='$phone' and password='$password' and id!=".$id);
}

	/**
	* 还在身边auth登录，绑定账号
	* @return js
	*/
	public function hzsb_login(){
   $phone=Input::get('phone');
   $password=Input::get('password');
      // $this->openid=$_SESSION['id'];
   if ($phone!='' && $password!='') {
    $re=Lampv2::login(['userPhone'=>$phone,'password'=>$password,'type'=>CODE_TYPE_BXJ]);
    Log::info('login'.$re);
    $msg='';
    $data='';
				$tokenId='';//用于通信的id
				try {
					$jsonObj=json_decode($re);
					if ($jsonObj->code!=CODE_S) {
            return Tool::getJson('0',$jsonObj->msg,$jsonObj->msg);
          }
          $this->updateDBByLogin($jsonObj,$phone,$password);
          
        } catch (Exception $e) {
        }
        return Tool::getJson('1','','');  //TODO
      }else{
       return Tool::getJson('0','账号或密码为空','账号或密码为空');
     }

   }


  /**
  * 还在身边auth登录，qr
  * @return js
  */
  public function users_center_qr(){
    $this->setOpenid();

    if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");
            if ($re[0]->telephone && $re[0]->password) {
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中

              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);

              $ticket=$this->getTicket($re[0]->telephone);
              if ($ticket=='') return Tool::h5(PAGE_ERR);
              
              $_SESSION['ticket'] = $ticket;//将ticket保存到session中
              echo Tool::h5('正在跳转会员信息...');
              return Tool::headerUrl('/qr_rec?ticket='.$ticket.'&phone='.$re[0]->telephone);

            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/hzsb_login_page_qr?id='.$this->openid);
            }
            return Tool::h5(PAGE_ERR);
          }
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN_QR);
  }

  /**
  * jxt auth登录，
  * @return js
  */
  public function auth_jxt(){
    $this->setOpenid();
    if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");

            if (count($re)==0) return Tool::h5('请重新关注公众号');

            if ($re[0]->telephone && $re[0]->card_rongtoken) {
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['card_userId'] = $re[0]->user_id;//将用户id保存到session中
              $_SESSION['card_loginName']=$re[0]->telephone;

              $_SESSION['card_rongtoken']=$re[0]->card_rongtoken;
              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);

              $signPackage=$this->getSignPackage();

              return View::make('jxt.center')->with('signPackage',$signPackage);

            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/jxt_login_page?id='.$this->openid);
            }

            return Tool::h5(PAGE_ERR);
          }
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN_JXT);
        }

  private function setOpenid()
        {
         if (array_key_exists('id',$_SESSION)) {
          Log::info('has openid->'.$_SESSION['id']);
          $this->openid=$_SESSION['id'];
        }else{
          $code=Input::get('code');
          if ($code){
            $re=$this->code2openid($code);
            Log::info($re);
            if($re){
              $jsondecode=json_decode($re,true);
              if (array_key_exists('openid',$jsondecode)) $this->openid=$jsondecode['openid'];
            }
          }
        }
      } 

  /**
  * xsk auth登录，
  * @return js
  */
  public function auth_card(){

    $this->setOpenid();
    if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");

            if (count($re)==0) {
              return Tool::h5('请重新关注公众号');
            }

            if ($re[0]->telephone && $re[0]->card_rongtoken) {
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['card_userId'] = $re[0]->user_id;//将用户id保存到session中
              $_SESSION['card_loginName']=$re[0]->telephone;

              $_SESSION['card_rongtoken']=$re[0]->card_rongtoken;
              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);

              $signPackage=$this->getSignPackage();

              return View::make('card.card_cardcenter')->with('signPackage',$signPackage);

            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/card_login_page?r='.mt_rand(0,99).'&id='.$this->openid);
            }

            return Tool::h5(PAGE_ERR);
          }
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN_XSK);

        }

  /**
  * xsk auth登录，
  * @return js
  */
  public function auth_card_test(){
    $this->setOpenid();

    if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");

            if (count($re)==0) {
              return Tool::h5('请重新关注公众号');
            }

            if ($re[0]->telephone && $re[0]->card_rongtoken) {
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['card_userId'] = $re[0]->user_id;//将用户id保存到session中
              $_SESSION['card_loginName']=$re[0]->telephone;

              $_SESSION['card_rongtoken']=$re[0]->card_rongtoken;
              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);

              $signPackage=$this->getSignPackage();

              return View::make('card.card_cardcenter_view')->with('signPackage',$signPackage);

            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/card_login_page?r='.mt_rand(0,99).'&id='.$this->openid);
            }

            return Tool::h5(PAGE_ERR);
          }

          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN_XSK_TEST);
        }

        public function getRecNum()
        {
          if (array_key_exists('ticket', $_SESSION) && array_key_exists('telephone', $_SESSION)){
            $phone=Input::get('phone');
    if ($phone==$_SESSION['telephone']) {//相等才能确认是用户自己中心的
      $this->updateOrder();
      return $this->getRecNumByPhone($_SESSION['telephone']);
    }
  }
  return '';
}

public function getSPRecNum()
{     
  $this->updateOrder();
      if (Input::get('type')!='1') {//1=com全体
        return $this->getRecNumBySP(0);
      }else{
        return $this->getRecNumBySP(1);
      }
    }

  /**
  * 还在身边auth登录，通过auth2.0获取openid
  * @return js
  */
  public function hzsb_getOpenid(){

    $this->setOpenid();

    if($this->openid){
      $_SESSION['id'] = $this->openid;//将id保存到session中

            //判断用户是否绑定过账号
      $re=DB::select('select * from users where users.name='."'$this->openid'");
      if ($re[0]->rong_token && $re[0]->password) {
        echo Tool::h5('正在跳转主界面...');

              $_SESSION['rong_token'] = $re[0]->rong_token;//将融云token保存到session中
              $_SESSION['users_id'] = $re[0]->id;//将本服务器用户id保存到session中
              $_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中
              $_SESSION['rong_token_id'] = $re[0]->token_id;//将融云id
              $_SESSION['user_id'] = $re[0]->user_id;//将主服务器用户id

              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);
              return Tool::headerUrl('/wxdemo_zhihui');
            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/hzsb_login_page_zhihui?id='.$this->openid);
            }
            return Tool::h5(PAGE_ERR);

          }
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN);
        }

	/**
	* 还在身边auth登录，测试接口
	* @return js
	*/
	public function hzsb_getOpenid3(){
		$this->setOpenid();
    if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");
            if ($re[0]->rong_token && $re[0]->password) {
              $_SESSION['rong_token'] = $re[0]->rong_token;//将融云token保存到session中
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中
              $_SESSION['rong_token_id'] = $re[0]->token_id;//将用户手机号保存到session中
              $_SESSION['user_id'] = $re[0]->user_id;//将主服务器用户id
              // echo Tool::h5('正在跳转...');
              $signPackage=$this->getSignPackage();
              return View::make('lamp.bxj_test')->with('signPackage',$signPackage);         
            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/hzsb_login_page3?id='.$this->openid);
            }
            return Tool::h5(PAGE_ERR);
          }
          return Tool::h5(PAGE_ERR);
        }

    /**
     * 正式接口
     * @return mixed
     */
    public function wxdemo(){
      if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      } else{
        return RELOG_ERR;
      }
      $signPackage=$this->getSignPackage();
      return View::make('lamp.wxdemo_zhihui')->with('signPackage',$signPackage);
    }


    /**
     * @return mixed测试接口
     */
    public function wxdemo3(){
     if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
     } else{
      return RELOG_ERR;
    }
    $signPackage=$this->getSignPackage();
    return View::make('wxdemo3')->with('signPackage',$signPackage);
  }

    /**
     * 获取设备id
     * @return mixed
     */
    public function getdevice(){
      if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
        $data='userPhone='.$_SESSION['telephone'];
        Log::info('GETDEVICE_URL'.GETDEVICE_URL.$data);
        $re=Http::http_request(GETDEVICE_URL,$data);
        Log::info('GETDEVICE'.$re);
        return $re;
      } else{
        return RELOG_ERR;
      }
    }


    /**
     * 获取昵称
     * @return mixed
     */
    public function getUserName(){
     if (array_key_exists('telephone', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      $data='userPhone='.$_SESSION['telephone'];
      Log::info('GET_USER_NAME_URL'.GET_USER_NAME_URL.$data);
      $re=Http::http_request(GET_USER_NAME_URL,$data);
      Log::info('GET_USER_NAME'.$re);
      return $re;
    } else{
      return RELOG_ERR;
    }
  }

    /**
     * 获取每日学习数据
     * @return mixed
     */
    public function getDailyData(){
     if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      $data='deviceId='.Input::get('deviceId');
      Log::info('GETDEVICE_URL'.GETDAILYDATA_URL.$data);
      $re=Http::http_request(GETDAILYDATA_URL,$data);
      Log::info('GETDAILYDATA'.$re);
      return $re;
    } else{
      return RELOG_ERR;
    }
  }


    /**
     * 下载音频并返回路径，然后由web端发给app
     * @return string url
     * author hgx
     */
    public function downloadVoice(){
      $media_id=Input::get('media_id');
      $access_token=$this->getAccessToken(self::$appId,self::$secret);
      $dir=$this->getAudioDir();
      $minddleName=str_replace(' ','',microtime()).mt_rand(1,99);
      $fileName='.amr';
      $re=MyWechat::downloadWeixinFile($access_token,$media_id,$dir.$minddleName,$fileName);
      $amrName=$dir.$minddleName.$fileName;
      if(filesize($amrName)){
        $mp3Name=$dir.$minddleName.'.mp3';
        exec("ffmpeg -i $amrName $mp3Name");
        return Audio_HOST.$dir.$minddleName.'.mp3';
      }
      return '';
    }

    public function card_downloadVoice(){
      $media_id=Input::get('media_id');
      $device_id=Input::get('device_id');
      $access_token=$this->getAccessToken(self::$appId,self::$secret);
      $dir=$this->getCardAudioDir();
      $minddleName=str_replace(' ','',microtime()).mt_rand(1,99);
      $fileName='.amr';
      $re=MyWechat::downloadWeixinFile($access_token,$media_id,$dir.$minddleName,$fileName);

      if($re){
        $amrName=$dir.$minddleName.$fileName;
        $mp3Name=$dir.$minddleName.'.mp3';
        if (filesize($amrName)) {
          exec("ffmpeg -i $amrName $mp3Name");
          $urlMp3=Audio_HOST.$dir.$minddleName.'.mp3';
          $urlAmr=Audio_HOST.$dir.$minddleName.'.amr';
        //发送给卡服务器
          $sendResult=Card::sendVoice(['device_id'=>$device_id,'userid'=>$_SESSION['card_userId'],'mp3_url'=>$urlAmr]);
          Log::info('sendResult'.$sendResult.json_encode(['device_id'=>$device_id,'userid'=>$_SESSION['card_userId'],'mp3_url'=>$urlAmr]));

          $obj=json_decode($sendResult);
          if ($obj->errcode==0) {
            return $this->card_audioReturn(0,'',['url'=>$urlMp3,'msgId'=>$obj->data->message_id]);
          }else{
            return $this->card_audioReturn(1,$obj->errmsg);
          }
        }

      }
      return $this->card_audioReturn(1,'音频下载失败');
    }

    private function card_audioReturn($code,$msg,$data)
    {
      return json_encode(['errcode'=>$code,'errmsg'=>$msg,'data'=>$data]);
    }


  }
  ?>