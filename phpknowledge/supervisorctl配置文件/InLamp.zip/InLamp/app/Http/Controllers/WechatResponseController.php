<?php
namespace App\Http\Controllers;
use App\Http\Controllers\WechatBaseController;
use App\Http\Controllers\ZhihuiWechatResponseController;
use Log;
use Input;
use DB;
// use Memcache;
// require_once "pic2text.php";
/*require_once "lib/WechatDownloader.php";
require_once('WechatMRController.php');*/

define('HAIZAISHENBIAN', 'gh_dd719c5b0a8f');//孩在身邊公眾號

/*$logFile ='wechatResponse.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);*/


set_time_limit(0);
class WechatResponseController extends WechatBaseController{
	private $fromUsername,$toUsername,$keyword,$msgType,$openid,$options,$ucpaas,$subscribe,$isPic,$isVoi,$mediaId,$isTextWait;
	// private $uid;
	private $Zhihui;
	const DEF_REPLY='感谢您的关注！更多内容，敬请期待。';

	const TYPE_SPECIAL=0;//内部
	const TYPE_PHONE=1;//全体

	// const DEF_REPLY="#最萌小女神大赛#投票，请点下面栏目<a href=\"http://mp.weixin.qq.com/s?__biz=MzA3MTc5NzQ3NA==&mid=400860421&idx=1&sn=6607a7796f087b4bc7abf0403d68748a#rd\">【小女神大赛】</a>，其他问题稍后回复你。";
	// const DEF_SUB_REPLY='谢谢您的关注，更多惊喜，请点击孩在身边微商城。';
	const DEF_SUB_REPLY='感谢您的关注！更多内容，敬请期待。';
	const DEF_SUPRISE_REPLY="“孩在身边”伴学机即将登陆商城，这是一款能架起父母和孩子之间的心灵之桥，让爸妈放心，让孩子开心，让家庭充满爱的陪伴的产品！\n PS：还有一波波优惠活动、优惠礼品准备接近中喔！/:,@-D";
	const DEF_GRADE="黄桂旋成绩：\n语文 期末考试 7-10周五\n98分 第3名\n数学 期末考试 7-10周五\n95分 第1名 \n英语 期末考试 7-10周五\n96分 第5名 \n英语 第八单元 6-17周三\n92分 第6名";
	const DEF_HOMEWORK="6月28日周日作业\n语文：\n1、背诵第10课第一段\n2、听写第11课\n数学：\n1、试卷一张\n英语：\n1、抄写第7课单词\n2、朗读第8课3遍\n备注：\n1、希望家长监督孩子朗读和听写";
	const DEF_CONTECT="客服电话：075532984123、075532985123\n工作时间：09:00—18:00\n官    网：<a href=\"http://www.haizaishenbian.com\">孩在身边</a>\n联系地址：深圳市龙岗区龙翔大道4075号汇和大厦9A\n";
	
	public function check(){
		$echoStr = Input::get('echostr');
		Log::info(Input::get('echostr')."|".Input::get('signature')."|".Input::get('timestamp')."|".Input::get('nonce'));
		echo $echoStr;
		exit;
	}
	public function check_yg(){
		$echoStr = Input::get('echostr');
		echo $echoStr;
		exit;
	} 
	public function ini($postObj){
		$this->fromUsername = $postObj->FromUserName;
		$this->openid = $postObj->FromUserName;
		// $this->mem = new Memcache;
		// $this->mem->connect('localhost', 11211) or die ('Could not connect');
		$this->toUsername = $postObj->ToUserName;
		$this->keyword = trim($postObj->Content);
		$this->msgType = $postObj->MsgType;
		$this->mediaId = $postObj->MediaId;
		// $this->setUID();

	} 

	//缓存设置用户的id，节省对数据库的操作
/*	private function setUID(){
		$this->uid=$this->mem->get($this->openid.'_uid');
		if (!$this->uid) {
			$idObjArr=DB::select("select id from users where name='$this->openid'");
			if ($idObjArr) {
				$this->uid=$idObjArr[0]->id;
				$this->mem->set($this->openid.'_uid', $this->uid, 0, UID_TIME);
				Log::info('mem->set'.$this->uid);
			}
		}
	}*/

	public function response()
	{
		$postStr = $GLOBALS['HTTP_RAW_POST_DATA'];
		Log::info($postStr);
		if (!empty($postStr)){
			$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
			$this->ini($postObj);

			// gh_dd719c5b0a8f 孩在身边
			$msg=self::DEF_REPLY;
			if($this->toUsername==HAIZAISHENBIAN){
				switch ($this->msgType){
					case 'text':
					// $msg=$this->text($key);
					break;
					case 'event':
					$msg=$this->event($postObj);
					break;
					case 'image':
					// $msg=$this->image();
					break;
					case 'voice':
					// $this->recognition = $postObj->Recognition;
					// $msg=$this->voice();
					break;
					default:
					// $this->deleteAll();
					break;
				}
			}else{
				$this->Zhihui=new ZhihuiWechatResponseController($postObj);
				$msg=ZhihuiWechatResponseController::DEF_REPLY;
				switch ($this->msgType){
					case 'text':
					break;
					case 'event':
					$msg=$this->Zhihui->event($postObj);
					break;
					case 'image':
					break;
					case 'voice':
					break;
					default:
					// $this->deleteAll();
					break;
				}
			}
			

			// }
			$result='';
			if ($msg!='') {
				$result=$this->transmitText($this->fromUsername,$this->toUsername,$msg);
			}
			
			echo $result;
			$size=ob_get_length();  
			header('Content-Length: '.$size);  
			ob_end_flush();  
			flush();
			
		}else{
			echo '';
			exit;
		}
		// $this->mem->close();
	}

	public function text($key){
		$msg='hello';
		switch($this->keyword){
			case '4':

			break;

			default:
			break;
		}
		return $msg;
	}

	/**
	*把二维码推广用户记录数据库
	*@param ekey 推荐者的二维码id
	*@return null
	*/
	private function save_rec($ekey){

		$type=self::TYPE_PHONE;
		if (strlen($ekey)!=11) {//手机号
			$type=self::TYPE_SPECIAL;
		}
		try {
			DB::insert("insert into rec(name,rec_id,type) values('$this->openid','$ekey',$type)");
		} catch (Exception $e) {
			Log::info("error insert into rec(name,rec_id,type) values('$this->openid',$ekey,$type)");
		}
		
	}

	public function event($postObj){
		$msg=self::DEF_REPLY;
		switch ($postObj->Event)
		{
			case 'subscribe':
			$msg=self::DEF_SUB_REPLY;
			$this->subscribe(1);
			if ($postObj->EventKey) {
				//保存二维码推荐人
				if (substr($postObj->EventKey,0,8)=='qrscene_') {//未关注用户
					$ekey=substr($postObj->EventKey, 8);//‘qrscene_123123’只截取未关注用户的。事件KEY值，是一个32位无符号整数，即创建二维码时的二维码scene_id
					if ($ekey) {
						$this->save_rec($ekey);
					}
				}
				
			}

			break;
			case 'SCAN':
			$msg='嘿嘿，咱们又见面了~';
			break;
			
			case 'unsubscribe':
			$this->delUnsub();
			break;
			case 'CLICK':
			switch ($postObj->EventKey)
			{
				case 'describe':
				$msg='';

				break;
				case 'suprise':
				$msg=self::DEF_SUPRISE_REPLY;
				break;
				case 'contact':
				$msg=self::DEF_CONTECT;
				break;
				case 'grade':
				$msg=self::DEF_GRADE;

				break;
				case 'homework':
				$msg=self::DEF_HOMEWORK;

				break;

			}
			break;
		}
		return $msg;
	}

	//
	public function zhihuijiaoyu_event($postObj){
		$msg=self::DEF_REPLY;
		switch ($postObj->Event)
		{
			case 'subscribe':
			$msg=self::DEF_SUB_REPLY;
			$this->zhihuijiaoyu_subscribe(1);
			if ($postObj->EventKey) {
				//保存二维码推荐人
				if (substr($postObj->EventKey,0,8)=='qrscene_') {//未关注用户
					$ekey=substr($postObj->EventKey, 8);//‘qrscene_123123’只截取未关注用户的。事件KEY值，是一个32位无符号整数，即创建二维码时的二维码scene_id
					if ($ekey) {
						$this->save_rec($ekey);
					}
				}
				
			}

			break;
			case 'SCAN':
			$msg='嘿嘿，咱们又见面了~';
			break;
			
			case 'unsubscribe':
			$this->delUnsub();
			break;
			case 'CLICK':
			switch ($postObj->EventKey)
			{
				case 'describe':
				$msg='';

				break;
				case 'suprise':
				$msg=self::DEF_SUPRISE_REPLY;
				break;
				case 'contact':
				$msg=self::DEF_CONTECT;
				break;
				case 'grade':
				$msg=self::DEF_GRADE;

				break;
				case 'homework':
				$msg=self::DEF_HOMEWORK;

				break;

			}
			break;
		}
		return $msg;
	}


	/**
	*取消关注的用户将推荐了的用户删掉
	*
	***/
	private function delUnsub(){
		try {
			DB::delete("delete from rec where name='$this->openid'");
			Log::info('delete unsubscribe succ');
		} catch (Exception $e) {
			Log::info("error delete from yg_rec where name='$this->openid'");
		}
		//置为取消关注
		DB::update("update users set unsubscribe=1 where name ='$this->openid'");

	}


/**
* 关注公众号
* @param group_id
*/
public function subscribe($group_id=1){
	$idArr=DB::select("select id from users where name ='$this->openid'");
	
	if(empty($idArr)){
		$nickname=addslashes($this->getUserNickname($this->openid));//修正个别昵称导致数据库插入失败问题
		Log::info("insert into users (name,group_id,nickname)values('$this->openid',$group_id,'$nickname')");
		try {

			DB::insert("insert into users (name,group_id,nickname)values('$this->openid',$group_id,'$nickname')");
		} catch (Exception $e) {
			Log::info("error insert into users (name,group_id)values('$this->openid',$group_id)");
		}
	}else{
		// fix 15-06-15
		DB::update("update users set unsubscribe=0 where name='$this->openid'");
	}

}

}
?>