<?php
$logFile ='users.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);
class UserController extends BaseController {


	public function register()
	{
		$imei = Input::get('UM');
		$pwd  = Input::get('PWD');
		Log::info($pwd);
		if ($pwd!='...X()dj3wo4fwo2320<>|sdwe3rt3sdw3xss-~~@*') {
			Log::info('register fail');
			echo $this->get_json('2','失败');
			return;
		}
		$password = $this->getRandchar(12);
		$passwordTosave = Hash::make($password);
		$res = DB::select("select * from device where imei='$imei'");
		if (!empty($res)) {
			// echo $this->get_json('2','失败');
			Log::info('register sucessful');
			DB::update("update users set password = '$passwordTosave' where name = '$imei'");
			Log::info("update users set password = '$passwordTosave' where name = '$imei'");
			// return;
		}
		// $password = $this->getRandchar(12);
		else{
			try{
				$device = DB::select("select id from device where imei = '$imei'");
				if (!empty($device)) {
					return $this->get_json('2','失败');
				}else{
					DB::insert("insert into device(imei) values('$imei')");
					log::info('add device sucessful');
					DB::insert("insert into users(name,password) values('$imei','$passwordTosave')");
				}
			} catch (Exception $e) {
				Log::info('add device fail');
				return $this->get_json('2','失败');
				// return;	
		}
		}
		
		$arr = array('UM' => $imei, 'PWD' => $password);
		$arrObj = json_encode($arr);
		Log::info('register complete');
		echo $this->get_json('1','成功',$arrObj);
		return;
	}

	public function login()
	{
		if(Auth::check()){
			echo $this->get_json('1','成功');
			Log::info('login sucessful!');
			return;
		}
		else{
			$userName = Input::get('UM');
			$password = Input::get('PWD');
			Log::info('login userName: '.$userName);
			Log::info('login password: '.$password);
			if(Auth::attempt(array('name'=>$userName,'password' =>$password),true)){
				echo $this->get_json('1','成功');
				Log::info('attempt sucessful!');
				return;
			}
			else{
				Log::info('attempt fail');
				echo $this->get_json('2','失败');
				return;
			}
		}
	}

	private function getRandchar($length){
   		$str = null;
  		$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   		$max = strlen($strPol)-1;
   		for($i=0;$i<$length;$i++){
    	$str.=$strPol[rand(0,$max)];//rand($min,$max)生成介于min和max两个数之间的一个随机整数
   		}
   		return $str;
  	}

}
