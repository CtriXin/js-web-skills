<?php
//use Mongo;

/**
 * Class MongoDB
 * anthor hgx
 */
class MyMongoDB{
  private static $ip='127.0.0.1';
  private static $port='27017';
  private static $con=null;
   public static function getInstance(){
    if (self::$con==null) {
      self::$con=new MongoClient(self::$ip.':'.self::$port);
    }
    return self::$con;
   }
}