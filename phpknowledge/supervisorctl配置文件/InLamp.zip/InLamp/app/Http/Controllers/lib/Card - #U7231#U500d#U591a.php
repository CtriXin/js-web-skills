<?php
/**
 * @version 1.0
 * @date 2015-10-07
 * @author hgx
 * Class Card 学生卡协议相关
 * 
 */
class Card
{

    //超级账户
    private static $admin_name='jh_admin';
    private static $admin_pwd='wbt351by58';
    //url
    private static $url_routen='http://www.abdjy.com/routon';


    /**
    * userLogin,用户登录
    * @param $loginName 用户名
    * @param $loginPwd 用户密码
    * @return $result xml格式返回结果
    */
    public static function userLogin($loginName,$loginPwd,$version='1.0'){
        $url=self::$url_routen;
        $action='UserLoginRequest';
        $loginPwd=md5($loginPwd);
        $paramArr=['loginName'=>$loginName,'loginPwd'=>$loginPwd];
        $checkSum=self::createCheckSum($action,self::$admin_name,md5(self::$admin_pwd),$version);
        $xml=self::createXML($action,$checkSum,self::$admin_name,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * msgCenter,获取消息中心数据
    * @param $terminalId 设备id，就是用户名
    * @param $date 时间如2015-10-07，可空默认当天
    * @param $version 可空
    * @return $result xml格式返回结果
    */
    public static function msgCenter($terminalId,$date='',$version='1.0'){
        if ($date=='') {
            $date=date('Y-m-d',$_SERVER['REQUEST_TIME']);
        }

        $url=self::$url_routen;
        $action='QueryActInfo';
        $loginName=self::$admin_name;
        $loginPwd=md5(self::$admin_pwd);
        $paramArr=['terminalId'=>$terminalId,'date'=>$date];
        $checkSum=self::createCheckSum($action,$loginName,$loginPwd,$version);
        $xml=self::createXML($action,$checkSum,$loginName,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * terminalStatus,获取设备最新状态，比如 电量，速度，最新经纬度，开关机在线状态，是否gps定位 ，最新定位时间等
    * @param $terminalId 设备id，就是用户名
    * @param $version 可空
    * @return $result xml格式返回结果
    */
    public static function terminalStatus($terminalId,$version='1.0'){
        $url=self::$url_routen;
        $action='GetTerminalStatus';
        $loginName=self::$admin_name;
        $loginPwd=md5(self::$admin_pwd);
        $paramArr=['terminalId'=>$terminalId];
        $checkSum=self::createCheckSum($action,$loginName,$loginPwd,$version);
        $xml=self::createXML($action,$checkSum,$loginName,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * terminalStatus,获取设备最新状态，比如 电量，速度，最新经纬度，开关机在线状态，是否gps定位 ，最新定位时间等
    * @param $orgiLat 原始纬度
    * @param $orgiLng 原始纬度
    * @param $lat 纠偏后的纬度
    * @param $lng 纠偏后的经度 
    * @param $isGps 
    * @return $result xml格式返回结果
    */
    public static function geoReverse($orgiLat,$orgiLng,$lat,$lng,$isGps,$version='1.0'){
        $url=self::$url_routen;
        $action='GetGeoReverse';
        $loginName=self::$admin_name;
        $loginPwd=md5(self::$admin_pwd);
        $paramArr=['orgiLat'=>$orgiLat,'orgiLng'=>$orgiLng,'lat'=>$lat,'lng'=>$lng,'mcc'=>'460','isGps'=>$isGps];
        $checkSum=self::createCheckSum($action,$loginName,$loginPwd,$version);
        $xml=self::createXML($action,$checkSum,$loginName,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * getUserTerminalByUserId,获取当前设备信息，通过用户名和密码，用于用户登录的时候获取当前号设备id
    * @param $terminalId 设备id，就是用户名
    * @param $version 可空
    * @return $result xml格式返回结果
    */
    public static function getUserTerminalByUserId($loginName,$loginPwd,$version='1.0'){
        $url=self::$url_routen;
        $action='GetUserTerminalByUserId';
        $loginPwd=md5($loginPwd);
        $paramArr=[];
        $checkSum=self::createCheckSum($action,$loginName,$loginPwd,$version);
        $xml=self::createXML($action,$checkSum,$loginName,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * terminalExt,查询设备所有配置信息,包括sos，亲情号码，等
    * @param $terminalId 设备id，就是用户名
    * @param $version 可空
    * @return $result xml格式返回结果
    */
    public static function terminalExt($terminalId,$version='1.0'){
        $url=self::$url_routen;
        $action='GetTerminalExt';
        $loginName=self::$admin_name;
        $loginPwd=md5(self::$admin_pwd);
        $paramArr=['terminalId'=>$terminalId];
        $checkSum=self::createCheckSum($action,$loginName,$loginPwd,$version);
        $xml=self::createXML($action,$checkSum,$loginName,$paramArr,$version);
        $result=self::http_request($url, $xml);
        return $result;
    }

    /**
    * checkSum生成,String checkSum = MD5Util.MD5(version + action+ loginName + loginPwd);
    * @param $action 对应的请求action
    * @param $loginName 超级账号
    * @param $loginPwd 超级账号密码
    * @param $version 版本,可空
    * @return $checkSum
    */
    private static function createCheckSum($action,$loginName='jh_admin',$loginPwd='wbt351by58',$version='1.0'){
        return md5($version.$action.$loginName.$loginPwd);
    }

    /**
    * xml协议生成
    * @param $version 版本
    * @param $action 对应的请求action
    * @param $checkSum 校验 checkSum = MD5Util.MD5(version + action+ loginName + loginPwd);
    * @param $loginName 卡机用户登录名
    * @param $paramArr Param item数组 key=>value.如<Param name="userName">123</Param>就是'userName'=>'123'
    * @return xml
    */
    private static function createXML($action,$checkSum,$loginName,$paramArr,$version='1.0'){
        $header='<IBABY version="'.$version.'" action="'.$action.'" checkSum="'.$checkSum.'" loginName="'.$loginName.'"><Request>';
        $footer='</Request></IBABY>';
        $body='';
        foreach ($paramArr as $key => $value) {
            $body.='<Param name="'.$key.'">'.$value.'</Param>';
        }
        return $header.$body.$footer;
    }


    /**
    * HTTP请求（支持HTTP/HTTPS，支持GET/POST）http_request
    * @param string $data post data 空则为GET
    * @param string $url 
    * @return string $result
    */    
   public static function http_request($url, $data = null)
    {
        $curl = curl_init();
    curl_setopt($curl, CURLOPT_PORT, '12346');//爱贝多端口12346
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    if (!empty($data)){
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}


}