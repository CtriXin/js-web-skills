<?php
// echo Card::userLogin(['userPhone'=>'13714876874', 'password'=>'123456', 'type'=>'S003']);
/**
 * @version 2.0
 * @date 2015-11-24
 * @author hgx
 * Class Card 学生卡协议相关
 * 
 */
class Card
{



    //url
    //private static $url_host='http://kq.snewfly.com:8081';
private static $url_host='http://kq2.snewfly.com:8081';//测试
    //url
    // private static $url_host_java='http://182.92.73.34:8080/lpserver/';
    private static $url_host_java='http://bxj.server.snewfly.com:8686/';

    // private static $url_host='http://ks.h-hy.com';
    private static $route_user_login='/user/login.action';

    private static $route_add_device='/api/user/add_device?access_token=';
    private static $route_edit_device='/api/user/edit_device?access_token=';
    private static $route_delete_device='/api/user/delete_device?access_token=';
    private static $route_query_device='/api/user/device?access_token=';
    private static $route_message_center='/api/user/message_center?access_token=';
    private static $route_device_bind_phone='/api/user/binding?access_token=';

    private static $route_info_query='/api/card/info_query?access_token=';
    private static $route_info_set='/api/card/info_set?access_token=';
    private static $route_attendance_notice_set='/api/attendance/notice?access_token=';
    private static $route_send_voice='/api/card/send_voice?access_token=';

    private static $route_card_action='/api/card/action?access_token=';

//用户相关：
    /**
    * userPhone password type=S003
    * @return $json
    */
    public static function userLogin($arr){
        $url=self::getJavaUrlByRoute(self::$route_user_login);
        return self::getPostByArr($url,$arr);
    }

    /**
    * addDevice,添加設備
    * $userid,$device_id,$password,$nick,$sex,$picture
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function addDevice($arr){
        $url=self::getUrlByRoute(self::$route_add_device);
        return self::getPostByArr($url,$arr);
    }

    /**
    * sendVoice,发送语音
    * $userid,$device_id,$mp3_url 可访问的mp3绝对地址（改成传amr格式）。
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function sendVoice($arr){
        $url=self::getUrlByRoute(self::$route_send_voice);
        return self::getPostByArr($url,$arr);
    }

    /**
    * cardAction,学生卡操作
    * $userid,$device_id,$action 目前可选：location或shutdown
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function cardAction($arr){
        $url=self::getUrlByRoute(self::$route_card_action);
        return self::getPostByArr($url,$arr);
    }

    /**
    * editDevice,编辑設備
    * $userid,$device_id,$nick,$sex,$picture
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function editDevice($arr){
        $url=self::getUrlByRoute(self::$route_edit_device);
        return self::getPostByArr($url,$arr);
    }

    /**
    * msgCenter,用户消息中心
    * $userid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function msgCenter($arr){
        $url=self::getUrlByRoute(self::$route_message_center);
        return self::getPostByArr($url,$arr);
    }

    /**
    * getDeviceBindPhone,获取设备绑定所有手机号
    * $userid imei
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function getDeviceBindPhone($arr){
        $url=self::getUrlByRoute(self::$route_device_bind_phone);
        return self::getPostByArr($url,$arr);
    }

    /**
    * queryDevice,查询設備
    * $userid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryDevice($arr){
        $url=self::getUrlByRoute(self::$route_query_device);
        return self::getPostByArr($url,$arr);
    }

    /**
    * deleteDevice,删除設備
    * $userid,$device_id
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function deleteDevice($arr){
        $url=self::getUrlByRoute(self::$route_delete_device);
        return self::getPostByArr($url,$arr);
    }

//卡相关：



    /**
    * infoQuery,学生卡信息查询
    * $user_id IMEI  real_time fields  need_location_zh   
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function infoQuery($arr){
        $url=self::getUrlByRoute(self::$route_info_query);
        return self::getPostByArr($url,$arr);
    }

    /**
    * infoQuery,学生卡设置
    * $usersid IMEIs IMEI fields
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function infoSet($arr){
        $url=self::getUrlByRoute(self::$route_info_set);
        return self::getPostByArr($url, $arr);
    }

    /**
    * 到离校通知设置
    * $usersid device_id flag
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function attendanceNoticeSet($arr){
        $url=self::getUrlByRoute(self::$route_attendance_notice_set);
        return self::getPostByArr($url, $arr);
    }

    /**
    * infoQuery,学生卡设置
    * $usersid IMEIs IMEI fields
    * @param $json
    * @return $result json格式返回结果
    */
    // public static function infoSet($json){
    //     $url=self::getUrlByRoute(self::$route_info_set);
    //     return self::http_request($url, $json);
    // }

    /**
    * 通用url 获取
    * @param $route
    * @return url
    */
    public static function getUrlByRoute($route){
        return self::$url_host.$route.self::getAccessToken();
    }

    /**
    * 通用url 获取
    * @param $route
    * @return url
    */
    public static function getJavaUrlByRoute($route){
        return self::$url_host_java.$route;
    }

    /**
    * 通用arr url 获取远程服务器json
    * @param $json
    * @return $result json格式返回结果
    */
    public static function getPostByArr($url,$arr){
        $data=self::arrayToString($arr);
        return self::http_request($url, $data);
    }

    /**
    * HTTP请求（支持HTTP/HTTPS，支持GET/POST）http_request
    * @param string $data post data 空则为GET
    * @param string $url 
    * @return string $result
    */    
   public static function http_request($url, $data = null)
    {
        $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    if (!empty($data)){
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    curl_close($curl);
    return $output;
}

private static function getAccessToken(){
    return 'access_token';
}


private static  function arrayToString($arr){
        $str='';
        foreach ($arr as $key => $value) {
            $str.=$key.'='.$value.'&';
        }
        if ($str!='') {
            $str=substr($str,0,strlen($str)-1);
        }
        return $str;
    }


}