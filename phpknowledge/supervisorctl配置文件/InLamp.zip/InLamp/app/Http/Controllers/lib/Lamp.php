<?php

// echo 're'.Lamp::sendSMS('13714876874','0');
// echo 're'.Lamp::register('13714876874','123456','461325');

/**
 * @version 1.0
 * @date 2015-11-20
 * @author hgx
 * Class Lamp 办学机协议1.0相关 mvp接口
 * 
 */
class Lamp
{

    private static $secret_key='SNEWFLYKEY';

    // private static $host='http://182.92.73.34:8080/hzsbServer/';//测试接口
    private static $host='http://120.24.76.242:8686/lpserver/';//测试接口
    private static $url_sendsms='sms/sendsms.action';
    private static $url_register='user/register.action';

    /**
    * sendSMS,发送验证码
    * @param $phone 手机号
    * @param $sendtype String  0|| 1   0为注册 1为找回密码 
    * @return $json
    */
    public static function sendSMS($phone,$sendtype)
    {
        $url=self::$host.self::$url_sendsms;
        $arrParam=['sendtype'=>$sendtype,'userPhone'=>$phone];
        $data=self::arrayParamToString($arrParam);
        return self::http_request($url,$data);
    }




    /**
    * sendSMS,发送验证码
    * @param $phone 手机号
    * @param $password 密码
    * @param $smsCode 验证码
    * @return $json
    */
    public static function register($phone,$password,$smsCode)
    {
        $url=self::$host.self::$url_register;
        $arrParam=['userPhone'=>$phone,'password'=>$password,'smscode'=>$smsCode];
        $data=self::arrayParamToString($arrParam);
        return self::http_request($url,$data);
    }

    /**
    * getSign,获取校验签名
    * @param $var 经常变的变量
    * @param $timestamp 10位时间戳
    * @return $nonce 随机数
    */
    public static function getSign($var,$timestamp ,$nonce){
        return sha1($var.$timestamp.$nonce.self::$secret_key);
    }


    /**
    * HTTP请求（支持HTTP/HTTPS，支持GET/POST）http_request
    * @param string $data post data 空则为GET
    * @param string $url 
    * @return string $result
    */    
    public static function http_request($url, $data = null)
    {
        $curl = curl_init();
    //curl_setopt($curl, CURLOPT_PORT, '12346');//爱贝多端口12346
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    /**
     * arrayParamToString 将数组转成post格式的参数
     * @return str 
     */
    public static function arrayParamToString($arr){
        $str='';
        foreach ($arr as $key => $value) {
            $str.=$key.'='.$value.'&';
        }
        if ($str!='') {
            $str=substr($str,0,strlen($str)-1);
        }
        return $str;
    }


}