<?php
// echo Jxt::queryDevice(['userid'=>'bQd4RRxiQNl8bNjenMoC0X']);

/**
 * @version 1.0
 * @date 2016-02-23
 * @author hgx
 * Class Jxt 家校通协议相关
 * 
 */
class Jxt
{

    //url
    private static $url_host='http://kq-admin.snewfly.com';

    private static $route_query_device='/wechat/device/query';
    private static $route_query_contact='/wechat/contact/query';
    private static $route_query_subject='/wechat/subject/query';
    private static $route_query_allScore='/wechat/score/queryall';
    private static $route_query_singleScore='/wechat/score/query';
    private static $route_query_homework='/wechat/homework/query';
    private static $route_query_notice='/wechat/notify/query';

    /**
    * queryDevice,查询設備
    * $userid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryDevice($arr){
        $url=self::getUrlByRoute(self::$route_query_device);
        return self::getGETByArr($url,$arr);
    }
    
    /**
    * queryNotice,查询tongzhi
    * $userid $deviceid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryNotice($arr){
        $url=self::getUrlByRoute(self::$route_query_notice);
        return self::getGETByArr($url,$arr);
    }

    /**
    * queryContact,查询联系方式
    * $userid $deviceid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryContact($arr){
        $url=self::getUrlByRoute(self::$route_query_contact);
        return self::getGETByArr($url,$arr);
    }

    /**
    * queryContact,查询拥有的科目
    * $userid $deviceid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function querySubject($arr){
        $url=self::getUrlByRoute(self::$route_query_subject);
        return self::getGETByArr($url,$arr);
    }


    /**
    * queryAllScore,查询所有科目成绩
    * $userid $deviceid
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryAllScore($arr){
        $url=self::getUrlByRoute(self::$route_query_allScore);
        return self::getGETByArr($url,$arr);
    }

    /**
    * querySingleScore,查询单科成绩
    * $userid $deviceid $subject
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function querySingleScore($arr){
        $url=self::getUrlByRoute(self::$route_query_singleScore);
        return self::getGETByArr($url,$arr);
    }

    /**
    * queryHomework,查询科目作业
    * $userid $deviceid $subject
    * @param $arr
    * @return $result json格式返回结果
    */
    public static function queryHomework($arr){
        $url=self::getUrlByRoute(self::$route_query_homework);
        return self::getGETByArr($url,$arr);
    }


    /**
    * 通用url 获取
    * @param $route
    * @return url
    */
    public static function getUrlByRoute($route){
        return self::$url_host.$route;
    }

    /**
    * 通用arr url 获取远程服务器json
    * @param $json
    * @return $result json格式返回结果
    */
    public static function getGETByArr($url,$arr){
        $data=self::arrayToString($arr);
        return self::http_request($url.'?'.$data);
    }

    /**
    * 通用arr url 获取远程服务器json
    * @param $json
    * @return $result json格式返回结果
    */
    public static function getPOSTByArr($url,$arr){
        $data=self::arrayToString($arr);
        return self::http_request($url, $data);
    }

    /**
    * HTTP请求（支持HTTP/HTTPS，支持GET/POST）http_request
    * @param string $data post data 空则为GET
    * @param string $url 
    * @return string $result
    */    
    public static function http_request($url, $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    private static  function arrayToString($arr){
        $str='';
        foreach ($arr as $key => $value) {
            $str.=$key.'='.$value.'&';
        }
        if ($str!='') {
            $str=substr($str,0,strlen($str)-1);
        }
        return $str;
    }


}