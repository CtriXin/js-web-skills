﻿<?php
    //第一个项目代码，没重构。已废弃的代码
$logFile ='wechatDownloader.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);

function getPath($type='img'){
	$dirDate = date('y-m-d',time());
	$dir='upload/wechat/'.$type.'/'.$dirDate;
	if(!is_dir($dir)){
		mkdir($dir);
	}
	$str =str_replace(' ','',microtime());
	$path=$dir.'/'.substr($str,3,strlen($str));
	Log::info(" path--".$path);
	return $path;
}
////重写盲人专用下载语音
function downloadMRVoice($access_token,$mediaId,$recognition,$messages_state,$filename){
	$fileName=$filename.".amr";
	$url="http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$mediaId";
	$fileInfo=downloadWeixinFile($url);
	$result=saveMRWeixinFile($filename.'.mp3',$fileInfo["body"],"voice",$messages_state,$recognition);
	$re=exec("ffmpeg -i $fileName $filename.mp3");
	 Log::info(' voice len'.strlen($fileInfo["body"]).'filename--'.$filename);
	return $result;
}
	//重写盲人专用下载图片
function downloadMRImg($access_token,$mediaId,$filename,$messages_state){
	$url="http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$mediaId";
	$fileInfo=downloadWeixinFile($url);
	$result=saveMRWeixinFile($filename,$fileInfo["body"],"pic",$messages_state);
	Log::info(" pic fileInfobodylength  ".strlen($fileInfo["body"]));
	return $result;
}
	//重写盲人专用保存文件
function saveMRWeixinFile($filename,$filecontent,$type,$messages_state,$recognition=null){
	$result="fail";
	$local_file=fopen($filename,'w');
	if(false!==$local_file){
		if(false!==fwrite($local_file,$filecontent)){
			Log::info("update messages set state=$messages_state where pic='$filename' 看我的state");
			$result="success";
			fclose($local_file);
			if($type=='pic'){
				DB::update("update messages set state=$messages_state where pic='$filename'");
			}else{
				DB::update("update messages set state=$messages_state where audio='$filename'");
			}
			
		}
	}
	return $result;
}
	//下载图片
function downloadImg($access_token,$mediaId,$fromUsername){
	$dirDate = date('y-m-d',time());
	$dir="upload/wechat/img/".$dirDate;
	Log::info(" dirDate--".$dir);
	if(!is_dir($dir)){
		mkdir($dir);
	}
	$filename=$dir."/".str_replace(' ','',microtime()).".jpeg";
	$url="http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$mediaId";
	$fileInfo=downloadWeixinFile($url);
	$result=saveWeixinFile($filename,$fileInfo["body"],"pic",$fromUsername);
	// Log::info(" $access_token,$mediaId,$fromUsername");
	Log::info(" pic fileInfobodylength  ".strlen($fileInfo["body"]));

	return $result;
}

//下载语音
function downloadVoice($access_token,$mediaId,$fromUsername,$recognition,$lyrVoi=false,$ygVoi=false,$msg_id=0){
	$dirDate = date('y-m-d',time());
	$dir="upload/wechat/voice/".$dirDate;
	if(!is_dir($dir)){
		mkdir($dir);}
	$filename=$dir."/".str_replace(' ','',microtime());
	$fileName=$filename.".amr";
	$url="http://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$access_token&media_id=$mediaId";
	$fileInfo=downloadWeixinFile($url);
	$result=saveWeixinFile($fileName,$fileInfo["body"],"voice",$fromUsername,$filename,$recognition,$lyrVoi,$ygVoi,$msg_id);
	$re=exec("ffmpeg -i $fileName $filename.mp3");
	 Log::info(' voice len'.strlen($fileInfo["body"]).'filename--'.$filename);
	return $result;
}
//上传图片和语音
function uploadMedia($access_token,$filepath,$type){
	//过时的方法 $filedata = array("media" => "@".$filepath);
	$url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=$access_token&type=$type";
	$result = https_request($url, $filepath);
	$jsoninfo = json_decode($result, true);
	$media_id = $jsoninfo["media_id"];
	Log::info("  upload media_id  ".$media_id);
	Log::info("  upload result  ".$result);
	return $media_id;

}


function https_request($url,$path){
	//上传文件，path貌似只要相对路径即可
	$curl=curl_init();
	// Create a CURLFile object
	$cfile = curl_file_create($path);
	$filedata = array('media' => $cfile);
	// Log::info("    path---$path filedata--  ".var_dump($filedata).'cfile ---'.var_dump($cfile));
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($curl,CURLOPT_POST,1);
	curl_setopt($curl,CURLOPT_POSTFIELDS,$filedata);
	curl_setopt($curl, CURLOPT_INFILESIZE,filesize($path)); 
	Log::info(" path---$path filesize(path)--  ".filesize($path));
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	$output=curl_exec($curl);
	curl_close($curl);
	return $output;
}

function downloadWeixinFile($url){
	$ch=curl_init($url);
	curl_setopt($ch,CURLOPT_HEADER,0);
	curl_setopt($ch,CURLOPT_NOBODY,0);//只取body头
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	$package=curl_exec($ch);
	Log::info('package-len-'.strlen($package));
	$httpinfo=curl_getinfo($ch);
	curl_close($ch);
	$imageAll=array_merge(array('header'=>$httpinfo),array('body'=>$package));

	return $imageAll;
}
function saveWeixinFile($filename,$filecontent,$type,$fromUsername,$filenamemp3=null,$recognition=null,$lyrVoi=false,$ygVoi=false,$msg_id=0){
	$result="fail";
	$local_file=fopen($filename,'w');
	if(false!==$local_file){
		if(false!==fwrite($local_file,$filecontent)){
			$result="success";
			fclose($local_file);
			$openid='wx_'.$fromUsername;
			$idObjArr = DB::select("select id from users where name = '$openid'");
			$users_id=$idObjArr[0]->id;
			// 图片还是语音&谁先谁后$是否归为同一条
			if($lyrVoi){
				$filename="$filenamemp3.mp3";
				$idObjArr=DB::select("select id from users where name = '$openid'");
				if(!empty($idObjArr)){
					$users_id=$idObjArr[0]->id;
					try{
						DB::insert("insert into lyr_messages(audio,audio_text,users_id) values('$filename','$recognition',$users_id)");
						$result="success";
					}catch (Exception $e) {
						Log::info("lyrmessages insert wxlyrVoi error");
						$result="fail";
					}
				}
			}else if($ygVoi){
				$filename="$filenamemp3.mp3";
				$idObjArr=DB::select("select id from users where name = '$openid'");
				if(!empty($idObjArr)){
					$users_id=$idObjArr[0]->id;
					DB::update("update reply set messages_reply='$filename',state=".REPLY_VOICE." where users_id=$users_id and messages_id=$msg_id");
					DB::update("update messages set state=".MESSAGE_REPLY_FINISH." where id=$msg_id");
					$result=$filename;
				}
			}else{
				if($type=="pic"){
					$timeStamp=time();
					$upload_timeObjArr=DB::select("select * from messages where users_id = $users_id order by upload_time desc");
					if(empty($upload_timeObjArr)){
						try{
							Log::info("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
							DB::insert("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
							$result="success";
						}catch (Exception $e) {
							Log::info("messages insert wxpic error");
							$result="fail";
						}
					}else{
						$audio=$upload_timeObjArr[0]->audio;
						$audio_text=$upload_timeObjArr[0]->audio_text;
						$pic=$upload_timeObjArr[0]->pic;
						$id=$upload_timeObjArr[0]->id;
						$upload_time=(int)($upload_timeObjArr[0]->upload_time);
						Log::info("upload_time ts?--$upload_time");
						//判断时间间隔是否在2分钟之内，可否当成同一条消息
						if(($upload_time+2*60)>$timeStamp){
							if((!empty($audio))||(!empty($audio_text))){
								//同一条消息--update
								Log::info("同一条消息--update");
								if(empty($pic)){
									DB::update("update messages set pic = '$filename',state = ".UPLOAD_2." where id = $id");
									$result="success";
									Log::info("update messages set pic = '$filename',state = ".UPLOAD_2." where id = $id");
								}else{
									try{
										Log::info("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
										DB::insert("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
										$result="success";
									}catch (Exception $e) {
										Log::info("messages insert wxpic error");
										$result="fail";
									}
								}
							}
						}else{
							try{
								Log::info("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
								DB::insert("insert into messages(pic,state,users_id,upload_time) values('$filename',".UPLOAD_1.",$users_id,$timeStamp)");
								$result="success";
							}catch (Exception $e) {
								Log::info("messages insert wxpic2 error");
								$result="fail";
							}
						}
					}
				}else if($type=="voice"){
					$filename="$filenamemp3.mp3";
					$upload_timeObjArr=DB::select("select * from messages where users_id = $users_id order by upload_time desc");
					$timeStamp=time();
					if(empty($upload_timeObjArr)){
						try{
							
							DB::insert("insert into messages(audio,state,users_id,upload_time,audio_text) values('$filename',".UPLOAD_1.",$users_id,$timeStamp,'$recognition')");
							$result="success";
							
						}catch (Exception $e) {
							Log::info("messages insert wxaudio error");
							$result="fail";
						}
					}else{
						//upload_timeObjArr不为空
						$pic=$upload_timeObjArr[0]->pic;
						$audio=$upload_timeObjArr[0]->audio;
						$audio_text=$upload_timeObjArr[0]->audio_text;
						$id=$upload_timeObjArr[0]->id;
						$upload_time=(int)($upload_timeObjArr[0]->upload_time);
						//判断时间间隔是否在2分钟之内，可否当成同一条消息
						Log::info("pic-$pic,audio-$audio,id-$id,upload_time-$upload_time");
						if(($upload_time+2*60)>$timeStamp){
							if(!empty($pic)){
								Log::info("同一条消息--update");
								//同一条消息--update
								if(empty($audio)&&empty($audio_text)){
									DB::update("update messages set audio = '$filename',audio_text='$recognition',state = ".UPLOAD_2." where id = $id");
									$result="success";
									Log::info("update messages set audio = '$filename',audio_text='$recognition',state = ".UPLOAD_2." where id = $id");
								}else{
									//插入新的行
									try{
										
										DB::insert("insert into messages(audio,state,users_id,upload_time,audio_text) values('$filename',".UPLOAD_1.",$users_id,$timeStamp,'$recognition')");
										$result="success";
									}catch (Exception $e) {
										Log::info("messages insert wxaudio error");
										$result="fail";
									}
								}
							}else{
								//图片为空，插入新的行
								try{
									DB::insert("insert into messages(audio,state,users_id,upload_time,audio_text) values('$filename',".UPLOAD_1.",$users_id,$timeStamp,'$recognition')");
									$result="success";
								}catch (Exception $e) {
									Log::info("messages insert wxaudio error");
									$result="fail";
								}
							}
						}else{
							//2分钟以后的，插入新的行
							try{
								DB::insert("insert into messages(audio,state,users_id,upload_time,audio_text) values('$filename',".UPLOAD_1.",$users_id,$timeStamp,'$recognition')");
								$result="success";
							}catch (Exception $e) {
								Log::info("messages insert wxaudio2 error");
								$result="fail";
							}
						}
					}
				}
			}
		}
	}
	return $result;
}



function yg_sign_up($type,$openid){
	//0失败，1成功，2无效用户,3今日已签。
	$result='';
	Log::info("wx_yg_openid = $openid");
	$usersObjArr = DB::select("select * from users where name = '$openid'");
	Log::info("wx_yg_ select * from users where name = '$openid'");
	if (empty($usersObjArr)) {
		//无效用户
		$result='无效用户，请先注册再签到，谢谢';
	}else{
		// if($type=='sign_up'){

		// }
		// $last_login=$usersObjArr[0]->last_login;
		// $day=substr($last_login,0,10);
		// $today=date("Y-m-d",time());
		// Log::info("day = '$day' today = '$today'");	
		// if($day==$today){
		// 	// $result=3;
		// 	$result='今天签过啦';
		// 	Log::info("今日已签");	
		// }else{
			$timeStamp=date("Y-m-d H:i:s",time());
			DB::update("update users set last_login = '$timeStamp' where name = '$openid'");
			DB::update("update reply inner join users set reply.state =".MSG_FAIL." where users.name = '$openid' and users.id=reply.users_id and (reply.state=".MESSAGE_ALLOCATION_FINISH." || reply.state=".MESSAGE_ALLOCATION_BEGIN." || reply.state=".USERS_LOCK.")");
			$result='签到成功！您可以接收到提问啦，记得常来签到哦';	
		// }
	}
	return $result;
}


function lyr_score($fromUsername){
	$result=0;
	$openid=$fromUsername;
	Log::info("wx_yg_openid = $openid");
	$scoreObjArr = DB::select("select score from lyr inner join users where users.name = '$openid' and lyr.users_id=users.id");
	Log::info("select score from lyr inner join users where users.name = '$openid' and lyr.users_id=users.id");
	if (empty($scoreObjArr)) {
		//无效用户
		$result='非法查询，请先验证身份';
	}else{
		$result='您当前的积分为：'.$scoreObjArr[0]->score;
	}
	return $result;
}
/* 
//下载多媒体文件,其实图片和音频都可以用同一个函数的
function saveMedia($url,$filename){
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);    
	curl_setopt($ch, CURLOPT_NOBODY, 0);    //对body进行输出。
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$package = curl_exec($ch);
	$httpinfo = curl_getinfo($ch);
	curl_close($ch);
	$media = array_merge(array('mediaBody' => $package), $httpinfo);
	//求出文件格式
	// preg_match('/\w\/(\w+)/i', $media["content_type"], $extmatches);
	// $fileExt = $extmatches[1];
	$fileName=$filename.".amr";
	$fp = fopen($fileName, 'w');  
	fwrite($fp, $package);  
	fclose($fp);  
	//amr转mp3
	exec("ffmpeg -i $fileName $filename.mp3");

} */
?>
