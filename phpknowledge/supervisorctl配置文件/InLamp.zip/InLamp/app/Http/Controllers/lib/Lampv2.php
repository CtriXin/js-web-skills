<?php

// echo Lampv2::resetPwd(['userPhone'=>'13714876874','newPassword'=>'123123','reset'=>'1','password'=>'123456']);
// echo Lampv2::resetPwd(['userPhone'=>'13714876874','newPassword'=>'123456','reset'=>'0','smscode'=>'123456']);
 // $arr=['userPhone'=>'13714876874','password'=>'123456','type'=>'S002'];
 // echo 're'.Lampv2::login($arr);

// $arr=['userId'=>'1-xe-Onc4v9bg4HxmwCIrk'];
// echo 're'.Lampv2::getBindList($arr);

// $arr=['userPhone'=>'13714876874','password'=>'a123456','smscode'=>'1234'];
// echo 're'.Lampv2::register($arr);

/**
 * @version 1.0
 * @date 2015-12-12
 * @author hgx
 * Class Lamp 办学机协议2.0相关 mvp接口
 * 
 */
class Lampv2
{

    private static $host='http://bxj.server.snewfly.com:8686/';//测试接口
    // private static $host='http://182.92.73.34:8080/lpserver/';//测试接口
    // private static $host='http://120.24.76.242:8686/lpserver/';//zhengshi接口
    private static $url_sendsms='/sms/sendsms.action';
    private static $url_login='/user/login.action';
    private static $url_register='user/register.action';
    private static $url_reset_pwd='/user/updatepwd.action';
    private static $url_bind_device='/binder/bind.action';
    private static $url_unbind_device='/binder/cancel.action';
    private static $url_get_bind_list='/binder/list.action';
    private static $url_edit_device='/binder/edit.action';
    private static $url_query_study_data='/ld/list.action';

    /**
    * sendSMS,发送验证码
    * @param $userPhone 手机号
    * @param $sendtype String  0|| 1   0为注册 1为找回密码 
    * @return $json
    */
    public static function sendSMS($arr)
    {
        return self::routeToPost($arr,self::$url_sendsms);
    }

    /**
    * login,登录
    * @param $userPhone 手机号
    * @param $password 6~12位数字+字母
    * @param $type S003
    * @return $json
    */
    public static function login($arr)
    {
        return self::routeToPost($arr,self::$url_login);
    }

    /**
    * register
    * @param $userPhone 手机号
    * @param $password 6~12位数字+字母
    * @param $smscode 
    * @return $json
    */
    public static function register($arr)
    {
        return self::routeToPost($arr,self::$url_register);
    }

    /**
    * resetPwd
    * @param $userPhone 手机号
    * @param $password 6~12位数字+字母
    * @param $newPassword 
    * @param $reset 0忘记密码重设  1正常修改密码重设
    * @param $smscode 忘记密码重设密码时需要，正常更改密码不需要
    * @return $json
    */
    public static function resetPwd($arr)
    {
        return self::routeToPost($arr,self::$url_reset_pwd);
    }

    /**
    * bindDevice
    * @param $deviceId 设备号
    * @param $userId 用户id
    * @param $bxjName 称呼 
    * @param $nick 昵称
    * @param $button 分别为F(父),M(母),O(其它)
    * @return $json
    */
    public static function bindDevice($arr)
    {
        return self::routeToPost($arr,self::$url_bind_device);
    }

    /**
    * unbindDevice
    * @param $deviceId 设备号
    * @param $userId 用户id
    * @return $json
    */
    public static function unbindDevice($arr)
    {
        return self::routeToPost($arr,self::$url_unbind_device);
    }

    /**
    * getBindList 3.1.7 获取伴学机列表
    * @param $userId 用户id
    * @return $json
    */
    public static function getBindList($arr)
    {
        return self::routeToPost($arr,self::$url_get_bind_list);
    }

    /**
    * editDevice 编辑伴学机
    * @param $deviceId 设备号
    * @param $userId 用户id
    * @param $realName 伴学机姓名 
    * @param $bxjName 称呼
    * @param $button 分别为F(父),M(母),O(其它)
    * @return $json
    */
    public static function editDevice($arr)
    {
        return self::routeToPost($arr,self::$url_edit_device);
    }


    /**
    * queryStudyData 查询学习数据
    * @param $deviceId 
    * @param $start 按月份，则为YYYY-MM
    * @param $end
    * @return $json
    */
    public static function queryStudyData($arr)
    {
        return self::routeToPost($arr,self::$url_query_study_data);
    }

    public static function routeToPost($arr,$route_url)
    {
        $url=self::getUrlByRoute($route_url);
        return self::getPostByArr($url,$arr);
    }


    /**
    * 通用url 获取
    * @param $route
    * @return url
    */
    public static function getUrlByRoute($route){
        return self::$host.$route;
    }


    /**
    * 通用arr url 获取远程服务器json
    * @param $json
    * @return $result json格式返回结果
    */
    public static function getPostByArr($url,$arr){
        $data=self::arrayParamToString($arr);
        return self::http_request($url, $data);
    }



    /**
    * HTTP请求（支持HTTP/HTTPS，支持GET/POST）http_request
    * @param string $data post data 空则为GET
    * @param string $url 
    * @return string $result
    */    
    public static function http_request($url, $data = null)
    {
        $curl = curl_init();
    //curl_setopt($curl, CURLOPT_PORT, '12346');//爱贝多端口12346
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }

    /**
     * arrayParamToString 将数组转成post格式的参数
     * @return str 
     */
    public static function arrayParamToString($arr){
        $str='';
        foreach ($arr as $key => $value) {
            $str.=$key.'='.$value.'&';
        }
        if ($str!='') {
            $str=substr($str,0,strlen($str)-1);
        }
        return $str;
    }


}