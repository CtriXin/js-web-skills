<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Log;
use Input;
use DB;
use Memcache;
// $logFile ='wechat.log';
set_time_limit(0);
// Log::useDailyFiles(storage_path().'/logs/'.$logFile);

define('UID_TIME', 172800);//用户id缓存的时间2天

define('APP_ID', 'wx05336cfd4ec2ec5f');//
define('APP_KEY', '6b7ac5a8f0637626230cde84cbd2e483');//


class WechatBaseController extends Controller{
	//回复信息
	public function transmitText($fromUsername,$toUsername,$content){
		$textTpl = '<xml>
		<ToUserName><![CDATA[%s]]></ToUserName>
		<FromUserName><![CDATA[%s]]></FromUserName>
		<CreateTime>%s</CreateTime>
		<MsgType><![CDATA[text]]></MsgType>
		<Content><![CDATA[%s]]></Content>
		<FuncFlag>0</FuncFlag>
	</xml>';
	$result = sprintf($textTpl, $fromUsername, $toUsername, time(), $content);
	Log::info('result---'.$result);
	return $result;
}

//随机数
private function createNonceStr($length = 16) {
	$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$str = '';
	for ($i = 0; $i < $length; $i++) {
		$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
	}
	return $str;
}


	//还在身边公众号的wx05336cfd4ec2ec5f，6b7ac5a8f0637626230cde84cbd2e483
public function getAccessToken($appid ,$appsecret,$mem_key='hzsb_access_token'){
		//设置缓存，100分钟更新一次access_token
	$mem = new Memcache;
	$mem->connect('localhost', 11211) or die ("Could not connect");
	$access_token = $mem->get($mem_key);
	Log::info('access_token----'.$access_token);
	if (empty($access_token)){
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
		$res = $this->http_request($url);
		$result = json_decode($res, true);
		$access_token = $result['access_token'];
		$mem->set($mem_key, $access_token, 0, 6000);
		Log::info('set access_token----'.$access_token);
	}
	$mem->close();
	return $access_token;
}


	//JsApiTicket
public function getJsApiTicket() {
  	//设置缓存，100分钟更新一次access_token
	$mem = new Memcache;
	$mem->connect('localhost', 11211) or die ('Could not connect');
	$hzsf_jsApiTicket = $mem->get('hzsb_jsApiTicket');
	Log::info('hzsb_jsApiTicket----'.$hzsf_jsApiTicket);
	if (empty($hzsf_jsApiTicket)){
		$accessToken=$this->getAccessToken(APP_ID,APP_KEY);
		$url = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token='.$accessToken;
		$res = $this->http_request($url);
		$result = json_decode($res, true);
		if (array_key_exists('ticket', $result)) {
			$hzsf_jsApiTicket = $result['ticket'];
		}
		$mem->set('hzsb_jsApiTicket', $hzsf_jsApiTicket, 0, 6000);
		Log::info('set hzsb_jsApiTicket----'.$hzsf_jsApiTicket);
	}
	$mem->close();
	return $hzsf_jsApiTicket;
}

  //wx js sdk return array
public function getSignPackage() {
	$jsapiTicket = $this->getJsApiTicket();

    // 注意 URL 一定要动态获取，不能 hardcode.
	$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

	$timestamp = $_SERVER['REQUEST_TIME'];
	$nonceStr = $this->createNonceStr();

    // 这里参数的顺序要按照 key 值 ASCII 码升序排序
	$string = 'jsapi_ticket='.$jsapiTicket.'&noncestr='.$nonceStr.'&timestamp='.$timestamp.'&url='.$url;

	$signature = sha1($string);

	$signPackage = array(
		'appId'     => 'wx05336cfd4ec2ec5f',
		'nonceStr'  => $nonceStr,
		'timestamp' => $timestamp,
		'url'       => $url,
		'signature' => $signature,
		'rawString' => $string
		);
	return $signPackage; 
}

	//HTTP请求（支持HTTP/HTTPS，支持GET/POST）
protected function http_request($url, $data = null)
{
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $url);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	if (!empty($data)){
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	}
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$output = curl_exec($curl);
	curl_close($curl);
	return $output;
}
	//主动发送消息
public function sentMsg($fromUsername,$content){
	$access_token =$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.$access_token;
	$postData='{
		"touser":"'.$fromUsername.'",
		"msgtype":"text",
		"text":{"content":"'.$content.'"   }
	}';
	Log::info(" postData----".$postData."access_token----".$access_token);
	$result=$this->http_request($url,$postData);
	Log::info(" result----".$result);
	return $result;
}
	//主动发送语音消息
public function sendMediaMsg($fromUsername,$media_id,$type){
	$access_token = $this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token='.$access_token;
	$postData='{
		"touser":"'.$fromUsername.'",
		"msgtype":"'.$type.'",
		"'.$type.'":{"media_id":"'.$media_id.'"   }
	}';
	Log::info('postData----'.$postData.'access_token----'.$access_token);
	$result=$this->http_request($url,$postData);
	Log::info('result----'.$result);
	return $result;
}


/**
*获得用户昵称
* @param openid
* @return nickname
*/
public function getUserNickname($openid){
	$access_token=$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
	$jsonArr=json_decode($this->http_request($url),true);
	$nickname='';
	if (array_key_exists('nickname',$jsonArr)) {
		$nickname=$jsonArr['nickname'];
	}
	return $nickname;
}

/**
*获得用户所有信息
* @param openid
* @return json
*/
public function getUserInfo($openid){
	$access_token=$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
	return $this->http_request($url);
}

public function updateLoginTime($users_id)
{
	$ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
	DB::update('update users set last_login='."'$ts'".' where id='.$users_id);
}

/**
* 获得推广二维码的ticket 用户phone作为scene_id
* @param users_id 用户id
* @param phone 用户手机号，作为scene_id
* @return ticket
*/
public function getTicket($phone){
	$ticket='';
	$reArr=DB::select('select ticket from ticket where phone='.$phone);
	if ($reArr) {//如果数据库存在，直接从数据库取出
		return $reArr[0]->ticket;
	}
	//否则获取并存入数据库
	$access_token=$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token;
	// $data='{"action_name": "QR_LIMIT_SCENE", "action_info": {"scene": {"scene_id": '.$phone.'}}}';
	$data='{"action_name": "QR_LIMIT_STR_SCENE", "action_info": {"scene": {"scene_str": "'.$phone.'"}}}';

	$jsonArr=json_decode($this->http_request($url,$data),true);

	if (array_key_exists('ticket',$jsonArr)) {
		$ticket=$jsonArr['ticket'];
	}
	if ($ticket) {
		try {
			DB::insert("INSERT INTO `ticket` (`phone` ,`ticket`)VALUES ('$phone',  '$ticket')");
		} catch (Exception $e) {
			Log::info("error INSERT INTO `ticket` (`phone` ,`ticket`)VALUES ('$phone',  '$ticket')");
		}
	}
	
	return $ticket;
}


/**
* 更新微信小店订单到数据库
* 
*/
public function updateOrder(){
	$access_token=$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/merchant/order/getbyfilter?access_token='.$access_token;
	$data='';
	$re=DB::select('SELECT * FROM  `order` ORDER BY  `order`.`id` DESC LIMIT 0 , 1');
	if ($re) {
		$create_time=strtotime($re[0]->create_time);//转时间戳
		$data='{"begintime": '.$create_time.', "endtime": '.$_SERVER['REQUEST_TIME'].'}';
	}else{
		$data='{}';//首次初始化
	}
	$arr=json_decode($this->http_request($url,$data));
	$count=count($arr->order_list);
	if ($count==0) {
		return;
	}
	//插入数据库、一次插完
	$sql='INSERT INTO  `in_lamp`.`order` (`order_id` ,`status` ,`total_price` ,`order_create_time` ,`express_price` ,
			`buyer_openid` ,`buyer_nick` ,`product_id` ,`product_name` ,`product_count` ,`trans_id` ,`product_price`) VALUES ';
	
	for ($i=0; $i <$count ; $i++) { 
		$obj=$arr->order_list[$i];
		$sql.=" (
			'{$obj->order_id}',  '$obj->order_status',  '$obj->order_total_price'
			, '$obj->order_create_time' ,  '$obj->order_express_price',  '$obj->buyer_openid'
			,  '$obj->buyer_nick',  '$obj->product_id',  '$obj->product_name'
			,  '$obj->product_count',  '$obj->trans_id',  '$obj->product_price'),";
	}

	$sql=substr($sql,0,strlen($sql)-1);
	try {
		DB::insert($sql);
	} catch (Exception $e) {
		Log::info("error DB::insert($sql);");
	}

}

/**
* 通过手机号联查
* 
*/
public function getRecNumByPhone($phone)
{
	$re=DB::select('SELECT COUNT(*)total FROM rec INNER JOIN `order` ON `rec`.`name` = `order`.`buyer_openid` WHERE rec.`rec_id`='."'$phone'");
	Log::info($phone."re->total".$re[0]->total);
	return $re[0]->total;
}

/**
* 
*/
public function getRecNumBySP($type)
{
	$type=$type=='1'?1:0;
	$re=DB::select('SELECT COUNT(*) total,rec_id FROM rec ,`order` WHERE rec.`type`='.$type.' AND `rec`.`name` = `order`.`buyer_openid` GROUP BY rec_id');
	return json_encode($re);
}


/**
* 获得推广二维码的ticket 用户id+100作为scene_id,
* @param users_id 用户id
* @return ticket
*/
public function getTicketExtra($users_id){
	$ticket='';
	$reArr=DB::select('select ticket from ticket_extra where rec_id='.$users_id);
	if ($reArr) {//如果数据库存在，直接从数据库取出
		return $reArr[0]->ticket;
	}
	//否则获取并存入数据库
	$access_token=$this->getAccessToken(APP_ID,APP_KEY);
	$url='https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token;
	$data='{"action_name": "QR_LIMIT_SCENE", "action_info": {"scene": {"scene_id": '.($users_id).'}}}';
	$jsonArr=json_decode($this->http_request($url,$data),true);
	
	if (array_key_exists('ticket',$jsonArr)) {
		$ticket=$jsonArr['ticket'];
	}
	if ($ticket) {
		try {
			DB::insert("INSERT INTO `ticket_extra` (`rec_id` ,`ticket`)VALUES ('$users_id',  '$ticket')");
		} catch (Exception $e) {
			Log::info("error INSERT INTO `ticket` (`rec_id` ,`ticket`)VALUES ('$users_id',  '$ticket')");
		}
	}
	
	return $ticket;
}

/**
* auth 认证回调的code
* @param $code 
* @return json 
*/
public function code2openid($code)
{
	$url='https://api.weixin.qq.com/sns/oauth2/access_token?appid='.APP_ID.'&secret='.APP_KEY.'&code='.$code.'&grant_type=authorization_code';
    return $this->http_request($url);//code->access_token
}

	/**
	 * @param $iemi,$timestamp,$nonce,$signature
	 * 学生卡统一签名校验
	 * @return boolean
	 */
	protected function signatureCheck()
	{
		// 获取fromUser
		$fromUser = Input::get('fromUser');

		// 获取toUser
		$toUser = Input::get('toUser');

		// 获取timestamp 10位
		$timestamp = Input::get('timestamp');

		// 获取Nonce
		$nonce = Input::get('nonce');

		// 获取signature
		$signature = Input::get('signature');

		// 格式化时间戳
		// $timestamp = substr($timestamp, 0, 10);

		// 对字符串进行hash1加密
		$secret = 'snpafs*1n2oz';

		Log::info("fromUser: $fromUser | toUser: $toUser | timestamp: $timestamp | nonce: $nonce | signature: $signature");
		$str = sha1($fromUser.$toUser.$timestamp.$nonce.$secret);
		Log::info("encoded signature: $str");
		
		// 如果校验通过返回true，否则返回false
		if ($str == $signature) {
			Log::info('method: check | true');
			return true;
		}
		else{
			Log::info('method: check | false');
			return false;
		}
	}


	/**
	 * @param $iemi,$timestamp,$nonce,$signature
	 * 学生卡 考勤统一签名校验
	 * @return boolean
	 */
	protected function signatureSignCheck()
	{
		// 获取fromUser
		$cardId = Input::get('cardId');

		// 获取timestamp 10位
		$timestamp = Input::get('timestamp');

		// 获取Nonce
		$nonce = Input::get('nonce');

		// 获取signature
		$signature = Input::get('signature');

		// 格式化时间戳
		// $timestamp = substr($timestamp, 0, 10);

		// 对字符串进行hash1加密
		$secret = 'we232*2amk%hgx';

		Log::info("cardId: $cardId | timestamp: $timestamp | nonce: $nonce | signature: $signature");
		$str = sha1($cardId.$timestamp.$nonce.$secret);
		Log::info("encoded signature: $str");
		
		// 如果校验通过返回true，否则返回false
		if ($str == $signature) {
			Log::info('method: check | true');
			return true;
		}
		else{
			Log::info('method: check | false');
			return false;
		}
	}

}
?>