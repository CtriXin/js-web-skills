<?php
namespace App\Http\Controllers;

use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
use DB;
require_once('lib/Tool.php');
require_once('lib/Http.php');
use Tool;
use Http;

// define('NET_ERR', '网络错误，请稍后重试');

set_time_limit(0);

/**
 * Class CardSignController 考勤反馈给老师
 * @package App\Http\Controllers
 * anthor hgx
 */
class CardSignRequestController extends ZhihuiWechatBaseController{

    //智慧教育
  private static $appId='wx2683432074892f86';
  private static $secret='9147009bbad321887c93b17cc1989c7e';


  private function sendTp($openidObjArr,$studentName,$type,$userIdArr,$msgId)
  {
    $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

    $template_id='bL65vNFAn0SGZT7MuZBANW12Cg3khu3gnXSSAakE-D4';
    $first='您的学生已离校';
    $keyword1=$ts;
    $keyword2='校门';
    $keyword3=$studentName;
    $remark='点击进入考勤反馈';
    $url='';
    if ($type=='进校') {
      $template_id='1BElgC9t0A1EWTgSJRsgVpyLUyZe2FzAqHxNglZeaPk';
      $first='您的学生已到校';
      $keyword1=$studentName;
      $keyword2=$type;
      $keyword3=$ts;

    }

    $count=count($openidObjArr);
    for ($i=0; $i < $count; $i++) {
      $url='http://bxj.snewfly.com/card_attance_request.php?userId='.$userIdArr[$i].'&deviceId='.Input::get('deviceId').'&studentName='.$studentName.'&ts='.$ts.'&msgId='.$msgId.'&type='.$type;
      $this->sendTemplateMsg($openidObjArr[$i]->name,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
    }

  }

  private function sendNearTp($openidObjArr,$studentName,$userIdArr,$msgId)
  {
    $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

    $template_id='YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE';
    $first='您的学生已到校门区域';
    $keyword1='考勤';
    $keyword2=$studentName;
    $keyword3=$ts;
    $remark='点击进入考勤反馈';
    $url='';

    $count=count($openidObjArr);
    for ($i=0; $i < $count; $i++) {
      $url='http://bxj.snewfly.com/card_attance_request.php?userId='.$userIdArr[$i].'&deviceId='.Input::get('deviceId').'&studentName='.$studentName.'&ts='.$ts.'&msgId='.$msgId.'&type=校门区域';
      $data=$this->createDeviceTemplate($openidObjArr[$i]->name,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
      $this->sendTemplate($data);
    }

  }


  private function getOpenidArr($userIdArr)
  {
    $count=count($userIdArr);
    $str='SELECT name FROM users WHERE ';
    for ($i=0; $i <$count ; $i++) { 
      $str.="user_id='{$userIdArr[$i]}'||";
    }

    $sql=substr($str,0,strlen($str)-2);
    return DB::select($sql);
  }

  private function getTypeName($type)
  {
    $mtype='';
    switch ($type) {
      case '0':
      $mtype='出校';
      break;
      case '1':
      $mtype='进校';
      break;

      default:
      $mtype='未定义';
      break;
    }
    return $mtype;
  }

    /**
    * 学生卡考勤反馈接口
    * @return json
    */
    public function cardSignRequest(){

      $data=file_get_contents('php://input');
      Log::info($data);

      $userId=Input::get('userId');
      $msgId=Input::get('msgId');
      $type=Input::get('type');
      if ($userId && $msgId && $type!='') {
        $studentName=Input::get('studentName');
        $userIdArr=explode(',',$userId);
        $openidObjArr=$this->getOpenidArr($userIdArr);

        if ($type=='4') {//校区附近
          $this->sendNearTp($openidObjArr,$studentName,$userIdArr,$msgId);
        }else{//0,1到离校推送
          $type=$this->getTypeName($type);
          $this->sendTp($openidObjArr,$studentName,$type,$userIdArr,$msgId);
        }
        return Tool::getJson('1');
      }

      return Tool::getJson('0','参数缺失');

    }

    public function attendanceConfirm()
    {
      $msgId=Input::get('msgId');
      $userId=Input::get('userId');

      $url='http://kq.snewfly.com:8081/api/attendance/send_notice';
      $data='msg_id='.$msgId.'&user_id='.$userId;
      return Http::http_request($url,$data);
    }


  /**
  *返回协议模式的设备事件提醒模板消息
  * 设备事件提醒id YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 提醒类型
  *@param keyword2 设备序号
  *@param keyword3 发生时间
  *@param remark 最低行 如点击查看历史记录
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createDeviceTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url=''){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return urldecode(json_encode($data));
  }



}
?>