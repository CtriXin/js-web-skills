<?php
namespace App\Http\Controllers;

use App\Http\Controllers\WechatBaseController;
use Log;
use Input;
use DB;
use Memcache;
use View;

require_once('lib/Tool.php');
require_once('lib/Http.php');
require_once('lib/MyWechat.php');
require_once('lib/Card.php');
require_once('lib/Lamp.php');
use MyWechat;
use Card;
use Lamp;
use Tool;
use Http;


define('REMOTE_HOST', 'http://120.24.76.242:8686/hzsbServer/');//登录成功标志
define('LOGIN_URL', REMOTE_HOST.'wechat/login.action');//登录url
define('GETDEVICE_URL', REMOTE_HOST.'wechat/getdevice.action');//获取设备
define('GETDAILYDATA_URL', REMOTE_HOST.'xbj/chatbynow.action');//获取设备每日数据
define('GETMONTHLYDATA_URL', REMOTE_HOST.'xbj/querybychat.action');//获取设备每月数据
define('GET_USER_NAME_URL', REMOTE_HOST.'wechat/getnamebyphone.action');//获取自己昵称

define('URL_AUTH_LOGIN', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx05336cfd4ec2ec5f&redirect_uri=http://lamp.snewfly.com/auth2&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect');
define('URL_AUTH_LOGIN_QR', 'http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx05336cfd4ec2ec5f&redirect_uri=http://lamp.snewfly.com/auth&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect');

define('NET_ERR', '网络错误，请稍后重试');
define('PAGE_ERR', '页面过期，请重新从公众号进入');
define('RELOG_ERR', "请重新登录<script type='text/javascript'>alert('请重新登录');close();</script>");

set_time_limit(0);

/**
 * Class WechatAuthController
 * @package App\Http\Controllers
 * anthor hgx
 */
class WechatAuthController extends WechatBaseController{

    /**
     * @var Memcache
     */
    private $openid,$mem,$uid;
    private static $appId='wx05336cfd4ec2ec5f';
    private static $secret='6b7ac5a8f0637626230cde84cbd2e483';
    //智慧教育
    // private static $appId='wx2683432074892f86';
    // private static $secret='9147009bbad321887c93b17cc1989c7e';
    public function __construct(){
    	if(!isset($_SESSION)){  
    		session_start();   //开启session
      }
      $this->mem = new Memcache;
      $this->mem->connect('localhost', 11211) or die ('Could not connect');
    }


  //生成ticket、获取链接
/*  public function getTicket1()
  {
    // for ($i=0; $i < 80; $i++) { 
    //   $this->getTicketExtra($i);
    // }
    // return 'finish';
    // https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=
    $prefix='https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=';
    $reArr=DB::select('select * from ticket_extra where rec_id>48 and rec_id<590');
    $str='';
    for ($i=0; $i <count($reArr) ; $i++) { 
      $str.=$reArr[$i]->rec_id.'|'.$prefix.$reArr[$i]->ticket.'<br/>';
    }

    return $str;
  }*/

  /**
  * 学生卡登录
  * @return json
  */
  public function card_login(){

    $loginName=Input::get('name');
    $loginPwd=Input::get('pwd');
    if ($loginName && $loginPwd) {
      // $re=Card::userLogin($loginName,$loginPwd);
      // Log::info($loginName.'-'.$loginPwd.'card_login:'.$re);
      // $xmlObj = simplexml_load_string($re);
      $_SESSION['id'] = "o4ugXtwanykZPmdiyN4iTA0L6u08";//测试用的openid
      $_SESSION['card_userId'] = "c_4QQ9PnAv3aPG626IGZ5z";//测试用的userid
      $_SESSION['card_loginName'] = $loginName;//测试用的userid
      $_SESSION['card_terminalId'] = $loginName;//测试用的userid
      return '{}';
    }
    return Tool::getJson('0','账号或密码为空');
  }


    /**
    * 获取微信用户信息
    * @return json
    */
    public function wechatinfo(){
      return $this->getUserInfo($_SESSION['id']);
    }


    /**
    * 获取最后一条location
    * @return json
    */
    public function card_getUserInfo(){
      if (array_key_exists('sc_username',$_SESSION)){
        $re=DB::connection('mongodb')->collection('usercollection')
        ->where('username',$_SESSION['sc_username'])->first();

        if (!empty($re)) {
          return Tool::getJson('1','',$re);
        }
        return Tool::getJson('1');
      }
      return Tool::getJson('0','登录超时，请重新从微信进入');
    }

    /**
    * 获取用户绑定设备
    * @return json
    */
    public function queryDevice(){
       $re=Card::queryDevice(['userid'=>$_SESSION['card_userId']]);
        Log::info('queryDevice'.$re.json_encode(['userid'=>$_SESSION['card_userId']]));
        return $re;
    }

    /**
    * 获取用户绑定设备
    * @return json
    */
    public function getBindPhoneByImei(){
        $imei=Input::get('imei');
       $re=Card::getDeviceBindPhone(['userid'=>$_SESSION['card_userId'],'device_id'=>$imei]);
        Log::info('getBindPhoneByImei'.$re.json_encode(['userid'=>$_SESSION['card_userId'],'device_id'=>$imei]));
        return $re;
    }

    /**
    * 学生卡绑定编辑设备
    * '&imei='+imei+'&nick='+nick+'&pwd='+pwd+'&sex='+sex+'&pic='+pic+'&type='+type,
    * @return json
    */
    public function submitEditDevice(){
      $imei=Input::get('imei');
      $nick=Input::get('nick');
      $pwd=Input::get('pwd');
      $sex=Input::get('sex');
      $pic=Input::get('pic');
      $type=Input::get('type');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'password'=>$pwd,'picture'=>$pic,'nick'=>$nick,'sex'=>$sex];
      if ($type=='2') {//编辑
        $re=Card::editDevice($arr);
        Log::info('editDevice');
      }else{//添加
        $re=Card::addDevice($arr);
        Log::info('addDevice');
      }
        Log::info('submitEditDevice'.$re.json_encode($arr));
        return $re;
    }

    /**
    * 学生卡绑定编辑设备
    * 'device_id userid
    * @return json
    */
    public function deleteDevice()
    {
      $imei=Input::get('imei');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei];
      $re=Card::deleteDevice($arr);
      Log::info('deleteDevice'.$re.json_encode($arr));
        return $re;
    }

    /**
    * 学生卡设备管理
    * 'device_id userid fields
    * @return json
    */
    public function submitManageSettings()
    {
      $quick_dial=Input::get('quick_dial');
      $volume=Input::get('volume');
      $imei=Input::get('imei');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'fields'=>json_encode(['quick_dial'=>$quick_dial,'volume'=>$volume])];
      $re=Card::infoSet($arr);
      Log::info('submitManageSettings'.$re.json_encode($arr));
        return $re;
    }

    /**
    * 到离校通知设置
    * 'device_id userid flag
    * @return json
    */
    public function submitToggleAttendance()
    {
      $flag=Input::get('flag');
      $imei=Input::get('imei');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'flag'=>$flag];
      $re=Card::attendanceNoticeSet($arr);
      Log::info('submitToggleAttendance'.$re.json_encode($arr));
        return $re;
    }

    /**
    * 获取消息中心
    * @return json
    */
    public function card_getMsgCenter(){
      $re=Card::msgCenter(['userid'=>$_SESSION['card_userId'],'action'=>'!voice']);
      Log::info('card_getMsgCenter'.$re.json_encode(['userid'=>$_SESSION['card_userId'],'action'=>'!voice']));
      return $re;
    }

    /**
    * 获取消息中心
    * @return xml
    */
    public function card_getTerminalExt(){
      if (array_key_exists('card_terminalId',$_SESSION)){
        $re=Card::terminalExt($_SESSION['card_terminalId']);
        Log::info('card_getTerminalExt'.$re);
        return $re;
      }
      return Tool::getJson('0','登录超时，请重新从微信进入');
    }


    /**
    * 经纬度转实际地址
    * @return json
    */
    public function card_getGeoReverse(){
      if (array_key_exists('card_terminalId',$_SESSION)){
        $orgiLat=Input::get('orgiLat');
        $orgiLng=Input::get('orgiLng');
        $lat=Input::get('lat');
        $lng=Input::get('lng');
        $isGps=Input::get('isGps');
        $re=Card::geoReverse($orgiLat,$orgiLng,$lat,$lng,$isGps);
        Log::info('card_getGeoReverse'.$re);
        return $re;
      }
      return Tool::getJson('0','登录超时，请重新从微信进入');
    }


    /**
    * 保存更新所有卡号码
    * @return json
    */
    public function card_saveAllPhoneNum(){
      if (array_key_exists('sc_id',$_SESSION)){
          // saveAllPhoneNum(sos1,sos2,sos3,familyName1,familyName2,familyName3,familyName4,familyNum1,familyNum2,familyNum3,familyNum4){
        $sos1=Input::get('sos1');
        $sos2=Input::get('sos2');
        $sos3=Input::get('sos3');
        $familyName1=Input::get('familyName1');
        $familyName2=Input::get('familyName2');
        $familyName3=Input::get('familyName3');
        // $familyName4=Input::get('familyName4');
        $familyNum1=Input::get('familyNum1');
        $familyNum2=Input::get('familyNum2');
        $familyNum3=Input::get('familyNum3');
        // $familyNum4=Input::get('familyNum4');
        Log::info($sos1.$sos2.$sos3.$familyName1.$familyName2.$familyName3.$familyNum1.$familyNum2.$familyNum3);
        $re=DB::connection('mongodb')->collection('telnumInfo')->where('id',$_SESSION['sc_id'])
        ->update(['sos1' => $sos1,'sos2' => $sos2,'sos3' => $sos3,
          'name1' => $familyName1,'name2' => $familyName2,'name3' => $familyName3,
          'family1' => $familyNum1,'family2' => $familyNum2,'family3' => $familyNum3]);
          if ($re) {//更新成功
            $re=DB::connection('mongodb')->collection('updateInfo')->where('id',$_SESSION['sc_id'])
            ->update(['sos_num' => 1,'family_num' => 1,'status' => 1]);
          if ($re) {//更新成功
            return Tool::getJson('1',"保存成功，需要过一会儿才会生效哦");
          }
        }else{
          Log::info("gx 失败");
        }
        return Tool::getJson('1',"保存失败，请稍后重试");

      }
      return Tool::getJson('0','登录超时，请重新从微信进入');
    }


    public function hzsb_sendSMS()
    {
      $phone=Input::get('phone');
      return Lamp::sendSMS($phone,'0');//注册
    }

    public function hzsb_register()
    {
      $phone=Input::get('phone');
      $password=Input::get('password');
      $checkCode=Input::get('checkCode');
      return Lamp::register($phone,$password,$checkCode);
    }

	/**
	* 还在身边auth登录，绑定账号
	* @return js
	*/
	public function hzsb_login(){
		if (array_key_exists('id',$_SESSION) ) {
			$this->openid=$_SESSION['id'];
			$phone=Input::get('phone');
			$password=Input::get('password');
			if ($phone!='' && $password!='') {
				//向远程服务器请求
				$data='userPhone='.$phone.'&password='.$password.'&openId='.$this->openid;
				Log::info('login'.LOGIN_URL.$data);
				$re=Http::http_request(LOGIN_URL,$data);
				Log::info('login'.$re);
				$msg='';
				$data='';
				$tokenId='';//用于通信的id
				// $re='{"data":[{"rtonken":"ltJzE9Y1f5ElMnfeJNXrK3j9nsG5sY6Y4/9MzEU1maKfnKsQKCiz/tOw0PcEexq/DIQLhL6/5OtX0S8H68aFCA=="}],"extra":"","message":"","status":"000000"}';
				try {
					$jsonObj=json_decode($re,true);
					if ($jsonObj['extra']!='') {
						$msg=$jsonObj['extra'];
					}else{
						$data=$jsonObj['data']['rtoken'];
						$tokenId=$jsonObj['data']['tokenId'];
                    	$_SESSION['rong_token']=$data;//存入session
                    	$_SESSION['rong_token_id']=$tokenId;//存入session
                    	$_SESSION['telephone'] =$phone;//将用户手机号保存到session中
                                    //记录最后登录时间
                      $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
                      DB::update("update users set  token_id='',telephone='',password='',rong_token='' where telephone='$phone' and password='$password' and id!=".$_SESSION['users_id']);
                      DB::update("update users set last_login='$ts', telephone='$phone',password='$password',rong_token='$data',token_id='$tokenId' where id=".$_SESSION['users_id']);
                    }
                    
                  } catch (Exception $e) {
                  }
                  return Tool::getJson($jsonObj['status'],$msg,$data);
                }else{
                 return Tool::getJson('0','账号或密码为空','账号或密码为空');
               }

             }else{
               return Tool::getJson('0','请重新从微信进去','请重新从微信进去');
             }
           }


  /**
  * 还在身边auth登录，qr
  * @return js
  */
  public function users_center_qr(){
    //以后在这里判断是不是微信浏览器
    $code=Input::get('code');
    if ($code) {
      $re=$this->code2openid($code);
      Log::info($re);
      if($re){
        $jsondecode=json_decode($re,true);
        if (array_key_exists('openid',$jsondecode)) {
          Log::info('openid->'.$jsondecode['openid']);
          $this->openid=$jsondecode['openid'];
          if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");
            if ($re[0]->rong_token && $re[0]->password) {
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中

              //记录最后登录时间
              $this->updateLoginTime($re[0]->id);

              $ticket=$this->getTicket($re[0]->telephone);
              if ($ticket=='') {
                return Tool::h5(PAGE_ERR);
              }
              $_SESSION['ticket'] = $ticket;//将ticket保存到session中
              echo Tool::h5('正在跳转会员信息...');
              return Tool::headerUrl('/qr_rec?r='.mt_rand(0,9999).'&ticket='.$ticket.'&phone='.$re[0]->telephone);

            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/hzsb_login_page_qr?r='.mt_rand(0,9999).'&id='.$this->openid);
            }
            return Tool::h5(PAGE_ERR);
          }
        }else{
          // return Tool::h5(PAGE_ERR);
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN_QR);
        }
      }else{
        return Tool::h5(PAGE_ERR);
      }
    }else{
      return Tool::h5(PAGE_ERR);
    }
  }

public function getRecNum()
{
  if (array_key_exists('ticket', $_SESSION) && array_key_exists('telephone', $_SESSION)){
    $phone=Input::get('phone');
    if ($phone==$_SESSION['telephone']) {//相等才能确认是用户自己中心的
      $this->updateOrder();
      return $this->getRecNumByPhone($_SESSION['telephone']);
    }
  }
  return '';
}

public function getSPRecNum()
{     
      $this->updateOrder();
      if (Input::get('type')!='1') {//1=com全体
        return $this->getRecNumBySP(0);
      }else{
        return $this->getRecNumBySP(1);
      }
      
      
}

  /**
  * 还在身边auth登录，通过auth2.0获取openid
  * @return js
  */
  public function hzsb_getOpenid(){
    //以后在这里判断是不是微信浏览器
    $code=Input::get('code');
    if ($code) {
      $re=$this->code2openid($code);
      Log::info($re);
      if($re){
        $jsondecode=json_decode($re,true);
        if (array_key_exists('openid',$jsondecode)) {
          Log::info('openid->'.$jsondecode['openid']);
          $this->openid=$jsondecode['openid'];
          if($this->openid){
            $_SESSION['id'] = $this->openid;//将id保存到session中
            //判断用户是否绑定过账号

            $re=DB::select('select * from users where users.name='."'$this->openid'");
            if ($re[0]->rong_token && $re[0]->password) {
              $_SESSION['rong_token'] = $re[0]->rong_token;//将融云token保存到session中
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              $_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中
              $_SESSION['rong_token_id'] = $re[0]->token_id;//将用户手机号保存到session中
              $signPackage=$this->getSignPackage();

              //记录最后登录时间
              $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);
              DB::update('update users set last_login='."'$ts'".' where id='.$re[0]->id);
              return View::make('wxdemo2')->with('signPackage',$signPackage);
            }else{
              echo Tool::h5('正在跳转登录界面...');
              $_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
              return Tool::headerUrl('/hzsb_login_page?r='.mt_rand(0,9999).'&id='.$this->openid);
            }
            return Tool::h5(PAGE_ERR);
          }
        }else{
          // return Tool::h5(PAGE_ERR);
          echo Tool::h5('页面过期，自动刷新..');
          return Tool::headerUrl(URL_AUTH_LOGIN);
        }
      }else{
        return Tool::h5(PAGE_ERR);
      }
    }else{
      return Tool::h5(PAGE_ERR);
    }
  }

	/**
	* 还在身边auth登录，测试接口
	* @return js
	*/
	public function hzsb_getOpenid3(){
		//以后在这里判断是不是微信浏览器
		$code=Input::get('code');
		if ($code) {
			$re=$this->code2openid($code);
			Log::info($re);
			if($re){
				$jsondecode=json_decode($re,true);
				if (array_key_exists('openid',$jsondecode)) {
					Log::info('openid->'.$jsondecode['openid']);
					$this->openid=$jsondecode['openid'];
					if($this->openid){
  					$_SESSION['id'] = $this->openid;//将id保存到session中
  					//判断用户是否绑定过账号

  					$re=DB::select('select * from users where users.name='."'$this->openid'");
  					if ($re[0]->rong_token && $re[0]->password) {
  						$_SESSION['rong_token'] = $re[0]->rong_token;//将融云token保存到session中
  						$_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
  						$_SESSION['telephone'] = $re[0]->telephone;//将用户手机号保存到session中
  						$_SESSION['rong_token_id'] = $re[0]->token_id;//将用户手机号保存到session中
  						// echo Tool::h5('正在跳转...');
  						$signPackage=$this->getSignPackage();
             return View::make('wxdemo3')->with('signPackage',$signPackage);					
           }else{
            echo Tool::h5('正在跳转登录界面...');
  						$_SESSION['users_id'] = $re[0]->id;//将用户id保存到session中
  						return Tool::headerUrl('/hzsb_login_page3?id='.$this->openid);
  					}
  					return Tool::h5(PAGE_ERR);
  				}
  			}else{
  				return Tool::h5(PAGE_ERR);
  			}
  		}else{
  			return Tool::h5(PAGE_ERR);
  		}
  	}else{
  		return Tool::h5(PAGE_ERR);
  	}
  }

    /**
     * 正式接口
     * @return mixed
     */
    public function wxdemo(){
      if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      } else{
        return RELOG_ERR;
      }
      $signPackage=$this->getSignPackage();
      return View::make('wxdemo2')->with('signPackage',$signPackage);
    }

    /**
     * @return mixed测试接口
     */
    public function wxdemo3(){
     if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
     } else{
      return RELOG_ERR;
    }
    $signPackage=$this->getSignPackage();
    return View::make('wxdemo3')->with('signPackage',$signPackage);
  }

    /**
     * 获取设备id
     * @return mixed
     */
    public function getdevice(){
      if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
        $data='userPhone='.$_SESSION['telephone'];
        Log::info('GETDEVICE_URL'.GETDEVICE_URL.$data);
        $re=Http::http_request(GETDEVICE_URL,$data);
        Log::info('GETDEVICE'.$re);
        return $re;
      } else{
        return RELOG_ERR;
      }
    }

    /**
     * 获取昵称
     * @return mixed
     */
    public function getUserName(){
     if (array_key_exists('telephone', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      $data='userPhone='.$_SESSION['telephone'];
      Log::info('GET_USER_NAME_URL'.GET_USER_NAME_URL.$data);
      $re=Http::http_request(GET_USER_NAME_URL,$data);
      Log::info('GET_USER_NAME'.$re);
      return $re;
    } else{
      return RELOG_ERR;
    }
  }

    /**
     * 获取每日学习数据
     * @return mixed
     */
    public function getDailyData(){
     if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      $data='deviceId='.Input::get('deviceId');
      Log::info('GETDEVICE_URL'.GETDAILYDATA_URL.$data);
      $re=Http::http_request(GETDAILYDATA_URL,$data);
      Log::info('GETDAILYDATA'.$re);
      return $re;
    } else{
      return RELOG_ERR;
    }
  }

    /**
     * 按月获取报表数据
     * @return mixed
     */
    public function getdeviceData(){
     if (array_key_exists('id', $_SESSION) && array_key_exists('rong_token', $_SESSION)){
      $DeviceId=Input::get('deviceId');
      $Time=Input::get('time');
      $year='';
      $month='';
      if ($Time=='本月') {
       $year=date('Y',$_SERVER['REQUEST_TIME']);
       $month=date('m',$_SERVER['REQUEST_TIME'])+0;
     }else{
       $arr=explode('-', $Time); 
       if (count($arr)>1) {
         $year=$arr[0];
         $month=$arr[1]+0;
       }
     }
     $data='deviceId='.$DeviceId.'&year='.$year.'&month='.$month;
     Log::info('GETDEVICE_URL'.GETMONTHLYDATA_URL.$data);
     $re=Http::http_request(GETMONTHLYDATA_URL,$data);
     Log::info('GETDEVICE'.$re);
     return $re;
   } else{
    return RELOG_ERR;
  }
}


    /**
     * 下载音频并返回路径，然后由web端发给app
     * @return string url
     * author hgx
     */
    public function downloadVoice(){
    	$media_id=Input::get('media_id');
    	$access_token=$this->getAccessToken(self::$appId,self::$secret);
    	$dir='upload/wechat/voice/';
    	$minddleName=str_replace(' ','',microtime());
    	$fileName='.amr';
    	$re=MyWechat::downloadWeixinFile($access_token,$media_id,$dir.$minddleName,$fileName);

    	if($re){
    		$amrName=$dir.$minddleName.$fileName;
    		$mp3Name=$dir.$minddleName.'.mp3';
    		exec("ffmpeg -i $amrName $mp3Name");
    		return 'http://lamp.snewfly.com/upload/wechat/voice/'.$minddleName.'.mp3';
    	}
    	return '';
    }

	/**
	* 判断用户是否登录
	* @return boolean 登录返回true
	*/
	private function checkLogin(){
		if (array_key_exists('id',$_SESSION) ) {
			$this->openid=$_SESSION['id'];
			$this->setUID();
			return true;
		}else{
			return false;
		}
	}


	/**
	* 通过openid获取id，含缓存
	* @return boolean
	*/
	private  function setUID(){
		$this->uid=$this->mem->get($this->openid.'_uid');
		if (!$this->uid) {
			$idObjArr=DB::select("select id from users where name='$this->openid'");
			if ($idObjArr) {
				$this->uid=$idObjArr[0]->id;
				$this->mem->set($this->openid.'_uid', $this->uid, 0, UID_TIME);
				Log::info('mem->set'.$this->uid);
			}
		}
	}

	/**
	* 通过name获取id，含缓存
	* @return boolean
	*/
	private  function getIdByname($name){
		$id=$this->mem->get($name.'_uid');
		if (!$id) {
			$idObjArr=DB::select("select id from users where name='$name'");
			if ($idObjArr) {
				$id=$idObjArr[0]->id;
				$this->mem->set($name.'_uid', $id, 0, UID_TIME);
				Log::info('mem->set'.$id);
			}
		}
		return $id;
	}


	/**
	 * 通过id获取手机号(name),对手机号进行缓存
	 * @return phone
	 */
	protected function getPhoneByid($id)
	{
		if ($this->mem->get($id.'phone')) {
			return $this->mem->get($id.'phone');
		}else{
			$idArr=DB::select('select name from users where id='.$id);
			$this->mem->set($id.'phone',$idArr[0]->name,0,MEM_TIME);
			return $idArr[0]->name;
		}

	}

	/**
	 * 通过id获取手机号(name),对手机号进行缓存
	 * @return phone
	 */
	protected function getGroupByName($openid)
	{
		if ($this->mem->get($openid.'group_id')) {
			return $this->mem->get($openid.'group_id');
		}else{
			$idArr=DB::select('select group_id from users where name='."'$openid'");
			$this->mem->set($openid.'group_id',$idArr[0]->name,0,MEM_TIME);
			return $idArr[0]->group_id;
		}

	}



}
?>