<?php
namespace App\Http\Controllers;

use Log;
use Input;
use DB;
use Memcache;
use View;

require_once('lib/Card.php');
use Card;

set_time_limit(0);



/**
 * Class CardRouteController 负责处理学生卡相关接口
 * @package App\Http\Controllers
 * anthor hgx
 */
class CardRouteController extends ZhihuiWechatBaseController{

    /**
     * @var Memcache
     */
    private $openid,$mem,$uid;

    public function __construct(){
    	if(!isset($_SESSION)){  
    		session_start();   //开启session
      }
      // $this->mem = new Memcache;
      // $this->mem->connect('localhost', 11211) or die ('Could not connect');
    }


    /**
    * 获取微信用户信息
    * @return json
    */
    public function wechatinfo(){
      return $this->getUserInfo($_SESSION['id']);
    }

    /**
    * 获取用户绑定设备
    * @return json
    */
    public function queryDevice(){
     $re=Card::queryDevice(['userid'=>$_SESSION['card_userId']]);
     Log::info('queryDevice'.$re.json_encode(['userid'=>$_SESSION['card_userId']]));
     return $re;
   }

    /**
    * 获取设备绑定用户手机
    * @return json
    */
    public function getBindPhoneByImei(){
      $imei=Input::get('imei');
      $re=Card::getDeviceBindPhone(['userid'=>$_SESSION['card_userId'],'device_id'=>$imei]);
      Log::info('getBindPhoneByImei'.$re.json_encode(['userid'=>$_SESSION['card_userId'],'device_id'=>$imei]));
      return $re;
    }

    /**
    * 获取实时定位
    * @return json
    */
    public function getNewLocation(){
      $device_id=Input::get('device_id');
      $re=Card::cardAction(['userid'=>$_SESSION['card_userId'],'device_id'=>$device_id,'action'=>'location']);
      Log::info('getNewLocation'.$re.json_encode(['userid'=>$_SESSION['card_userId'],'device_id'=>$device_id,'action'=>'location']));
      return $re;
    }

    /**
    * 远程关机
    * @return json
    */
    public function shutdown(){
      $device_id=Input::get('device_id');
      $re=Card::cardAction(['userid'=>$_SESSION['card_userId'],'device_id'=>$device_id,'action'=>'shutdown']);
      Log::info('shutdown'.$re.json_encode(['userid'=>$_SESSION['card_userId'],'device_id'=>$device_id,'action'=>'shutdown']));
      return $re;
    }

    /**
    * 学生卡绑定、编辑设备
    * '&imei='+imei+'&nick='+nick+'&pwd='+pwd+'&sex='+sex+'&pic='+pic+'&type='+type,
    * @return json
    */
    public function submitEditDevice(){
      $imei=Input::get('imei');
      $nick=Input::get('nick');
      $pwd=Input::get('pwd');
      $sex=Input::get('sex');
      $pic=Input::get('pic');
      $type=Input::get('type');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'password'=>$pwd,'picture'=>$pic,'nick'=>$nick,'sex'=>$sex];
      if ($type=='2') {//编辑
        $re=Card::editDevice($arr);
        Log::info('editDevice');
      }else{//添加
        $re=Card::addDevice($arr);
        Log::info('addDevice');
      }
      Log::info('submitEditDevice'.$re.json_encode($arr));
      return $re;
    }

    /**
    * 学生卡绑定编辑设备
    * 'device_id userid
    * @return json
    */
    public function deleteDevice()
    {
      $imei=Input::get('imei');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei];
      $re=Card::deleteDevice($arr);
      Log::info('deleteDevice'.$re.json_encode($arr));
      return $re;
    }

    /**
    * 学生卡设备管理
    * 'device_id userid fields
    * @return json
    */
    public function submitManageSettings()
    {
      $quick_dial=Input::get('quick_dial');
      $volume=Input::get('volume');
      $work_mode=Input::get('work_mode');
      $imei=Input::get('imei');
      $arr=[];
      if ($work_mode!='') 
        $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'fields'=>json_encode(['quick_dial'=>$quick_dial,'volume'=>$volume,'work_model'=>$work_mode])];
      else
        $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'fields'=>json_encode(['quick_dial'=>$quick_dial,'volume'=>$volume])];

      $re=Card::infoSet($arr);
      Log::info('submitManageSettings'.$re.json_encode($arr));
      return $re;
    }

    /**
    * 学生卡校園管理管理
    * 'device_id userid fields
    * @return json
    */
    public function submitSchoolManage()
    {
      $limit_time=Input::get('limit_time');
      $toggle=Input::get('toggle');
      $device_id=Input::get('device_id');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$device_id,'fields'=>json_encode(['limit_time'=>$limit_time,'flag_limit_time'=>$toggle])];
      $re=Card::infoSet($arr);
      Log::info('submitSchoolManage'.$re.json_encode($arr));
      return $re;
    }

    /**
    * 到离校通知设置
    * 'device_id userid flag
    * @return json
    */
    public function submitToggleAttendance()
    {
      $flag=Input::get('flag');
      $imei=Input::get('imei');
      $arr=['userid'=>$_SESSION['card_userId'],'device_id'=>$imei,'flag'=>$flag];
      $re=Card::attendanceNoticeSet($arr);
      Log::info('submitToggleAttendance'.$re.json_encode($arr));
      return $re;
    }

    /**
    * 获取消息中心
    * @return json
    */
    public function card_getMsgCenter(){
      $endTs=$_SERVER['REQUEST_TIME'];
      $beginTs=$_SERVER['REQUEST_TIME']-86400*7;
      $end_date=date('Y-m-d',$endTs);
      $begin_date=date('Y-m-d',$beginTs);
      $arr=['userid'=>$_SESSION['card_userId'],'action'=>'!voice','begin_date'=>$begin_date,'end_date'=>$end_date];
      $re=Card::msgCenter($arr);
      Log::info('card_getMsgCenter'.$re.json_encode($arr));
      return $re;
    }


    function showCardCenterPage(){
      $signPackage=$this->getSignPackage();
      return View::make('card.card_cardcenter')->with('signPackage',$signPackage);
    }

  }
  ?>