<?php
namespace App\Http\Controllers;

use Log;
use Input;
require_once('lib/Tool.php');
use Tool;

use App\Jobs\SendUnreadPush;
use Illuminate\Support\Facades\Redis as Redis;

// define('KEY_HZSB_USERID', 'KEY_HZSB_USERID');

set_time_limit(0);

/**
 * Class LampPushController 伴学机与主服务器消息推送接收入口
 * @package App\Http\Controllers
 * anthor hgx
 */
class LampPushController extends Controller{
/*
    public function __construct(){
    	if(!isset($_SESSION)){
    		session_start();   //开启session
      }
    }*/


    /**
    * 学生卡那边推送消息接口
    * @return json
    */
    public function lamp_msgcenter(){
      $data=file_get_contents('php://input');
      Log::info($data);
      $msgType=Input::get('msgType');
      switch ($msgType) {
        case 'voice':
        $this->recAudio();
        break;
        case 'pic':
        $this->picPush();
        break;
        default:
        break;
      }

      return Tool::getJson('1');
    }


    private function recAudio()
    {
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msgId=Input::get('msgId');
      $url=Input::get('url');

      $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'bxj','msgType'=>'voice','msgId'=>$msgId,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$user_id];
      $this->deliverJob($arr);
    }

    private function picPush()
    {
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msgId=Input::get('msgId');
      $url=Input::get('url');

      $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'bxj','msgType'=>'pic','msgId'=>$msgId,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$user_id];
      $this->deliverJob($arr);
    }

    function deliverJob($arr,$delay=30){
      Log::info(json_encode($arr));
      $redis=$this->getRedis();
      $redis->SETEX($arr['deviceType'].$arr['msgId'],3600,1);
      $job=(new SendUnreadPush($arr))->delay($delay);
      $this->dispatch($job);
         //TODO 以後可以創建多幾個隊列或者缩短等待时间解決並發
    }

    function getRedis(){
      return Redis::connection('default');
    }

  }
  ?>