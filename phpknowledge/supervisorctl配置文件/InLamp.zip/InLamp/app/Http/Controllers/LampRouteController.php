<?php
namespace App\Http\Controllers;

use Log;
use Input;
use DB;
use View;

require_once('lib/Lampv2.php');
use Lampv2;


set_time_limit(0);


/**
 * Class LampRouteController 伴学机2.0接口相关
 * @package App\Http\Controllers
 * anthor hgx
 */
class LampRouteController extends ZhihuiWechatBaseController{

    //智慧教育
    public function __construct(){
    	if(!isset($_SESSION)){  
    		session_start();   //开启session
      }
    }


    /**
     * 正式接口
     * @return mixed
     */
    public function wxdemo(){
      $signPackage=$this->getSignPackage();
      return View::make('lamp.wxdemo_zhihui')->with('signPackage',$signPackage);
    }


    /**
     * 获取设备
     * @return mixed
     */
    public function getdevice_zhihui(){
      $re=Lampv2::getBindList(['userId'=>$_SESSION['user_id']]);
      Log::info('getdevice_zhihui'.$re);
      return $re;
    }


    /**
     * 获取每日学习数据
     * @return mixed
     */
    public function getDailyData_zhihui(){
      $deviceId=Input::get('deviceId');
      $start=date('Y-m-d',$_SERVER['REQUEST_TIME']);
      $arr=['deviceId'=>$deviceId,'start'=>$start,'end'=>$start];
      $re=Lampv2::queryStudyData($arr);
      Log::info('GETDAILYDATA'.$re.json_encode($arr));
      return $re;

    }

    /**
     * 绑定伴学机
     */
    public function bindDevice(){
      $deviceId=Input::get('deviceId');
      $childNick=Input::get('childNick');
      $parentCall=Input::get('parentCall');
      $keySelect=Input::get('keySelect');
      $arr=['deviceId'=>$deviceId,'userId'=>$_SESSION['user_id'],'bxjName'=>$childNick,'caller'=>$parentCall,'btn'=>$keySelect];
      $re=Lampv2::bindDevice($arr);
      Log::info('bindDevice'.$re.json_encode($arr));
      return $re;
    }

    /**
     * 编辑伴学机
     */
    public function editDevice(){
      $deviceId=Input::get('deviceId');
      $childNick=Input::get('childNick');
      $parentCall=Input::get('parentCall');
      $keySelect=Input::get('keySelect');
      $realName=Input::get('realName');
      $arr=['deviceId'=>$deviceId,'realName'=>$realName,'userId'=>$_SESSION['user_id'],'bxjName'=>$childNick,'caller'=>$parentCall,'btn'=>$keySelect];
      $re=Lampv2::editDevice($arr);
      Log::info('editDevice'.$re.json_encode($arr));
      return $re;
    }

    /**
     * 解绑伴学机
     */
    public function unbindDevice(){
      $deviceId=Input::get('deviceId');
      $arr=['deviceId'=>$deviceId,'userId'=>$_SESSION['user_id']];
      $re=Lampv2::unbindDevice($arr);
      Log::info('unbindDevice'.$re.json_encode($arr));
      return $re;
    }

    /**
     * 按月获取报表数据
     * @return mixed
     */
    public function getdeviceData(){
      $deviceId=Input::get('deviceId');
      $Time=Input::get('time');
      if ($Time=='本月') {
       $Time=date('Y-m',$_SERVER['REQUEST_TIME']);
     }
     $arr=['deviceId'=>$deviceId,'start'=>$Time,'end'=>$Time];
     $re=Lampv2::queryStudyData($arr);
     Log::info('getdeviceData'.$re.json_encode($arr));
     return $re;
   }

 }
 ?>