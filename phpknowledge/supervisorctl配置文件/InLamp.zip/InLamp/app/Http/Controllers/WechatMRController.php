<?php
$logFile ='wechat_mr.log';
set_time_limit(0);
require_once "lib/WechatDownloader.php";
require_once('lib/Ucpaas.class.php');
require_once('lib/RongYun.php');
Log::useDailyFiles(storage_path().'/logs/'.$logFile);

class WechatMRController extends WechatBaseController{
	const DEF_REPLY="为了更好的为您服务，请先进行认证。";
	const DEF_CANCELL=",如需取消当前操作请回复'9'";
	const YG_REGISTER_SUCCE="么么哒，资料记录完毕，义工注册成功，点下面菜单的/:heart后才可以接收到问题哦";
	const DESCRIBE="思路飞扬公众号是专为视障人士服务的：\n在工作时间内可以发送图片或拍照提问给我们，我们会尽快回复您图片是什么的。\n 我们将会对您的个人资料进行保密，更多功能，请回复\n【6】修改手机号\n【7】验证手机号\n【9】取消当前操作";
	
	private $openid,$keyword,$mem,$mediaId,$fromUsername,$recognition;
	public $msg_id;

	public function  __construct($openid,$keyword,$mediaId)
	{
		$this->mem = new Memcache;
		$this->mem->connect('localhost', 11211) or die ("Could not connect");
		$this->openid=$openid;
		$this->keyword=$keyword;
		$this->mediaId=$mediaId;
		$this->fromUsername=substr($openid,3,strlen($openid)-3);
	}
	public function  __destruct()
	{
		$this->mem->close();
	}
	
	public function mr_check_score(){
		$mrScoreArr=DB::select("select info.users_id,info.update_time,info.today_score,info.score from info inner join users where users.name='$this->openid' and users.id=info.users_id");
		if(empty($mrScoreArr)){
			$msg='只有认证了的视障者才可以查询哦';
		}else{
			$users_id=$mrScoreArr[0]->users_id;
			$update_time=$mrScoreArr[0]->update_time;
			//回答总次数和总积分
			$score=$mrScoreArr[0]->score;
			// $score=$mrScoreArr[0]->score;
			$day=substr($update_time,0,10);
			$today=date("Y-m-d",time());
			$today_time=$today.' 0:0:0';
			if($day!=$today){
				DB::update("update info inner join users set info.today_score = 0 where users.name='$this->openid' and users.id=info.users_id");
				// $ygScoreArr=DB::select("select yg.update_time,yg.today_answer_num,yg.answer_num,yg.score,yg.today_score from yg inner join users where users.name='$this->openid' and users.id=yg.users_id");
				// $today_answer_num=0;
				$today_score=0;
				$today_question=0;
			}else{
				
				// foreach (get_object_vars($question_numArr[0]) as $key => $value) {
				// 	Log::info("key-$key-value-$value-- ");
				// }
				$today_score=$mrScoreArr[0]->today_score;
			}
			$question_numArr=DB::select("select count(*) from messages where pic !='' and users_id=$users_id");
			$today_questionArr=DB::select("select count(*) from messages where pic !='' and users_id=$users_id and update_time>'$today_time'");
			$question_num=get_object_vars($question_numArr[0])['count(*)'];
			$today_question=get_object_vars($today_questionArr[0])['count(*)'];
			// $msg="您的总积分为：{$score}，其中今日获得积分为：{$today_score}\n";
			 $msg="您的总积分为：{$score}，\n其中今日获得积分为：{$today_score}\n您一共提问了{$question_num}个问题，\n其中今日提问个数为：{$today_question}。";
		}
		return $msg;
	}
	
}
?>