<?php
$logFile = 'File.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);
include_once 'RongYun.php';
class FileController extends BaseController{

	public function __construct()
	{
		RongYun::ini('cpj2xarljqsvn','IBpnrGvU8kb4S','json','https://api.cn.rong.io');
	}
	/**
	 * 
	 * 接收上传的录音文件
	 * @return string
	 */
	public function audio()
	{	
		// 检查签名
		if (!$this->signatureCheck()) {
			Log::info('method:audio messages:has no authority');

			//返回无权限 
			return $this->get_json('0','无权限');
		}
		else{
			// 获操作指令
			$cmd = Input::get('CMD');

			// 获取设备IMEI
			$imei = Input::get('IMEI');

			// 获取上传的文件
			$file = $_FILES['upload'];

			$from = Input::get('from');

			$to = Input::get('to');

			$extra = Input::get('Extra');

			log::info('from: '.$from);

			Log::info('to: '.$to);

			Log::info('extra: '.$extra);

			Log::info($file);

			// 从文件名获取上传时间
			$uploadTime = (int)substr($file['name'], 0, 10);
			
			// 获取上传文件类型
			$type = $file['type'];

			// 根据文件类型获取文件名
			$destination = $this->getDestination($type);

			// 将文件移动到新的文件路径
			move_uploaded_file($file['tmp_name'], $destination);
			
			// 获取用户ID
			$id = $this->getUserId($imei);
			
			// 获取消息ID
			$messagesId = DB::table('messages')
				->where('upload_time', $uploadTime)
				->where('state', 381)
				->where('users_id', $id)
				->pluck('id');
			// Log::info('From: '.)
			
			// 跟新messages表
			DB::table('messages')
				->where('id', $messagesId)
				->update(array('state' => 382,'audio' => $destination));
			Log::info('audio upload sucess');
			return $this->get_json(1,'成功');

		}
	}

	public function image()
	{
		// 检查签名
		if (!$this->signatureCheck()) {
			Log::info('method:audio messages:has no authority');

			//返回无权限 
			return $this->get_json('0','无权限');
		}
		else{
			// 获操作指令
			$cmd = Input::get('CMD');

			// 获取设备IMEI
			$imei = Input::get('IMEI');

			// Log::info($_FILES);
			$from = Input::get('from');

			$to = Input::get('to');

			$extra = Input::get('Extra');

			// 获取上传的文件
			$file = $_FILES['upload'];

			log::info('from: '.$from);

			Log::info('to: '.$to);

			Log::info('extra: '.$extra);

			Log::info($file);

			// 从文件名获取上传时间
			$uploadTime = (int)substr($file['name'], 0, 10);
			
			// 获取上传文件类型
			$type = $file['type'];
			
			// 根据文件类型获取文件名
			$destination = $this->getDestination($type);

			Log::info('destination: '.$destination);

			// 将文件移动到新的文件路径
			move_uploaded_file($file['tmp_name'], $destination);
			
			// 获取用户ID
			$id = $this->getUserId($imei);

			// 向数据库插入消息
			DB::table('messages')->insert(
				array('pic' => $destination, 'state' => 381,
					'upload_time' => $uploadTime, 'users_id' => $id)
			);
			Log::info('messages upload sucess');
			return $this->get_json('1','成功');
		}
	}

	public function getToken()
	{
		if (!$this->signatureCheck()) {
			Log::info('method:audio messages:has no authority');

			//返回无权限 
			return $this->get_json('0','无权限');
		}else{
			// 获取设备IMEI
			$imei = Input::get('IMEI');

			// 获取用户ID
			$id = $this->getUserId($imei);

			$name = 'test';

			$token = DB::table('users')->where('id', $id)->pluck('rong_token');
			
			if ($token == '') {
				// 从融云获取Token
				$ret = json_decode(RongYun::getToken($id,$name,'test'));
				// Log::info('ret '.$ret);
				$status = $ret->code;
				Log::info($status);
				if ($status	!=	200)
					return false;
				$token = $ret->token;
				if ($token) {
					DB::table('users')
						->where('id',$id)
						->update(array('rong_token' => $token));
				return $this->get_json(1,'成功',$token);
				}
				else{
					return $this->get_json(2,'失败');
				}
			}
			else{
				return $this->get_json(1,'成功',$token);
			}	
		}
	}

	public function send()
	{
		$url = '/upload/audio/15-01-17/1418567077.mp3';
		$arr = array('content' => $url,'extra' => 'audio' );
		// $content = {"content":base64_encode($content), "duration":10,"extra":"helloExtra"};
		RongYun::messagePublish(241, array(240),'RC:TxtMsg',json_encode($arr));
		return 'sucess';
	}

	private function getUserId($imei)
	{
		// 获取用户的ID
		$id = DB::table('users')->where('name',$imei)->pluck('id');

		// 如果不存在用户则插入用户
		if (!$id) {
			$id = DB::table('users')->insertGetId(
				array('name' => $imei, 'group_id' => 5)
			);
		}
		return $id;
	}
}