<?php
namespace App\Http\Controllers;
use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
use DB;
require_once('lib/Tool.php');
require_once('lib/RongYun.php');
use Tool;
use RongYun;

use App\Jobs\SendUnreadPush;
use Illuminate\Support\Facades\Redis as Redis;

define('KEY_REDIS_CARD_TOKEN_ID', 'CTI');//card_token_id
define('KEY_REDIS_EXPIRE', 7200);

set_time_limit(0);

/**
 * Class CardController 学生卡消息推送接收入口
 * @package App\Http\Controllers
 * anthor hgx
 */
class CardController extends ZhihuiWechatBaseController{

    private static $EXTRA_REC_AUDIO_V1='0101001';
    private static $EXTRA_REC_READ_AUDIO_V1='0101002';
    private static $EXTRA_REC_FEEDBACK_V1='0101003';
    private static $EXTRA_REC_SOS_V1='0101004';
    private static $EXTRA_REC_LBS_V1='0101005';

    const DEFAULT_SOS_TIPS=' 紧急求助消息';

    /**
    * 学生卡那边推送消息接口
    * @return json
    */
    public function card_msgcenter(){
      // if ($this->signatureCheck()) {

      $data=file_get_contents('php://input');
      Log::info($data);

      $msgType=Input::get('msgType');
      switch ($msgType) {
        case 'voice':
        $this->recAudio();
        break;
        case 'read':
        $this->readPush();
        break;
        case 'feedback':
        $this->feedbackPush();
        break;
        case 'sos':
        $this->sosPush();
        break;
        case 'lbs':
        $this->lbsPush();
        break;

        default:
        break;
      }

      return Tool::getJson('1');
      // }
      // return Tool::getJson('0','无权限');
    }

    private function sosPush(){
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msg_id=Input::get('msgId');

      $lat=Input::get('lat');
      $lng=Input::get('lng');
      $address=Input::get('address');
      $type=Input::get('type','LBS');
      
      $userIdArr=explode(',',$user_id);
      $RongTokenIdObjArr=$this->getRongTokenIdArr($userIdArr);
      $count=count($userIdArr);

      $userTokenIdArr=[];
      
      for ($i=0; $i < $count; $i++) {
         $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'xsk','msgType'=>'sos','lat'=>$lat,'address'=>$address,'lng'=>$lng,'msgId'=>$userIdArr[$i].$msg_id,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$userIdArr[$i]];
         $unreadPush=new SendUnreadPush($arr);
         $unreadPush->pushTemplate(self::DEFAULT_SOS_TIPS,$address,'sos');
        // $this->deliverJob($arr,0);

      }

      $countRY=count($RongTokenIdObjArr);//修正DB融云id数量少于用户id时候漏发bug
      if ($countRY){
        for ($i=0; $i <$countRY ; $i++) {
          array_push($userTokenIdArr, $RongTokenIdObjArr[$i]->card_token_id);
        }

      $rccontent=$this->createSOSPushContent($lat,$lng,$address,$msg_id,$fromUser,$fromUserNick,$type);
      $this->rongYunText($fromUserNick,$userTokenIdArr,$rccontent,[]);
      }
    }

    private function rongYunText($fromUserId,$toUserId = array(),$content,$redisKey= array())
    {
      $re=RongYun::messagePublish($fromUserId,$toUserId,'RC:TxtMsg',$content);
      if (!strpos($re,'"code":200')){//发送失败
        $re=RongYun::messagePublish($fromUserId,$toUserId,'RC:TxtMsg',$content);
        if (!strpos($re,'"code":200')){//发送失败
          $redis=$this->getRedis();
          foreach ($redisKey as $value) {
            $redis->DEL($value);
          }
          
          Log::info('Fail->'.$fromUserId.$re);
      }
      }
    }

    private function feedbackPush(){
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msg_id=Input::get('msgId');

      $name=Input::get('msgName');
      $content=Input::get('msgContent');

      $userIdArr=explode(',',$user_id);
      $RongTokenIdObjArr=$this->getRongTokenIdArr($userIdArr);
      $count=count($RongTokenIdObjArr);
      $countUId=count($userIdArr);

      $userTokenIdArr=[];
      $userRedisKeyArr=[];
      //修正融云id比用户id少导致丢失推送的bug
      for ($i=0; $i <$countUId ; $i++) {
        $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'xsk','msgType'=>'feedback','msgName'=>$name,'msgContent'=>$content,'msgId'=>$userIdArr[$i].$msg_id,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$userIdArr[$i]];
        $this->deliverJob($arr);
      }

      for ($i=0; $i < $count; $i++) {
        array_push($userTokenIdArr, $RongTokenIdObjArr[$i]->card_token_id);
        array_push($userRedisKeyArr,'xsk'.$arr['msgId']);
      }

      if (count($userTokenIdArr)){
      $rccontent=$this->createFeedbackPushContent($name,$content,$msg_id);
      $this->rongYunText($fromUserNick,$userTokenIdArr,$rccontent,$userRedisKeyArr);
      }
    }

    private function getRongTokenIdArr($userIdArr)
    {
      // SELECT name FROM users WHERE user_id='arjxwcc5k1FarddeVSIR8L'||user_id='123'
      $count=count($userIdArr);
      $str='SELECT card_token_id FROM users WHERE ';
      for ($i=0; $i <$count ; $i++) { 
        $str.="user_id='{$userIdArr[$i]}'||";
      }

      $sql=substr($str,0,strlen($str)-2);
      return DB::select($sql);
    }


    private function lbsPush(){
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msg_id=Input::get('msgId');

      $lat=Input::get('lat');
      $lng=Input::get('lng');
      $address=Input::get('address');
      $type=Input::get('type','LBS');
      
      $toUserTokenId=$this->getRongTokenIdByUserId($user_id);
      $rccontent=$this->createLbsPushContent($lat,$lng,$address,$msg_id,$fromUser,$fromUserNick,$type);

      $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'xsk','msgType'=>'lbs','lat'=>$lat,'lng'=>$lng,'address'=>$address,'msgId'=>$msg_id,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$user_id];
      $this->deliverJob($arr);

      $this->rongYunText($fromUserNick,[$toUserTokenId],$rccontent,[$arr['deviceType'].$arr['msgId']]);
    }


    private function readPush(){
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $readMsgId=Input::get('readMsgId');
      $toUserTokenId=$this->getRongTokenIdByUserId($user_id);
      $content=$this->createReadPushContent($readMsgId);
      $RE=RongYun::messagePublish($fromUserNick,[$toUserTokenId],'RC:TxtMsg',$content);
      Log::info("RongYun::messagePublish($fromUserNick,[$toUserTokenId],'RC:TxtMsg',$content) ".$RE);
    }

    private function recAudio()
    {
      $user_id=Input::get('toUser');
      $fromUserNick=Input::get('fromUserNick');
      $fromUser=Input::get('fromUser');
      $msg_id=Input::get('msgId');
      $url=Input::get('url');

      $toUserTokenId=$this->getRongTokenIdByUserId($user_id);
      if ($toUserTokenId) {
        $arr=['ts'=>$_SERVER['REQUEST_TIME'],'deviceType'=>'xsk','msgType'=>'voice','msgId'=>$msg_id,'fNick'=>$fromUserNick,'fromUser'=>$fromUser,'toUser'=>$user_id];
        $this->deliverJob($arr);

        $content=$this->createAudioContent($fromUser,$fromUserNick,$msg_id,$url);
        $this->rongYunText($fromUserNick,[$toUserTokenId],$content,[$arr['deviceType'].$arr['msgId']]);
      }
    }

    function deliverJob($arr,$delay=30){
      $redis=$this->getRedis();
      $redis->SETEX($arr['deviceType'].$arr['msgId'],3600,1);
      $job=(new SendUnreadPush($arr))->delay($delay);
      $this->dispatch($job);
         //TODO 以後可以創建多幾個隊列或者缩短等待时间解決並發
    }

    function getRedis(){
      return Redis::connection('default');
    }

    function createAudioContent($fromUser,$fromUserNick,$msg_id,$url){
      $content=json_encode(['user_id'=>$fromUser,'nick'=>$fromUserNick,'msg_id'=>$msg_id,'url'=>$url]);
      $extra=self::$EXTRA_REC_AUDIO_V1;
      return RongYun::createMsg($content,$extra);
    }

    function createReadPushContent($read_id){
      $content=json_encode(['read_id'=>$read_id]);
      $extra=self::$EXTRA_REC_READ_AUDIO_V1;
      return RongYun::createMsg($content,$extra);
    }

    function createFeedbackPushContent($name,$content,$msg_id){
      $content=json_encode(['name'=>$name,'content'=>$content,'msg_id'=>$msg_id]);
      $extra=self::$EXTRA_REC_FEEDBACK_V1;
      return RongYun::createMsg($content,$extra);
    }

    function createSOSPushContent($lat,$lng,$address,$msg_id,$fromUser,$fromUserNick,$type){
      $content=json_encode(['lat'=>$lat,'lng'=>$lng,'address'=>$address,'msg_id'=>$msg_id,'user_id'=>$fromUser,'nick'=>$fromUserNick,'type'=>$type]);
      $extra=self::$EXTRA_REC_SOS_V1;
      return RongYun::createMsg($content,$extra);
    }

    function createLbsPushContent($lat,$lng,$address,$msg_id,$fromUser,$fromUserNick,$type){
      $content=json_encode(['lat'=>$lat,'lng'=>$lng,'address'=>$address,'msg_id'=>$msg_id,'user_id'=>$fromUser,'nick'=>$fromUserNick,'type'=>$type]);
      $extra=self::$EXTRA_REC_LBS_V1;
      return RongYun::createMsg($content,$extra);
    }

    function getRongTokenIdByUserId($user_id){
      $redis=$this->getRedis();
      $token_id=$redis->get($user_id.KEY_REDIS_CARD_TOKEN_ID);
      if ($token_id) {
        return $token_id;
      }
      $re=DB::select("select card_token_id from users where user_id='$user_id'");
      if ($re) {
        $redis->SETEX($user_id.KEY_REDIS_CARD_TOKEN_ID,KEY_REDIS_EXPIRE,$re[0]->card_token_id);
        return $re[0]->card_token_id;
      }
      return '';
    }

    /*
    * 已读（所有消息已读通用接口）
    */
    function delRecAudio(){
      $msgId=Input::get('msgId');
      $type=Input::get('type');
      $redis=$this->getRedis();
      $redis->DEL($type.$msgId);
      Log::info('delRecAudio'.$type.$msgId);
      return '{}';
    }



  }
  ?>