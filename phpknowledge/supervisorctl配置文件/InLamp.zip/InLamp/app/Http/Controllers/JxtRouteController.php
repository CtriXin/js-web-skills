<?php
namespace App\Http\Controllers;

use Log;
use Input;
use DB;
use View;

require_once('lib/Jxt.php');
use Jxt;

set_time_limit(0);

/**
 * Class 负责处理家校通相关接口
 * @package App\Http\Controllers
 * anthor hgx
 */
class JxtRouteController extends ZhihuiWechatBaseController{


  public function __construct(){
   if(!isset($_SESSION)) session_start();   //开启session
      
    }


    /**
    * 获取用户绑定设备
    * @return json
    */
    public function queryDevice(){
     $re=Jxt::queryDevice(['userid'=>$_SESSION['card_userId']]);
     Log::info('queryDevice'.$re.json_encode(['userid'=>$_SESSION['card_userId']]));
     return $re;
   }

    /**
    * 获取联系方式
    * @return json
    */
    public function queryContact(){
      $deviceid=Input::get('deviceid');
      $paranArr=['userid'=>$_SESSION['card_userId'],'deviceid'=>$deviceid];
      $re=Jxt::queryContact($paranArr);
      Log::info('queryContact'.$re.json_encode($paranArr));

      return $re;
    }

    /**
    * 查询学生拥有的科目
    * @return json
    */
    public function querySubject(){
      $deviceid=Input::get('deviceid');
      $paranArr=['userid'=>$_SESSION['card_userId'],'deviceid'=>$deviceid];
      $re=Jxt::querySubject($paranArr);
      Log::info('querySubject'.$re.json_encode($paranArr));
      return $re;
    }

    /**
    * 查询通知
    * @return json
    */
    public function queryNotice(){
      $deviceid=Input::get('deviceid');
      $paranArr=['userid'=>$_SESSION['card_userId'],'deviceid'=>$deviceid];
      $re=Jxt::queryNotice($paranArr);
      Log::info('queryNotice'.$re.json_encode($paranArr));
      return $re;
    }

    /**
    * 查询各个科目成绩
    * @return json
    */
    public function queryAllScore(){
      $deviceid=Input::get('deviceid');
      $paranArr=['userid'=>$_SESSION['card_userId'],'deviceid'=>$deviceid];
      $re=Jxt::queryAllScore($paranArr);
      Log::info('queryAllScore'.$re.json_encode($paranArr));
      return $re;
    }

    /**
    * 查询科目作业
    * @return json
    */
    public function queryHomework(){
      $deviceid=Input::get('deviceid');
      $subject=Input::get('subject');
      $paranArr=['userid'=>$_SESSION['card_userId'],'deviceid'=>$deviceid,'subject'=>$subject];
      $re=Jxt::queryHomework($paranArr);
      Log::info('queryHomework'.$re.json_encode($paranArr));
      return $re;
    }

    function showCenterPage(){
      $signPackage=$this->getSignPackage();
      return View::make('jxt.center')->with('signPackage',$signPackage);
    }

  }
  ?>