<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Log;
use Input;
use DB;
use Illuminate\Support\Facades\Redis as Redis;
$logFile ='wechattoken.log';
set_time_limit(0);
Log::useDailyFiles(storage_path().'/logs/'.$logFile);

//只有主服务器(242)才会运行
class TokenController extends Controller{

	const exprie_time=60;
/*	const APP_ID='wx2683432074892f00';
	const APP_KEY='9147009bbad321887c93b17cc1989c00';*/
	const APP_ID='wx2683432074892f86';
	const APP_KEY='9147009bbad321887c93b17cc1989c7e';
	private $redis;

  public function __construct()
  {
    $this->redis = Redis::connection('default');

  }
	public function getZHJYAccessToken()
	{
		$access_token=$this->redis->get('redis_zhjy_a_t');
		if ($access_token) {//解决并发问题
			Log::info($_SERVER['REMOTE_ADDR'].'redis_zhjy_a_t'.$access_token);
		return $access_token;
		}
		$access_token=$this->getAccessToken();
		if ($access_token) {
			$this->redis->SETEX('redis_zhjy_a_t',self::exprie_time,$access_token);
		}
		
		Log::info($_SERVER['REMOTE_ADDR'].'getZHJYAccessToken'.$access_token);
		return $access_token;
	}

	public function getZHJYJsApiTicket()
	{
		$access_token=Input::get('token');
		$ticket=$this->redis->get('redis_zhjy_js_t');
		if ($ticket) {//解决并发问题
			Log::info($_SERVER['REMOTE_ADDR'].'redis_zhjy_js_t'.$ticket);
		return $ticket;
		}

		$ticket=$this->getJsApiTicket($access_token);
		if ($ticket) {
			$this->redis->SETEX('redis_zhjy_js_t',self::exprie_time,$ticket);
		}
		Log::info($_SERVER['REMOTE_ADDR'].'getZHJYJsApiTicket'.$ticket);
		return $ticket;
	}

	private function notifyToAllZHJYAccessToken($access_token)
	{
		//所有主从服务器域名
		$hostArr=['http://bxj.snewfly.com','http://bxjtest.snewfly.com'];
		$route='/token/refresh_zhjy_access_token?token='.$access_token;
		$url='';
		$count=count($hostArr);
		for ($i=0; $i <$count; $i++) {
			$url=$hostArr[$i].$route;
			$re=$this->http_request($url);
			Log::info($re.$url);
		}
		
	}

	private function notifyToAllZHJYJsApiTicket($jsApiTicket)
	{
		//所有主从服务器域名
		$hostArr=['http://bxj.snewfly.com','http://bxjtest.snewfly.com'];
		$route='/token/refresh_zhjy_js_ticket?ticket='.$jsApiTicket;
		$url='';
		$count=count($hostArr);
		for ($i=0; $i <$count; $i++) {
			$url=$hostArr[$i].$route;
			$re=$this->http_request($url);
			Log::info($re.$url);
		}
	}

	private function getAccessToken($appid=self::APP_ID ,$appsecret=self::APP_KEY){
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
		$res = $this->http_request($url);

		$result = json_decode($res, true);
		$access_token = '';
		if (array_key_exists('access_token', $result)) {
			$access_token = $result['access_token'];
		}
		if ($access_token) {
			$this->notifyToAllZHJYAccessToken($access_token);
		}
		Log::info($res.'appid'.$appid);
		return $access_token;
	}

	//JsApiTicket
	private function getJsApiTicket($accessToken,$appid=self::APP_ID ,$appsecret=self::APP_KEY) {
		$url = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token='.$accessToken;
		$res = $this->http_request($url);
		$result = json_decode($res, true);
		$jsApiTicket='';
		if (array_key_exists('ticket', $result)) {
			$jsApiTicket = $result['ticket'];
		}
		if ($jsApiTicket) {
			$this->notifyToAllZHJYJsApiTicket($jsApiTicket);
		}
		return $jsApiTicket;
	}

	//HTTP请求（支持HTTP/HTTPS，支持GET/POST）
	protected function http_request($url, $data = null)
	{
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
		if (!empty($data)){
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$output = curl_exec($curl);
		curl_close($curl);
		return $output;
	}

}
?>