<?php
namespace App\Http\Controllers;

use App\Http\Controllers\WechatBaseController;
use Log;
use Input;
use DB;
use Memcache;
use View;
use Auth;
use Redirect;
$logFile = 'admin.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);
class AdminController extends BaseController{
	// private $info = array('status' => '', 'message' =>'');
	public function index(){
		if (!Auth::check()) {
			return Redirect::to('/login');
		}
		else{
			// $totalPageArr = array();
			$messagesState = Input::get("state");
			if ($messagesState == '') {
				$messagesState = 382;
			}
			// $len = 5;
			$page = (int)(Input::get('page') == '')?1:(Input::get('page'));
			$currentPage = (int)(Input::get('currentPage') == '')?1:(Input::get('currentPage'));
			$num = 3;
			$pageButtonNum = 8;
			$time = time() - 300;
			$date = date('Y-m-d H:i:s',$time);
			// count(var)
			if($messagesState == 61){
				$totalObj = DB::select("select * from messages where state = 61 || state = 383");
			}
			elseif ($messagesState == 62) {
				$totalObj = DB::select("select * from messages where state =62 and update_time <='$date'");
				Log::info("select id from messages where state =62 and update_time <='$date'");
			}
			else{
				$totalObj = DB::select("select * from messages where state = '$messagesState'");
			}

			$dealed = DB::select('select * from messages where state = 61 || state = 383');
			$toDealObj = DB::select('select * from messages where state = 382');
			$messagesDownloadedObj = DB::select('select * from messages where state = 383');
			$messagesDownloadedNum = count($messagesDownloadedObj);
			$messagesToDealNum = count($toDealObj);
			$messagesDealedNum = count($dealed);
			$totalPage = (count($totalObj) % $num == 0)?intval(count($totalObj)/$num):intval(count($totalObj)/$num + 1);
			if ($page > $totalPage) {
				$page = $totalPage;
			}
			if ($page < 1) {
				$begin = 0;
				$page  = 1; 
			}
			else{
				$begin = ($page - 1)*$num;
			}
			$currentPage = $page;
			// $begin = ($currentPage -1)*$num;
			if($messagesState == 61){
				$messages = DB::select("select * from messages where state = 61|| state =383 limit $begin, $num");
			}
			elseif ($messagesState == 62) {
				$messages = DB::select("select * from messages where state =62 and update_time <='$date' limit $begin, $num");
				Log::info("select id from messages where state =62 and update_time <='$date'");
			}
			else{
				$messages = DB::select("select * from messages where state = $messagesState limit $begin, $num");
			}
			Log::info("select * from messages where state = 381 limit $begin, $num");
			$totalPageArr = $this->getButtonList($totalPage,$pageButtonNum,$currentPage);
			$messagesErrordObj =  DB::select("select id from messages where state =62 and update_time <='$date'");
			$messagesErrordNum = count($messagesErrordObj);
			Log::info($totalPageArr);
			return View::make('index',array('messages' => $messages, 'totalPage' => $totalPageArr,
				'currentPage' => $currentPage,'messagesToDealNum' => $messagesToDealNum, 
				'messagesDealedNum' => $messagesDealedNum,'messagesDownloadedNum' =>$messagesDownloadedNum,
				'state' => $messagesState,'messagesErrordNum' =>$messagesErrordNum));			
		}
	}

	

	public function check()
	{
		// $userName = Input::get('UM');
		// $password = Input::get('PWD');
		$userName = $_POST['UM'];
		$password = $_POST['PWD'];
		$time1 = time();
		if (Auth::attempt(array('name' => $userName, 'password' => $password),true)) {
			$time2 = time();
			$rest = $time2 - $time1;
			Log::info('time used'.$rest);
			echo $this->get_json('1','登录成功');
		}
		else{
			echo $this->get_json('2','用户名或者密码不正确');
		}
	}


	public function register()
	{
		if (Auth::check()) {
			return Redirect::to('/');
		}
		else{
			$userName = Input::get('UM');
			$password = Input::get('PWD');
			if (!$this->is_username($userName) || !$this->is_password($password)) {
			echo $this->get_json('202','用户名或者密码不正确');
			return;
			}

			if (!$this->is_username_exist($userName)) {
				echo $this->get_json('201','用户名已被占用');
				return;		
			}

			$password = Hash::make($password);
			try {
			$createdAt =  date('Y-m-d H:i:s',time());
			// echo "insert into users(name,password,created_at) values ('$userName','$password','$createdAt')";
			$result = DB::insert("insert into users(name,password,created_at) values ('$userName','$password','$createdAt')");
			$id_arr = (array)DB::select('select last_insert_id()')[0];
			$id = $id_arr['last_insert_id()'];
			DB::insert("insert into warnings(type,value,user_id) values('message','false',$id)");
			}
			catch(Exception $e){
				echo $this->get_json('3','其他');
				return;
			}
			echo $this->get_json('1','成功');
			return;


		}
		
	}

	public function lock()
	{
		$id = Input::get('ID');
		DB::update("update messages set state = 62 where id = $id");
		return;
	}

	public function logout()
	{
		Auth::logout();
		return Redirect::to('login');
	}

	public function edit()
	{
		$id = Auth::id();
		$password = Input::get('password');
		if (!$this->is_password($password)) {
			echo $this->get_json('202','密码错误');
		}
		$password = Hash::make($password);
		try {
			DB::update("update users set password = '$password' where id = $id");
		} catch (Exception $e) {
			echo $this->get_json('203','其他');
			return;
		}
		echo $this->get_json('1','成功');
		Auth::logout();
		return;

	}
	public function requestNew()
	{
		if (!Auth::check()) {
			return;
		}
		else{
			$id = Auth::id();
			$res = DB::select("select * from warnings where type='message' and value ='true' and user_id = $id");

			if (!empty($res)) {
				echo $this->get_json('4','新消息');
				DB::update("update warnings set value = 'false' where user_id = $id and type='message'");
				return;
			}
			else{
				echo $this->get_json('404','无新消息');
				return;
			}
		}
	}

	public function delete()
	{
		$messageId = Input::get('ID');
		try {
			DB::update("update messages set state = 67 where id = $messageId");
			return $this->get_json('1','成功');
		} catch (Exception $e) {
			return $this->get_json('2','失败');
		}
	}
	private function getButtonList($totalPage, $pageButtonNum,$currentPage)
	{
		$totalPageArr =array();
		if($totalPage <= $pageButtonNum){
			for ($i=0; $i < $totalPage; $i++) { 
				array_push($totalPageArr, $i+1);
			}
		}
		if($totalPage > $pageButtonNum){
			for ($i=0; $i < $pageButtonNum; $i++) { 
				if ($currentPage < 4) {
					if($i == 4){
						array_push($totalPageArr, '...');
					}
					elseif($i > 4){
						array_push($totalPageArr, $totalPage - $pageButtonNum + 1 + $i);
					}
					else{
						array_push($totalPageArr,$i+1);
					}
				}
				elseif($currentPage > 4 && $currentPage > ($totalPage - $pageButtonNum)){
					array_push($totalPageArr, $i + 1 + $totalPage - $pageButtonNum);
				}
				else{
					if($i == 4){
						array_push($totalPageArr, '...');
					}
					elseif($i > 4){
						array_push($totalPageArr, $totalPage - $pageButtonNum + 1 + $i);
					}
					else{
						array_push($totalPageArr, ($i+$currentPage));
					}
				}
			}
		}
		Log::info($totalPageArr);
		return $totalPageArr;
	}

	private function is_username($username) {
		if (strlen($username) >= 5 && preg_match("/^\w{5,20}$/", $username)) {
			return 1;
		}

		return 0;
	}

	private function is_username_exist($name) {
		$result = DB::select("select * from users where name ='$name' ");
		return empty($result);

	}

	// private function get_json($status='',$message=''){
	// 	$this->info['status']		=	$status;
	// 	$this->info['message']		=	$message;
	// 	return json_encode($this->info);
	// }

	private function is_password($password) {

		if (strlen($password) >= 6 && preg_match("/^\w{6,16}$/", $password)) {
			return 1;
		}

		return 0;
	}

}