<?php namespace App\Http\Controllers;
use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
set_time_limit(0);

class TokenRefreshController extends ZhihuiWechatBaseController{

	public function zhjyAccessToken()
	{
		$token=Input::get('token');
		if ($token) {
			$this->refreshAccessToken($token);
		return 1;
		}
		return 0;
		
	}

	public function zhjyJsApiTicket()
	{
		$ticket=Input::get('ticket');
		if ($ticket) {
			$this->refreshJsApiTicket($ticket);
		return 1;
		}
		return 0;
		
	}

}
?>