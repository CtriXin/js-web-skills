<?php
namespace App\Http\Controllers;

use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
use DB;
require_once('lib/Tool.php');
require_once('lib/Http.php');
use Tool;
use Http;


// define('NET_ERR', '网络错误，请稍后重试');

set_time_limit(0);

/**
 * Class CardSignController 考勤
 * @package App\Http\Controllers
 * anthor hgx
 */
class CardSignController extends ZhihuiWechatBaseController{

    //智慧教育
    private static $appId='wx2683432074892f86';
    private static $secret='9147009bbad321887c93b17cc1989c7e';


    private function sendTp($openidObjArr,$studentName,$type,$userIdArr)
    {
      $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

      $template_id='bL65vNFAn0SGZT7MuZBANW12Cg3khu3gnXSSAakE-D4';
      $first='您的孩子已离校';
      $keyword1=$ts;
      $keyword2='校门';
      $keyword3=$studentName;
      $remark='点击查看历史记录';
      $url='http://bxj.snewfly.com/card_attance_history.php?userId=1&device_id=1#section_cardcenter';
      if ($type=='按时进校'||$type=='迟到') {
        $template_id='1BElgC9t0A1EWTgSJRsgVpyLUyZe2FzAqHxNglZeaPk';
        $first='您的孩子已到校';
        $keyword1=$studentName;
        $keyword2=$type;
        $keyword3=$ts;

      }

      $count=count($openidObjArr);
      for ($i=0; $i < $count; $i++) {
        $url='http://bxj.snewfly.com/card_attance_history.php?userId='.$userIdArr[$i].'&device_id='.Input::get('deviceId');
        $this->sendTemplateMsg($openidObjArr[$i]->name,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
        // Log::info($re);
      }
      
    }

    private function sendNearTp($openidObjArr,$studentName,$userIdArr)
    {
      $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

      $template_id='YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE';
      $first='您的孩子已到校门区域';
      $keyword1='考勤';
      $keyword2=$studentName;
      $keyword3=$ts;
      $remark='点击查看历史记录';
      $url='http://bxj.snewfly.com/card_attance_history.php?userId=1&device_id=1#section_cardcenter';
      
      $count=count($openidObjArr);
      for ($i=0; $i < $count; $i++) {
        $url='http://bxj.snewfly.com/card_attance_history.php?userId='.$userIdArr[$i].'&device_id='.Input::get('deviceId');
        $data=$this->createDeviceTemplate($openidObjArr[$i]->name,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
        $this->sendTemplate($data);
      }
      
    }


    private function getOpenidArr($userIdArr)
    {
      // SELECT name FROM users WHERE user_id='arjxwcc5k1FarddeVSIR8L'||user_id='123'
      $count=count($userIdArr);
      $str='SELECT name FROM users WHERE ';
      for ($i=0; $i <$count ; $i++) { 
        $str.="user_id='{$userIdArr[$i]}'||";
      }

      $sql=substr($str,0,strlen($str)-2);
      return DB::select($sql);
    }

    private function getTypeName($type)
    {
      $mtype='';
      switch ($type) {
        case '0':
        $mtype='按时出校';
        break;
        case '1':
        $mtype='按时进校';
        break;
        case '2':
        $mtype='迟到';
        break;

        default:
        $mtype='早退';
        break;
      }
      return $mtype;
    }

    /**
    * 学生卡考勤接口
    * @return json
    */
    public function card_sign(){
      if ($this->signatureSignCheck()) {

          $data=file_get_contents('php://input');
          Log::info($data);

        $userId=Input::get('cardId');
        $type=Input::get('type');
        $studentName=Input::get('studentName');
        $userIdArr=explode(',',$userId);
        $openidObjArr=$this->getOpenidArr($userIdArr);

        if ($type=='4') {//校区附近
          $this->sendNearTp($openidObjArr,$studentName,$userIdArr);
        }else{//0,123到离校推送
        $type=$this->getTypeName($type);
        $this->sendTp($openidObjArr,$studentName,$type,$userIdArr);
        }
        
        return Tool::getJson('1');
      }
      return Tool::getJson('0','无权限');
    }

    public function getAttanceHistory()
    {
      $userId=Input::get('userid');
      $device_id=Input::get('device_id');
      $begin_date=Input::get('begin_date');
      $end_date=Input::get('end_date');

      $url='http://kq.snewfly.com:8081/api/attendance/list?access_token=access_token';
      $data='userid='.$userId.'&device_id='.$device_id.'&begin_date='.$begin_date.'&end_date='.$end_date;
      return Http::http_request($url,$data);
    }


  /**
  *返回协议模式的设备事件提醒模板消息
  * 设备事件提醒id YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 提醒类型
  *@param keyword2 设备序号
  *@param keyword3 发生时间
  *@param remark 最低行 如点击查看历史记录
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createDeviceTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url=''){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return urldecode(json_encode($data));
  }



  }
  ?>