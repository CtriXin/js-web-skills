<?php
namespace App\Http\Controllers;

use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
use DB;
require_once('lib/Tool.php');
require_once('lib/Http.php');
use Tool;
use Http;

// define('NET_ERR', '网络错误，请稍后重试');

set_time_limit(0);

/**
 * Class SinglePushTest 用来推送模板给个别用户的
 * @package App\Http\Controllers
 * anthor hgx
 */
class SinglePushTest extends ZhihuiWechatBaseController{

    //智慧教育
  private static $appId='wx2683432074892f86';
  private static $secret='9147009bbad321887c93b17cc1989c7e';


  private function sendNearTp()
  {
    $ts=date('Y-m-d H:i:s',$_SERVER['REQUEST_TIME']);

    $template_id='YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE';
    $first='';
    $keyword1='学府中学八年九班家长群';
    $keyword2='无';
    $keyword3=$ts;
    $remark='点击详情查看家长群二维码。长按图片识别二维码';
    $url='http://7xkaou.com2.z0.glb.qiniucdn.com/%E5%AD%A6%E5%BA%9C%E4%B8%AD%E5%AD%A6%E5%85%AB%E5%B9%B4%E7%BA%A7%E5%AE%B6%E9%95%BF%E7%BE%A4%E4%BA%8C%E7%BB%B4%E7%A0%81.jpg';

    $openidObjArr=[];
    $count=count($openidObjArr);
    for ($i=0; $i < $count; $i++) {
      $data=$this->createDeviceTemplate($openidObjArr[$i],$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
      $this->sendTemplate($data);
    }

  }


  private function getOpenidArr($userIdArr)
  {
    $count=count($userIdArr);
    $str='SELECT name FROM users WHERE ';
    for ($i=0; $i <$count ; $i++) { 
      $str.="user_id='{$userIdArr[$i]}'||";
    }

    $sql=substr($str,0,strlen($str)-2);
    return DB::select($sql);
  }


    /**
    * 学生卡考勤反馈接口
    * @return json
    */
    public function pushTarget(){
      $this->sendNearTp();
      return Tool::getJson('1');

    }


  /**
  *返回协议模式的设备事件提醒模板消息
  * 设备事件提醒id YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 提醒类型
  *@param keyword2 设备序号
  *@param keyword3 发生时间
  *@param remark 最低行 如点击查看历史记录
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createDeviceTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url=''){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return urldecode(json_encode($data));
  }

}
?>