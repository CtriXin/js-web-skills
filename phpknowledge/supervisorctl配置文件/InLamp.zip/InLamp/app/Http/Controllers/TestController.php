<?php
$logfile = 'Test.log';
Log::useDailyFiles(storage_path().'/logs/'.$logfile);
class TestController extends BaseController{
	public function test()
	{
		$cmd = Input::get('cmd');
		if ($cmd == 'file') {
			Log::info($_FILES);
		}
	}
}