<?php namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use Log;
use Input;
use DB;
use Memcache;
$logFile = 'Base.log';
Log::useDailyFiles(storage_path().'/logs/'.$logFile);
class BaseController extends Controller {

	/**
	 * Setup the layout used by the controller.
	 *
	 * @return void
	 */
	protected $info = array('status' => '', 'message' =>'', 'data' =>'');
	protected function setupLayout()
	{
		if ( ! is_null($this->layout))
		{
			$this->layout = View::make($this->layout);
		}
	}

	/**
	 * @param $status,$message,$data
	 * 格式化返回数据
	 * @return JsonObj
	 */
	protected function get_json($status='',$message='',$data=''){
	$this->info['status']		=	$status;
	$this->info['message']		=	$message;
	$this->info['data'] 		= 	$data;
	return json_encode($this->info);
	}

	/**
	 * @param $iemi,$timestamp,$nonce,$signature
	 * 统一签名校验
	 * @return void
	 */
	protected function signatureCheck()
	{
		// 获取IMEI
		$imei = Input::get('IMEI');

		// 获取Timestamp
		$timestamp = Input::get('Timestamp');

		// 获取Nonce
		$nonce = Input::get('Nonce');

		// 获取signature
		$signature = Input::get('Signature');

		// 格式化时间戳
		$timestamp = substr($timestamp, 0, 10);

		// 对字符串进行hash1加密
		$secret = 'kcurimnfgmkfmfl';

		Log::info("imei: $imei | timestamp: $timestamp | nonce: $nonce | signature: $signature");
		$str = sha1($imei.$timestamp.$nonce.$secret);
		Log::info("encoded signature: $str");
		
		// 如果校验通过返回true，否则返回false
		if ($str == $signature) {
			Log::info('method: check | true');
			return true;
		}
		else{
			Log::info('method: check | false');
			return false;
		}
	}

	/**
	 * @param $type
	 * 文件名确定
	 * @return String
	 */
	protected function getDestination($type)
	{
		$timeArr = gettimeofday();
		$name = $timeArr['sec'].$timeArr['usec'].rand(0,50);
		// 根据文件类型取不同的文件名后缀
		switch ($type) {
			case 'audio/wav':
				$fileName = $name.".wav";
				break;
			case 'audio/mp3':
				$fileName = $name.".mp3";
				break;
			case 'audio/mpeg':
				$fileName = $name.".mp3";
				break;
			case 'audio/mp4':
				$fileName = $name.".mp4";
				break;
			case 'video/mp4':
				$fileName = $name.".mp4";
				break;
			case 'audio/3gpp':
				$fileName = $name.".3gp";
				break;
			case 'video/3gpp':
				$fileName = $name.".3gp";
				break;
			case 'image/gif':
				$fileName = $name.'.gif';
				break;
			case 'image/jpeg':
				$fileName = $name.'.jpeg';
				break;
			case 'image/tiff':
				$fileName = $name.'.tif';
				break;
			case 'image/png':
				$fileName = $name.'.png';
				break;
			case 'image/dwg':	
				$fileName = $name.'.dwg';
				break;
			default:
				$fileName = $name.".3gp";
				break;
		}
		$dir = $this->getDir($type);
		return $dir.'/'.$fileName;
	}

	protected function getDir($type)
	{
		// 获取目录上传日期
		$dirDate = date('y-m-d',time());

		// 看是有否上传文件目录
		if(!is_dir('upload'))
			mkdir('upload');

		//查看是否有相应的录音上传目录 
		if (!is_dir('upload/audio')) {
			mkdir('upload/audio');
		}

		// 查看是否有相应日期的上传目录
		if (!is_dir('upload/audio/'.$dirDate)) {
			mkdir('upload/audio/'.$dirDate);
		}

		//查看是否有相应的录音上传目录 
		if (!is_dir('upload/img')) {
			mkdir('upload/img');
		}

		// 查看是否有相应日期的图片上传目录
		if (!is_dir('upload/img/'.$dirDate)) {
			mkdir('upload/img/'.$dirDate);
		}

		// 查看是否有相应日期的录音上传目录
		if (!is_dir('upload/audio/'.$dirDate)) {
			mkdir('upload/audio/'.$dirDate);
		}

		if ($type == 'image/jpeg') {
			return 'upload/img/'.$dirDate;
		}
		elseif($type == 'audio/mp4') {
			return 'upload/audio/'.$dirDate;
		}
		else{
			return 'upload/audio/'.$dirDate;
		}
	}

}
