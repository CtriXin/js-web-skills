<?php
namespace App\Http\Controllers;

use App\Http\Controllers\ZhihuiWechatBaseController;
use Log;
use Input;
use DB;
require_once('lib/Tool.php');
use Tool;

set_time_limit(0);

//TODO 长时间类型任务，用队列优化

/**
 * Class JxtController 家校通消息推送接收入口
 * @package App\Http\Controllers
 * anthor hgx
 */
class JxtController extends ZhihuiWechatBaseController{

  // const DEFAULT_UNREAD_TIPS='您有新的语音消息';

  const TPID_HOMEWORK='z4N4z7s0syT_gUFnUj036-Gy1vrTCm4e8MVTB0hHKIQ';
  const TPID_HOLIDAY='4LoNzpwR-kQr7uE_EjpcZd22xPpTnli8MuV4c9MBLec';
  const TPID_EXAM='CBSbB-l9I9YteIObTa8i-4s0nOZ3ngXs2hreej5Yi-g';
  const TPID_MEETING='E9lhhFEtL2_K5lRdLpsARzO7dzImg8cIJWZDE0FxRhA';
  const TPID_TERMBEGIN='6i6ZPtSeT9kwcMLRkf7H1bGC_JffhD5aHb4SYXUvNP0';
  const TPID_GRADE='soaJxd2AoxZdq7en2eauSZmCqcnyQ_EjULmRiYlxNEM';
  // const TPID_NOTICE='z4N4z7s0syT_gUFnUj036-Gy1vrTCm4e8MVTB0hHKIQ';

  const DEFAULT_JXT_URL='http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_jxt&response_type=code&scope=snsapi_base&state=SUISHI';
  const DEFAULT_REMARK='点击进入家校互动';


    /**
    * 消息接口
    * @return json
    */
    public function push(){
      $data=file_get_contents('php://input');
      Log::info($data);
      if ($data) {
        $obj=json_decode($data);
        if ($obj) {
          if (isset($obj->type)) {
            $re='';
            switch ($obj->type) {
            case 'homework':
            $re=$this->homeworkPush($obj);
            break;
            case 'notice':
            $re=$this->noticePush($obj);
            break;
            case 'score':
            $re=$this->scorePush($obj);
            break;
            case 'holiday':
            $re=$this->holidayPush($obj);
            break;
            case 'exam':
            $re=$this->examPush($obj);
            break;
            case 'meeting':
            $re=$this->meetingPush($obj);
            break;
            case 'term_begin':
            $re=$this->termBeginPush($obj);
            break;
            
            default:
            return Tool::getJson('0','没有这个消息类型');
            break;
          }
          if ($re) {
            return Tool::getJson('1');
          }
          
          }
            
        }
        return Tool::getJson('0','数据格式错误');
        
      }
      return Tool::getJson('0','提交数据为空');
      
    }

  /**
  *@param obj msg obj
  *@return void
  */
  private function homeworkPush($obj)
  {
    $date=date('Y-m-d',$_SERVER['REQUEST_TIME']);
      $nickArr=$this->getNickArrFromToArr($obj->content->to);//存放昵称的数组，防止查询数据库数量不匹配
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);
      $tp='';
      $subject=$obj->content->subject;
      $content=$obj->content->content;
      if ($count<100){
        for ($i=0; $i <$count; $i++) {
        $tp=$this->createHomeworkTemplate($openidArr[$i]->openid,self::TPID_HOMEWORK,$nickArr[$openidArr[$i]->user_id],$subject,$date,$content,self::DEFAULT_REMARK,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
      
    }

    private function noticePush($obj)
    {
      $date=date('Y-m-d',$_SERVER['REQUEST_TIME']);
      $nickArr=$this->getNickArrFromToArr($obj->content->to);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);
      $tp='';
      $from=$obj->content->from;
      $content=$obj->content->content;
      if ($count<100){
        for ($i=0; $i <$count; $i++) {
        $tp=$this->createHomeworkTemplate($openidArr[$i]->openid,self::TPID_HOMEWORK,$nickArr[$openidArr[$i]->user_id],$from,$date,$content,self::DEFAULT_REMARK,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
      
    }
    
    private function holidayPush($obj)
    {
      $date=date('Y-m-d',$_SERVER['REQUEST_TIME']);
      $nickArr=$this->getNickArrFromToArr($obj->content->to);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);
      $tp='';
      $from=$obj->content->from;
      $content=$obj->content->content;
      if ($count<100){
        for ($i=0; $i <$count; $i++) {
          $first=$nickArr[$openidArr[$i]->user_id].' 放假通知';
        $tp=$this->createHolidayTemplate($openidArr[$i]->openid,self::TPID_HOLIDAY,$first,$from,$date,$content,self::DEFAULT_REMARK,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
    }

    private function examPush($obj)
    {
      $nickArr=$this->getNickArrFromToArr($obj->content->to);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);

      $tp='';
      $subject=$obj->content->subject;
      $time=$obj->content->time;
      $room=$obj->content->room;
      $content=$obj->content->content;

      if ($count<100){
        
        for ($i=0; $i <$count; $i++) {
          $first=$nickArr[$openidArr[$i]->user_id].' 考试安排';
        $tp=$this->createExamTemplate($openidArr[$i]->openid,self::TPID_EXAM,$first,$subject,$time,$room,$content,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
    }

    private function meetingPush($obj)
    {
      $nickArr=$this->getNickArrFromToArr($obj->content->to);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);

      $tp='';
      $school=$obj->content->school;
      $time=$obj->content->time;
      $room=$obj->content->room;
      $content=$obj->content->content;

      if ($count<100){
        
        for ($i=0; $i <$count; $i++) {
          $first=$nickArr[$openidArr[$i]->user_id].' 家长会通知';
        $tp=$this->createMeetingTemplate($openidArr[$i]->openid,self::TPID_MEETING,$first,$school,$time,$room,$content,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
    }

    private function termBeginPush($obj)
    {
      $nickArr=$this->getNickArrFromToArr($obj->content->to);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->to);
      $count=count($openidArr);

      $tp='';
      $school=$obj->content->school;
      $time=$obj->content->time;
      $content=$obj->content->content;
      $from=$obj->content->from;

      if ($count<100){
        
        for ($i=0; $i <$count; $i++) {
        $tp=$this->createTermBeginTemplate($openidArr[$i]->openid,self::TPID_TERMBEGIN,$content,$nickArr[$openidArr[$i]->user_id],$from,$time,$school,self::DEFAULT_REMARK,self::DEFAULT_JXT_URL);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
    }

    private function scorePush($obj)
    {
      $nickArr=$this->getNickArrFromContentArr($obj->content->content);
      $openidArr=$this->getOpenidArrFromToArr($obj->content->content);
      $count=count($openidArr);
      $tp='';
      $subject=$obj->content->common->subject;
      $subjectNote=$obj->content->common->note;
      if ($count<100) {
        for ($i=0; $i <$count ; $i++) {
        $keyobj=$nickArr[$openidArr[$i]->user_id];

        $title=$keyobj->name.' '.$subjectNote.' '.$keyobj->note;

        $tp=$this->createGradeTemplate($openidArr[$i]->openid,self::TPID_GRADE,$title,$subject,$keyobj->score);
        $this->sendTemplate($tp);
      }
      return 1;
      }
      return 0;
      
    }

    private function getNickArrFromToArr($toArr)
    {
      $len=count($toArr);
      $arr=[];
      for ($i=0; $i <$len ; $i++) {
        if ($toArr[$i]->name) {
          $arr[$toArr[$i]->userid]=$toArr[$i]->name;
        }
      }
      return $arr;
    }

    //成绩 key->obj{name,note}
    private function getNickArrFromContentArr($contentArr)
    {
      $len=count($contentArr);
      $arr=[];
      for ($i=0; $i <$len ; $i++) {
        $obj=new ScoreBean();
        $obj->name=$contentArr[$i]->student_name;
        $obj->note=$contentArr[$i]->note;
        $obj->score=$contentArr[$i]->score;

        $arr[$contentArr[$i]->userid]=$obj;
      }
      return $arr;
    }

    private function getOpenidArrFromToArr($toArr)
    {
      $len=count($toArr);
      $sql='SELECT NAME as openid,user_id FROM users WHERE ';
      for ($i=0; $i <$len ; $i++) {
        if ($toArr[$i]->userid) {
          $sql.="user_id='{$toArr[$i]->userid}'||";
        }
        
      }
      $sql=substr($sql,0,strlen($sql)-2);
      Log::info($sql);
      return DB::select($sql);
    }

  /**
  *返回协议模式的模板消息
  * 作业提醒id z4N4z7s0syT_gUFnUj036-Gy1vrTCm4e8MVTB0hHKIQ
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 科目
  *@param keyword2 日期
  *@param keyword3 内容
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createHomeworkTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }

  /**
  *返回协议模式的模板消息
  * id 4LoNzpwR-kQr7uE_EjpcZd22xPpTnli8MuV4c9MBLec
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 发送人
  *@param keyword2 发送时间
  *@param keyword3 放假原因
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createHolidayTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'noticeSender'=>['value'=>$keyword1,'color'=>'#173177'],
    'time'=>['value'=>$keyword2,'color'=>'#173177'],
    'status'=>['value'=>'否','color'=>'#173177'],
    'reason'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }

  /**
  *返回协议模式的模板消息
  * id CBSbB-l9I9YteIObTa8i-4s0nOZ3ngXs2hreej5Yi-g
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 课程名
  *@param keyword2 考试时间
  *@param keyword3 考试地点
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createExamTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }

  /**
  * id E9lhhFEtL2_K5lRdLpsARzO7dzImg8cIJWZDE0FxRhA
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 学校名称
  *@param keyword2 会议日期
  *@param keyword3 会议地点
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createMeetingTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'date'=>['value'=>$keyword1,'color'=>'#173177'],
    'class'=>['value'=>$keyword2,'color'=>'#173177'],
    'type'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }


  /**
  * id 6i6ZPtSeT9kwcMLRkf7H1bGC_JffhD5aHb4SYXUvNP0
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 学生姓名
  *@param keyword2 通知人
  *@param keyword3 开学时间
  *@param keyword4 学校
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createTermBeginTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$keyword4,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'keyword4'=>['value'=>$keyword4,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }

  /**
  *返回协议模式的模板消息
  * 考试成绩通知id soaJxd2AoxZdq7en2eauSZmCqcnyQ_EjULmRiYlxNEM
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 考试科目
  *@param keyword2 考试成绩
  *@param remark 最低行 点击进入家校通
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createGradeTemplate($touser,$template_id,$first,$keyword1,$keyword2,$remark=self::DEFAULT_REMARK,$url=self::DEFAULT_JXT_URL){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return json_encode($data,JSON_UNESCAPED_UNICODE);
  }

}

class ScoreBean
{
  public $name,$note,$score;
}
?>