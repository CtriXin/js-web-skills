<?php
function getStatus($arg){
   echo "i do\n";
   // print_r connection_status();
   // debug_print_backtrace();
}
reigster_tick_function("getStatus", true);
declare(ticks=1){
   for($i =1; $i<999; $i++){
        echo "hello";
  }
}
unregister_tick_function("getStatus");