<?php

namespace App\Http\Middleware;

use Closure;

    /**
     * BXJAuth
     * banxueji session rong_token校验用户是否登录状态
     * 15-12-15 by hgx bajian
     */
class BXJAuth
{

    public function __construct()
    {
        if(!isset($_SESSION)){
            session_start();  
        }  
    }

    /**
     * Run the request filter.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (array_key_exists('id',$_SESSION) &&array_key_exists('rong_token',$_SESSION)){
            return $next($request);//登录状态
        }else{
            return $this->getNoAuthJson();
        }
    }

    /**
     * 解耦
     *
     * @return json
     */
    private function getNoAuthJson()
    {
        return '{"code":"101","msg":"登录超时，请重新从微信进入"}';
    }

}