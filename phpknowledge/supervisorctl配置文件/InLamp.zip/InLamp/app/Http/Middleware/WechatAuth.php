<?php

namespace App\Http\Middleware;

use Closure;

    /**
     * WechatAuth
     * weixin auth授权 session id（openid）校验用户是否登录状态
     * 15-12-23 by hgx bajian
     */
class WechatAuth
{

    public function __construct()
    {
        if(!isset($_SESSION)){
            session_start();  
        }  
    }

    /**
     * Run the request filter.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (array_key_exists('id',$_SESSION)){
            return $next($request);//登录状态
        }else{
           //默认学生卡auth
            return $this->toLoginJson();
        }
    }

    private function toLoginJson(){
        return '{"code":"101","msg":"登录超时"}';
    }

}