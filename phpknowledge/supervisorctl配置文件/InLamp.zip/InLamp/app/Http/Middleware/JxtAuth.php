<?php

namespace App\Http\Middleware;

use Closure;

    /**
     * JxtAuth
     * jxt session card_userId校验用户是否登录状态
     * 16-02-29 by hgx bajian
     */
class JxtAuth
{

    public function __construct()
    {
        if(!isset($_SESSION)){
            session_start();  
        }  
    }

    /**
     * Run the request filter.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (array_key_exists('id',$_SESSION) && array_key_exists('card_userId',$_SESSION)  ){
            return $next($request);//登录状态
        }else{
            return $this->getNoAuthJson();
        }
    }

    /**
     * 解耦
     *
     * @return json
     */
    private function getNoAuthJson()
    {
        return '{"code":110,"data":null,"msg":"登录超时，请重新从微信进去"}';
    }

}