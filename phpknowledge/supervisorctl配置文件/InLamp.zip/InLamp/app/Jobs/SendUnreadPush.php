<?php
namespace App\Jobs;
use App\Jobs\Job;
use App\Http\Controllers\ZhihuiWechatBaseController;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Bus\SelfHandling;
use Illuminate\Contracts\Queue\ShouldQueue;
use Log;
use Illuminate\Support\Facades\Redis as Redis;
use DB;

class SendUnreadPush extends Job implements SelfHandling, ShouldQueue
{
  use InteractsWithQueue;
  private $redis;
  private $arr;

  const APP_ID='wx2683432074892f86';
  const APP_KEY='9147009bbad321887c93b17cc1989c7e';
  const MEM_KEY_ACCESS_TOKEN_ZHIHUIJIAOYU='zhjy_access_token';
  const KEY_REDIS_OPENID='opid';//openid
  const KEY_REDIS_EXPRIE=7200;

  const ID_DEVICE_MSG_TEMPLATE='YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE';

  const DEFAULT_UNREAD_TIPS=' 语音消息';
  const DEFAULT_LBS_TIPS=' 实时定位消息';
  const DEFAULT_SOS_TIPS=' 紧急求助消息';
  const DEFAULT_PIC_TIPS=' 图片消息';
  const DEFAULT_UNREAD_REMARKS='点击进入查看';
  const DEFAULT_UNREAD_BXJ_URL='http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_bxj&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect';
  const DEFAULT_UNREAD_XSK_URL='http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx2683432074892f86&redirect_uri=http://bxj.snewfly.com/auth_card&response_type=code&scope=snsapi_base&state=SUISHI#wechat_redirect';

  public function __construct($arrInfo)
  {
    $this->arr = $arrInfo;
    $this->redis = Redis::connection('default');

  }

  /**
   * Execute the job.
   *  ['type'=>'bxj','msgId'=>'123','fNick'=>'小明','fromUser'=>'123','toUser'=>'123']
   * @return void
   */
  public function handle()
  {
    if ($this->attempts() > 3) {
        return;//放弃失败3次以上的任务
    }
    $key=$this->redis->get($this->arr['deviceType'].$this->arr['msgId']);
    if ($key==1) {
      Log::info('SendUnreadPush handle'.json_encode($this->arr));
      $this->redis->DEL($this->arr['deviceType'].$this->arr['msgId']);

      switch ($this->arr['msgType']) {
        case 'voice':
          $this->pushTemplate(self::DEFAULT_UNREAD_TIPS,'未读语音消息');
          break;
          case 'feedback':
          $this->pushTemplate($this->arr['msgName'],$this->arr['msgContent']);
          break;
          case 'lbs':
          $this->pushTemplate(self::DEFAULT_LBS_TIPS,$this->arr['address']);
          break;
          case 'sos':
          $this->pushTemplate(self::DEFAULT_SOS_TIPS,$this->arr['address'],'sos');
          break;
          case 'pic':
          $this->pushTemplate(self::DEFAULT_PIC_TIPS,'未读图片消息');
          break;

        default:
          break;
      }
    }
  }

  /**
  * 发送模板消息
  * @param $first 消息内容
  * @param $typeValue 通知类型。如低电量通知
  * @param $type sos/'' 
  * @return json
  */
  public function pushTemplate($typeValue,$first,$type=''){
    $touser=$this->getOpenIdByUserId($this->arr['toUser']);
    if (!$touser) return;
    
    $deviceType='学生卡';
    $url=self::DEFAULT_UNREAD_XSK_URL;
    if ($this->arr['deviceType']=='bxj') {
      $deviceType='伴学机';
      $url=self::DEFAULT_UNREAD_BXJ_URL;
    }
    $ts=date(' Y-m-d H:i:s',$this->arr['ts']);

    switch ($type) {
      case 'sos':
        $this->sendSOSTemplateMsg($touser,self::ID_DEVICE_MSG_TEMPLATE,$first,$deviceType.$typeValue,$this->arr['fNick'],$ts,self::DEFAULT_UNREAD_REMARKS,$url);
        break;

      default:
            $this->sendTemplateMsg($touser,self::ID_DEVICE_MSG_TEMPLATE,$first,$deviceType.$typeValue,$this->arr['fNick'],$ts,self::DEFAULT_UNREAD_REMARKS,$url);
        break;
    }
}
/*
  private function getAccessToken($appid ,$appsecret,$mem_key=self::MEM_KEY_ACCESS_TOKEN_ZHIHUIJIAOYU){
    //设置缓存，100分钟更新一次access_token
    $access_token = $this->redis->get($mem_key);
    Log::info('zhihui access_token----'.$access_token);
    if (empty($access_token)){
      $url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$appsecret;
      $res = $this->http_request($url);
      $result = json_decode($res, true);
      $access_token = $result['access_token'];
      $this->redis->SETEX($mem_key,6000, $access_token);
      Log::info('set zhihui access_token----'.$access_token);
    }
    return $access_token;
  }*/

/**
* 发送模板消息
* @param $data json格式模板
* @return json
*/
private function sendTemplate($data){
  $baseController=new ZhihuiWechatBaseController();
  $baseController->sendTemplate($data);
}

  /**
  *发送模板消息 入口
  *@param touser openid 其他参数参照微信模板协议
  *@return null
  */
  public function sendTemplateMsg($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url){
    $data=$this->createUnreadTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
    return $this->sendTemplate($data);
  }

  /**
  *发送模板消息 入口
  *@param touser openid 其他参数参照微信模板协议
  *@return null
  */
  public function sendSOSTemplateMsg($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url){
    $data=$this->createSOSTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url);
    return $this->sendTemplate($data);
  }
  
  /**
  *返回协议模式的到校模板消息
  * 设备事件提醒id YVdWeh8QDc8DsfnqCnEtoK1wuoyF1LuLpwmnNjbWChE
  *@param touser 欲发送给目标openid
  *@param first 标题
  *@param keyword1 提醒类型
  *@param keyword2 设备序号
  *@param keyword3 发生时间
  *@param remark 最低行 如点击查看历史记录
  *@param url 可空，用户点击消息显示的url
  *@return json
  */
  private function createUnreadTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url=''){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#173177'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return urldecode(json_encode($data));
  }

  private function createSOSTemplate($touser,$template_id,$first,$keyword1,$keyword2,$keyword3,$remark,$url=''){
    $data=['touser'=>$touser,'template_id'=>$template_id,'url'=>$url,'topcolor'=>'#FF0000',
    'data'=>['first'=>['value'=>$first,'color'=>'#173177'],
    'keyword1'=>['value'=>$keyword1,'color'=>'#FF0000'],
    'keyword2'=>['value'=>$keyword2,'color'=>'#173177'],
    'keyword3'=>['value'=>$keyword3,'color'=>'#173177'],
    'remark'=>['value'=>$remark,'color'=>'#173177']]];
    return urldecode(json_encode($data));
  }

  function getOpenIdByUserId($user_id){
    $openid=$this->redis->get($user_id.self::KEY_REDIS_OPENID);
      if ($openid) {
        return $openid;
      }

    $re=DB::select("select name from users where user_id='$user_id' and group_id=2");
    if ($re) {
      $this->redis->SETEX($user_id.self::KEY_REDIS_OPENID,self::KEY_REDIS_EXPRIE,$re[0]->name);
      return $re[0]->name;
    }
    return '';
  }





}